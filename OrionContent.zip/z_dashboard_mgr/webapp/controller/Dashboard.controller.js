sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"../model/formatter",
	"../model/DashboardService",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
    'sap/ui/model/BindingMode',
   'sap/viz/ui5/format/ChartFormatter',
    'sap/viz/ui5/api/env/Format',
    '../model/InitPage',
    '../model/InitPageRev'
], function (BaseController, JSONModel, formatter,DashboardService, Filter, FilterOperator,BindingMode,ChartFormatter,Format,InitPageUtil,InitPageRev) {
	"use strict";

	return BaseController.extend("icl.group.com.dashboard.mgr.controller.Dashboard", {

		formatter: formatter,
        oVizFrame : null,



		onInit : function () {
			var oView = this.getView(),
				iOriginalBusyDelay,
				oTable = this.byId("table");
				
			var oService = new DashboardService(this.getView(), false);
			oService.mngLevelASet() ;                      
 
			this._aTableSearchState = [];

			// Model used to manipulate control states
/*			oViewModel = new JSONModel({
				dashboardTableTitle : this.getResourceBundle().getText("dashboardTableTitle"),
				shareOnJamTitle: this.getResourceBundle().getText("dashboardTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailDashboardSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailDashboardMessage", [location.href]),
				tableNoDataText : this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay : 0
			});
			this.setModel(oViewModel, "dashboardView");


            var oModel = new JSONModel(this.settingsModel);
            oModel.setDefaultBindingMode(BindingMode.OneWay);
            this.getView().setModel(oModel);

			var oVizFrame = this.getView().byId("idVizFrameItems");
			this.oVizFrame = oVizFrame ; 
			var oChart = this.getView().byId("idPopOver");
			oChart.connect(oVizFrame.getVizUid());
			InitPageUtil.initPageSettings(this.getView());
  
		 
  			var oVizFrameRev = this.getView().byId("idVizFrameRev");
			this.oVizFrameRev = oVizFrameRev ; 
			var oChartRev = this.getView().byId("idPopOverRev");
			oChartRev.connect(oVizFrameRev.getVizUid());
			InitPageRev.initPageSettings(this.getView());       
			
  			var idVizFrameComp = this.getView().byId("idVizFrameComp");
			this.idVizFrameComp = idVizFrameComp ; 
			var oChartRev = this.getView().byId("idPopOverComp");
			oChartRev.connect(idVizFrameComp.getVizUid());
			InitPageRev.initPageSettings(this.getView());       			
		 
			var sampleDatajson = this.getOwnerComponent().getModel("mngLevelASet");
			var oVizFrame = this.getView().byId("idStackedChart");
			oVizFrame.setVizProperties({
				plotArea: {
					colorPalette: d3.scale.category20().range(),
					dataLabel: {
						showTotal: true
					}
				},
				tooltip: {
					visible: true
				},
				title: {
					text: "Open PR Status"
				}
			});			

			var oDataset = new sap.viz.ui5.data.FlattenedDataset({
				dimensions: [{
					name: "Status Duration",
					value: "{Title}"
				}],
	
				measures: [{
					name: "Not Handle",
					value: "{openPR}"
				}, {
					name: "Partial PO",
					value: "{PO}"
				}, {
					name: "In RFQ",
					value: "{RFQ}"
				}],
	
				data: {
					path: "/groupedByStatusTime"
				}
			});			

			oVizFrame.setDataset(oDataset);
	
			oVizFrame.setModel(sampleDatajson);
	
			var oFeedValueAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
					"uid": "valueAxis",
					"type": "Measure",
					"values": ["Not Handle"]
				}),
				oFeedValueAxis1 = new sap.viz.ui5.controls.common.feeds.FeedItem({
					"uid": "valueAxis",
					"type": "Measure",
					"values": ["Partial PO"]
				}),
				oFeedValueAxis2 = new sap.viz.ui5.controls.common.feeds.FeedItem({
					"uid": "valueAxis",
					"type": "Measure",
					"values": ["In RFQ"]
				}),
	
				oFeedCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
					"uid": "categoryAxis",
					"type": "Dimension",
					"values": ["Status Duration"]
				});
	
			oVizFrame.addFeed(oFeedValueAxis);
			oVizFrame.addFeed(oFeedValueAxis1);
			oVizFrame.addFeed(oFeedValueAxis2);
			oVizFrame.addFeed(oFeedCategoryAxis);		*/ 
			
		 

		},
		/*
		getPrDetailsSetLevelCallback : function(o) {
			var oModel = o.oModel;
			this.setModel (oModel, "PrDetailsSetLevelModel"  );
		},*/
		onChartLevelChanged: function(){ 
			var selectedLevel = this.getView().getModel("levelModel").getData().selectedKey ;
			var oService = new DashboardService(this.getView(), false);
			oService.getPrDetailsSetLevel(selectedLevel,false,true);
		},
        onAfterRendering : function(){
        	/*
        	if (this.oVizFrame){
                this.oVizFrame.setVizProperties({
                    plotArea: {
                        dataLabel: {
                            visible: true
                        }
                    }
                });
            }*/
    
        },
  
		mngLevelASetCallback : function(o) {
			
			var oModel = o.oModel;
			this.getView().setModel (oModel, "mngLevelASet"  );
			 
			var oViewModel = new JSONModel({
				dashboardTableTitle : this.getResourceBundle().getText("dashboardTableTitle"),
				shareOnJamTitle: this.getResourceBundle().getText("dashboardTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailDashboardSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailDashboardMessage", [location.href]),
				tableNoDataText : this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay : 0
			});
			
			this.setModel(oViewModel, "dashboardView");


            var oModel = new JSONModel(this.settingsModel);
            oModel.setDefaultBindingMode(BindingMode.OneWay);
            this.getView().setModel(oModel);

			var oVizFrame = this.getView().byId("idVizFrameItems");
			this.oVizFrame = oVizFrame ; 
			var oChart = this.getView().byId("idPopOver");
			oChart.connect(oVizFrame.getVizUid());
			InitPageUtil.initPageSettings(this.getView());
  
		 
  			var oVizFrameRev = this.getView().byId("idVizFrameRev");
			this.oVizFrameRev = oVizFrameRev ; 
			var oChartRev = this.getView().byId("idPopOverRev");
			oChartRev.connect(oVizFrameRev.getVizUid());
			InitPageRev.initPageSettings(this.getView());       
			
  			var idVizFrameComp = this.getView().byId("idVizFrameComp");
			this.idVizFrameComp = idVizFrameComp ; 
			var oChartRev = this.getView().byId("idPopOverComp");
			oChartRev.connect(idVizFrameComp.getVizUid());
			InitPageRev.initPageSettings(this.getView());       			
		 
			var sampleDatajson = this.getView().getModel("mngLevelASet");
			var oVizFrame = this.getView().byId("idStackedChart");
			oVizFrame.setVizProperties({
				plotArea: {
					colorPalette: d3.scale.category20().range(),
					dataLabel: {
						showTotal: true
					}
				},
				tooltip: {
					visible: true
				},
				title: {
					text: "Open PR Status"
				}
			});			

			var oDataset = new sap.viz.ui5.data.FlattenedDataset({
				dimensions: [{
					name: "Status Duration",
					value: "{Title}"
				}],
	
				measures: [{
					name: "Not Handle",
					value: "{openPR}"
				}, {
					name: "Partial PO",
					value: "{PO}"
				}, {
					name: "In RFQ",
					value: "{RFQ}"
				}],
	
				data: {
					path: "/groupedByStatusTime"
				}
			});			

			oVizFrame.setDataset(oDataset);
	
			oVizFrame.setModel(sampleDatajson);
	
			var oFeedValueAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
					"uid": "valueAxis",
					"type": "Measure",
					"values": ["Not Handle"]
				}),
				oFeedValueAxis1 = new sap.viz.ui5.controls.common.feeds.FeedItem({
					"uid": "valueAxis",
					"type": "Measure",
					"values": ["Partial PO"]
				}),
				oFeedValueAxis2 = new sap.viz.ui5.controls.common.feeds.FeedItem({
					"uid": "valueAxis",
					"type": "Measure",
					"values": ["In RFQ"]
				}),
	
				oFeedCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
					"uid": "categoryAxis",
					"type": "Dimension",
					"values": ["Status Duration"]
				});
	
			oVizFrame.addFeed(oFeedValueAxis);
			oVizFrame.addFeed(oFeedValueAxis1);
			oVizFrame.addFeed(oFeedValueAxis2);
			oVizFrame.addFeed(oFeedCategoryAxis);		

			console.log("dashbord mngLevelASetCallback ") ; 
		},
  
		onUpdateFinished : function (oEvent) {
			// update the dashboard's object counter after the table update
			var sTitle,
				oTable = oEvent.getSource(),
				iTotalItems = oEvent.getParameter("total");
			// only update the counter if the length is final and
			// the table is not empty
			if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("dashboardTableTitleCount", [iTotalItems]);
			} else {
				sTitle = this.getResourceBundle().getText("dashboardTableTitle");
			}
			this.getModel("dashboardView").setProperty("/dashboardTableTitle", sTitle);
		},

		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		onPress : function (oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},

		/**
		 * Event handler for navigating back.
		 * We navigate back in the browser history
		 * @public
		 */
		onNavBack : function() {
			// eslint-disable-next-line sap-no-history-manipulation
			history.go(-1);
		},
		onSearchCompanyDesc: function (oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
			} else {
				var aTableSearchState = [];
				var sQuery = oEvent.getParameter("query");

				if (sQuery && sQuery.length > 0) {
					aTableSearchState = [new Filter("CompanyDesc", FilterOperator.Contains, sQuery)];
				}
				this._applySearch(aTableSearchState);
			}

		},
		onSearchBuyerName : function (oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
			} else {
				var aTableSearchState = [];
				var sQuery = oEvent.getParameter("query");

				if (sQuery && sQuery.length > 0) {
					aTableSearchState = [new Filter("BuyerName", FilterOperator.Contains, sQuery)];
				}
				this._applySearch(aTableSearchState);
			}

		},

		onSearchSystem : function (oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
			} else {
				var aTableSearchState = [];
				var sQuery = oEvent.getParameter("query");

				if (sQuery && sQuery.length > 0) {
					aTableSearchState = [new Filter("System", FilterOperator.Contains, sQuery)];
				}
				this._applySearch(aTableSearchState);
			}

		},

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh : function () {
			var oTable = this.byId("table");
			oTable.getBinding("items").refresh();
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showObject : function (oItem) {
			var path = oItem.getBindingContext("PrDetailsSetModel").getPath() ; 
			path = path.substring(1, path.length) ;
			this.getRouter().navTo("object", {
				objectId: path
			});
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @param {sap.ui.model.Filter[]} aTableSearchState An array of filters for the search
		 * @private
		 */
		_applySearch: function(aTableSearchState) {
			var oTable = this.byId("table"),
				oViewModel = this.getModel("dashboardView");
			oTable.getBinding("items").filter(aTableSearchState, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (aTableSearchState.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("dashboardNoDataWithSearchText"));
			}
		}

	});
});