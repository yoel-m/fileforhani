"use strict";

jQuery.sap.declare("clalit.org.il.ZEssAttendance.constants.TableCells");

clalit.org.il.ZEssAttendance.constants.TableCells =  new function() {


		this.DATE_REPORT = 0;
		this.DAY = 1;
		
		//רב מינוי או רב שיבוץ
		this.ORG_UNIT = 2;
		
		//עובד רגיל
		this.START_HOUR = 2;
		this.END_HOUR = 3;
		this.ATTENDANCE_DAILY = 4;
		this.TEKEN_DAILY = 5;
		this.ABS_CODE = 6;
		this.ABS_FULL_DAY = 7;
		this.COMMENT = 8;
		
	
    
};