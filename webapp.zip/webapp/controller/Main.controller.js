sap.ui.define([
    "./BaseController",
    "sap/ui/core/mvc/Controller",
    "project3/model/MainService"
], function (BaseController, Controller, MainService) {
    "use strict";

    return BaseController.extend("project3.controller.Main", {
        onInit: function () {
            this.getView().addEventDelegate({
                onAfterRendering: function () {
                    this._injectContent();
                }.bind(this),
            });
        },

        _injectContent: function () {
            // Fetch the placeholder div
            const oVBox = this.byId("containerVBox");
            const domRef = oVBox && oVBox.getDomRef();

            if (!domRef) {
                console.error("VBox DOM reference is not available.");
                return;
            }

            // Dynamically create and inject the HTML content
            const placeholderDiv = document.createElement("div");
            placeholderDiv.id = "shavitDiv";
            domRef.appendChild(placeholderDiv);



            const shadowHost = document.createElement('div');
            shadowHost.id = 'shavit-shadow-root';
            document.body.appendChild(shadowHost);
            
            const shadowRoot = shadowHost.attachShadow({ mode: 'open' });
            fetch('./shavit.html')
                .then(response => response.text())
                .then(html => {
                    shadowRoot.innerHTML = html;
                });
            
       
             
              fetch("./shavit.html")
                .then(response => {
                    if (!response.ok) {
                        throw new Error("Failed to load shavit.html");
                    }
                    return response.text();
                })
                .then(html => {
                    placeholderDiv.innerHTML = html;
                    this._initializeShavitInteractions();
                })
                .catch(error => console.error("Error loading shavit.html:", error));
        },

        _initializeShavitInteractions: function () {
            console.log("Shavit content successfully loaded and initialized.");
        }
    });
});
