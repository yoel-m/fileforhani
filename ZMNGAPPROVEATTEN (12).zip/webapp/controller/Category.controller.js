sap.ui.define([
	'jquery.sap.global',
	'sap/ui/demo/cart/controller/BaseController',
	'sap/ui/demo/cart/model/formatter',
	'sap/ui/Device',
	'sap/ui/model/Filter',
	'sap/ui/model/FilterOperator',
	'sap/m/MessageToast',
	'sap/ui/model/json/JSONModel',
	'sap/ui/demo/cart/model/MngAttendanceService',
	'sap/ui/model/Sorter',
], function (
	$,
	BaseController,
	formatter,
	Device,
	Filter,
	FilterOperator,
	MessageToast,
	JSONModel,
	MngAttendanceService,
	Sorter) {
	"use strict";

	return BaseController.extend("sap.ui.demo.cart.controller.Category", {
		formatter : formatter,
		// Define filterPreviousValues as global variables because they need to be accessed from different functions
		_iLowFilterPreviousValue: 0,
		_iHighFilterPreviousValue: 5000,

		onInit: function () {


			this._oView = this.getView();

			var aData =  {categoryView: this.getView().getId() } ; 
			var viewGlobalModel = new sap.ui.model.json.JSONModel();
			viewGlobalModel.setData(aData);
			sap.ui.getCore().setModel(viewGlobalModel, "categoryViewModel");				
			
			var oViewModel = new JSONModel();
			this.getView().setModel(oViewModel, "empListModel");
			var oComponent = this.getOwnerComponent();
			this._router = oComponent.getRouter();
			
			this._router.getRoute("emplist").attachMatched(this._loadCategories, this);
		   	this._router.getRoute("product").attachMatched(this._loadCategories, this);
		   	
		    
		  
		 //	this.setFirstItemselected() ;
			
		},
		
		refreshList: function(mngPernr){
			var oProductList = this.byId("productList");
			var selectedItem  = oProductList.getSelectedItems();
			
			var monthSelectedValue = sap.ui.getCore().getModel('oSelectedMonthModel').getData().monthSelectedKey ;
			var oView  = this.getView();
			var oService = new MngAttendanceService(oView,false);
		    oService.getDepEmplistRefresh(monthSelectedValue,mngPernr,selectedItem) ;	
			
			
			
		}, 
		
		_loadCategories: function(oEvent) {
			//var oModel = this.getModel();
			var sId = oEvent.getParameter("arguments").Manager;
			/*
			this._loadSuppliers(sId);
			*/
			
			var monthSelectedValue = sap.ui.getCore().getModel('oSelectedMonthModel').getData().monthSelectedKey ;
			var oView  = this.getView();
			var oService = new MngAttendanceService(oView,false);
		    oService.getDepEmplist(monthSelectedValue,sId) ;	
			
			var oProductList = this.byId("productList");
			this._changeNoDataTextToIndicateLoading(oProductList);
			var oBinding = oProductList.getBinding("items");
			oBinding.attachDataReceived(this.fnDataReceived, this);
		
			this._sProductId = oEvent.getParameter("arguments").Manager;
		 	this.handleResetFilters();
		
		},
		getDepEmplistRefreshCallback : function(o) {
			var oView = o.oView;
			var oModel = o.oModel;
			var oSelectedItem = o.oSelectedItem ; 
			var oProductList = this.byId("productList");
			
			oView.setModel(oModel, "empListModel");
			oProductList.setSelectedItemById (oSelectedItem[0].sId);
			
			// ריענון של הכפתורים רק אחרי שרשימת העובדים מתרעננת
			var viewHomeModel = sap.ui.getCore().getModel("productViewModel");	
			var productView  = sap.ui.getCore().byId(viewHomeModel.getData().productView); 
			
			productView.getController().onRefreshButtonState(); 

		},
		getDepEmplistCallback : function(o) {
			var oView = o.oView;
			var oModel = o.oModel;
			
			var olist =  this.getView().byId("productList");
			var selectedItem  = olist.getSelectedItems();

		 	oView.setModel(oModel, "empListModel");
		 	
			var url = window.location.href ; 
			if (url.indexOf('Emp_listSet') == -1 ){
			 	
			 	selectedItem  = olist.getItems()[0] ; 
			 	selectedItem.setSelected (true); 
			 
				var selectedPath = selectedItem.getBindingContextPath() ;
				var selectedObject = oModel.getContext(selectedPath).getObject() ; 
				
				//var oModel = oBindContext.getModel();
				var sCategoryId = selectedObject.ManagerPernr;
				var sProductId = selectedObject.EmpMainPernr;
				this._router.navTo("product", {Manager: sCategoryId, EmpMainPernr: sProductId}, !Device.system.phone); 		 	
		 	}else {
		 		if (selectedItem.length > 0   ){
		 			olist.setSelectedItemById(selectedItem[0].sId);
		 		}else {
				 	selectedItem  = olist.getItems()[0] ; 
				 	selectedItem.setSelected (true); 
				 
					var selectedPath = selectedItem.getBindingContextPath() ;
					var selectedObject = oModel.getContext(selectedPath).getObject() ; 
					
					//var oModel = oBindContext.getModel();
					var sCategoryId = selectedObject.ManagerPernr;
					var sProductId = selectedObject.EmpMainPernr;
					this._router.navTo("product", {Manager: sCategoryId, EmpMainPernr: sProductId}, !Device.system.phone); 			 			
		 		}
		 	}

		},


		
		setFirstItemselected : function( ) {
			var oView = this.getView() ; 
			var oModel =oView.getModel("empListModel");
	
		 	var olist =  this.getView().byId("productList");
		 	var selectedItem  = olist.getItems()[0] ; 
		 	selectedItem.setSelected (true); 


			var selectedPath = selectedItem.getBindingContextPath() ;
			var selectedObject = oModel.getContext(selectedPath).getObject() ; 
			
			//var oModel = oBindContext.getModel();
			var sCategoryId = selectedObject.ManagerPernr;
			var sProductId = selectedObject.EmpMainPernr;
			this._router.navTo("product", {Manager: sCategoryId, EmpMainPernr: sProductId}, !Device.system.phone);
		},

		/**
		 * Craete a unique array of suppliers to be used in the supplier flter option
		 * @private
		 */
		 
		 /*
		_loadSuppliers: function (sId) {
			var oModel = this.getModel();
 			var aFilters = [];

 			var monthSelectedKey = sap.ui.getCore().getModel('oSelectedMonthModel').getData().monthSelectedKey ; 
			var oFilter1 = new Filter("Month", FilterOperator.EQ, monthSelectedKey);
			var oFilter2 = new Filter("ManagerPernr", FilterOperator.EQ, sId );
			aFilters.push(oFilter1);
			aFilters.push(oFilter2);				
			
 
			this.getView().byId("productList").setBusy(true);
			oModel.read("/Emp_listSet",   {
				filters: aFilters,
			 	success: function (oData) {
					var aProducts = oData.results;

















					this.getModel("empListModel").setProperty("/Emp_listSet", aProducts);
					this.getView().byId("productList").setBusy(false);
				 
				}.bind(this)
			});
		},
		*/

		_changeNoDataTextToIndicateLoading: function (oList) {
			var sOldNoDataText = oList.getNoDataText();
			oList.setNoDataText("Loading...");
			oList.attachEventOnce("updateFinished", function() {oList.setNoDataText(sOldNoDataText);});
		},
		
		/*
		fnDataReceived: function() {
			var oList = this.byId("productList");
			var aListItems = oList.getItems();
			aListItems.some(function(oItem) {
				if (oItem.getBindingContext().sPath === "/Products('" + this._sProductId + "')") {
					oList.setSelectedItem(oItem);
					return true;
				}
			}.bind(this));
		},*/


		/**
		 * Event handler to determine which list item is selected
		 * @param {sap.ui.base.Event} oEvent the list select event
		 */
		onProductListSelect : function (oEvent) {
			this._showProduct(oEvent);
		},

		/**
		 * Event handler to determine which sap.m.ObjectListItem is pressed
		 * @param {sap.ui.base.Event} oEvent the sap.m.ObjectListItem press event
		 */
		onProductListItemPress : function (oEvent) {
			this._showProduct(oEvent);
		},

		_showProduct: function (oEvent) {
			var oBindContext;
			/*
			if (sap.ui.Device.system.phone) {
				oBindContext = oEvent.getSource().getBindingContext();
			} else {
				oBindContext = oEvent.getSource().getSelectedItem().getBindingContext();
			}*/
			
			var selectedItem = oEvent.getSource().getSelectedItem() ;
			var selectedPath = selectedItem.getBindingContextPath() ;
			
			var oModel = selectedItem.getModel('empListModel') ;
			
			var selectedObject = oModel.getContext(selectedPath).getObject() ; 
			
			//var oModel = oBindContext.getModel();
			var sCategoryId = selectedObject.ManagerPernr;
			var sProductId = selectedObject.EmpMainPernr;
			this._router.navTo("product", {Manager: sCategoryId, EmpMainPernr: sProductId}, !Device.system.phone);
		},

		/**
		 * Navigation back to home view
		 */
		onNavButtonPress : function () {
			this.getOwnerComponent().myNavBack();
		},

		/**
		 * Navigation to cart view
		 */
		onCartButtonPress :  function () {
			this._router.navTo("cart");
		},

		/** Apply selected filters to the category list and update text and visibility of the info toolbar
		 * @param oEvent {sap.ui.base.Event} the press event of the sap.m.Button
		 * @private
		 */
        _applyFilter : function (oEvent) {
                        var oList = this.byId("productList"),
                                        oBinding = oList.getBinding("items"),
                                        aSelectedFilterItems = oEvent.getParameter("filterItems"),
                                        oCustomFilter =  this._oDialog.getFilterItems()[1],
                                        oFilter,
                                        oCustomKeys = {},
                                        aFilters = [],
                                        aChangeIndFilters = [],
                                        aStsFilters = [],
                                        aEtcFilters = [];
                        
                        // Add the slider custom filter if the user selects some values
                        /*
                        if (oCustomFilter.getCustomControl().getAggregation("content")[0].getValue() !== oCustomFilter.getCustomControl().getAggregation("content")[0].getMin() ||
                                        oCustomFilter.getCustomControl().getAggregation("content")[0].getValue2() !== oCustomFilter.getCustomControl().getAggregation("content")[0].getMax()) {
                                        aSelectedFilterItems.push(oCustomFilter);
                        }*/
                        aSelectedFilterItems.forEach(function (oItem) {
                                        var sFilterKey = oItem.getProperty("key");
                                        
                                        switch (sFilterKey) {
                                                        case "EmpChanged":
                                                                        oFilter = new Filter("EmpChangeInd", FilterOperator.EQ, "X");
                                                                        aChangeIndFilters.push(oFilter);
                                                                        break;

                                                        case "EmpNOTChangeInd":
                                                                        oFilter = new Filter("EmpChangeInd", FilterOperator.EQ, "");
                                                                        aChangeIndFilters.push(oFilter);
                                                                        break;

                                                        case "EmpNotApproved":
                                                                        oFilter = new Filter("EmpTmStatus", FilterOperator.EQ, "0");
                                                                        aStsFilters.push(oFilter);
                                                                        break;
                                                        
                                                        case "EmpApproved":
                                                                        oFilter = new Filter("EmpTmStatus", FilterOperator.EQ, "1");
                                                                        aStsFilters.push(oFilter);
                                                                        break;
                                                        case "MgrApproved":
                                                                        oFilter = new Filter("EmpTmStatus", FilterOperator.EQ, "2");
                                                                        aStsFilters.push(oFilter);
                                                                        break;
                                                        case "MinhalanApproved":
                                                                        oFilter = new Filter("EmpTmStatus", FilterOperator.EQ, "4");
                                                                        aStsFilters.push(oFilter);
                                                                        break;
                                                        /*
                                                        default:
                                                                        oFilter = new Filter("EmpChangeInd", FilterOperator.EQ, sFilterKey);
                                                                        aEtcFilters.push(oFilter);
                                                                        */

                                        }
                        });
                        if (aChangeIndFilters.length > 0) {
                                        aFilters.push(new Filter({filters: aChangeIndFilters}));
                        }
                        if (aStsFilters.length > 0) {
                                        aFilters.push(new Filter({filters: aStsFilters}));
                        }
                        if (aEtcFilters.length > 0) {
                                        aFilters.push(new Filter({filters: aEtcFilters}));
                        }
                        oFilter = new Filter({filters: aFilters, and: true});
                        if (aFilters.length > 0) {
                                        oBinding.filter(oFilter);
                                        this.byId("categoryInfoToolbar").setVisible(true);
                                        var sText = /*this.getResourceBundle().getText("filterByText")*/ ' מסונן לפי: ' ;
                                        var sSeparator = "";
                                        var oFilterKey = oEvent.getParameter("filterCompoundKeys");
                                        var oKeys = $.extend(oFilterKey, oCustomKeys);
                                        for (var key in oKeys) {
                                                        if (oKeys.hasOwnProperty(key)) {
                                                                        if (key == 'EmpChangeInd') {
                                                                                        sText = sText + sSeparator  + 'שינויים ידניים';
                                                                        }else {
                                                                                        sText = sText + sSeparator  + 'סטטוס';
                                                                        }
                                                                        //sText = sText + sSeparator  + this.getResourceBundle().getText(key, [this._iLowFilterPreviousValue, this._iHighFilterPreviousValue]);
                                                                        sSeparator = ", ";
                                                        }
                                        }
                                        this.byId("categoryInfoToolbarTitle").setText(sText);
                        } else {
                                        oBinding.filter(null);
                                        this.byId("categoryInfoToolbar").setVisible(false);
                                        this.byId("categoryInfoToolbarTitle").setText("");
                        }
        },

		
		onOpenViewSettings : function (oEvent) {
			this._getDialogSort().open();
		},
		
		
		_getDialogSort: function () {
			if (!this._oDialogSort) {
				this._oDialogSort = sap.ui.xmlfragment("sap.ui.demo.cart.view.ViewSettingsDialog", this);
				this.getView().addDependent(this._oDialogSort);
			}
			return this._oDialogSort;
		},

		/**
		 * Open the filter dialog
		 */
		onMasterListFilterPressed: function () {
			this._getDialog().open();
		},

		/**
		 * Define and return {sap.ui.xmlfragment}
		 * @private
		 */
		_getDialog: function () {
			 if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("sap.ui.demo.cart.view.MasterListFilterDialog", this);
				this.getView().addDependent(this._oDialog);
		 	}
			return this._oDialog;
		},

		/**
		 * Updates the previous slider values
		 * @param {sap.ui.base.Event} oEvent the press event of the sap.m.Button
		 */
		handleConfirm: function (oEvent) {
			var oCustomFilter = this._getDialog().getFilterItems()[0];
			var oCustomFilter1 = this._getDialog().getFilterItems()[1];
			//var oSlider = oCustomFilter.getCustomControl().getAggregation("content")[0];
			//this._iLowFilterPreviousValue = oSlider.getValue();
			//this._iHighFilterPreviousValue = oSlider.getValue2();
			this._applyFilter(oEvent);
		},
		onConfirmViewSettingsDialog : function (oEvent) {
			var mParams = oEvent.getParameters(),
				sPath,
				bDescending,
				aSorters = [];
			var olist = this.byId("productList");
			// apply sorter to binding
			// (grouping comes before sorting)
			/*
			if (mParams.groupItem) {
				sPath = mParams.groupItem.getKey();
				bDescending = mParams.groupDescending;
				var vGroup = this._oGroupFunctions[sPath];
				aSorters.push(new Sorter(sPath, bDescending, vGroup));
			}*/
			sPath = mParams.sortItem.getKey();
			bDescending = mParams.sortDescending;
			aSorters.push(new Sorter(sPath, bDescending));
			olist.getBinding("items").sort(aSorters);
		},

		/**
		 * Sets the slider values to the previous ones
		 * Updates the filter count
		 */
		handleCancel: function () {
			var oCustomFilter = this._oDialog.getFilterItems()[1];
			var oSlider = oCustomFilter.getCustomControl().getAggregation("content")[0];
			oSlider.setValue(this._iLowFilterPreviousValue).setValue2(this._iHighFilterPreviousValue);
			if (this._iLowFilterPreviousValue > oSlider.getMin() || this._iHighFilterPreviousValue !== oSlider.getMax()) {
				oCustomFilter.setFilterCount(1);
			} else {
				oCustomFilter.setFilterCount(0);
			}
		},

		/**
		 * Updates filter count if there is a change in one of the slider values
		 * @param {sap.ui.base.Event} oEvent the change event of the sap.m.RangeSlider
		 */
		handleChange: function (oEvent) {
			var oCustomFilter = this._getDialog().getFilterItems()[1];
			var oSlider = oCustomFilter.getCustomControl().getAggregation("content")[0];
			var iLowValue = oEvent.getParameter("range")[0];
			var iHighValue = oEvent.getParameter("range")[1];
			if (iLowValue !== oSlider.getMin() || iHighValue !== oSlider.getMax()) {
				oCustomFilter.setFilterCount(1);
			} else {
				oCustomFilter.setFilterCount(0);
			}

		},

		/**
		 * Reset the price custom filter
		 */
		handleResetFilters: function () {
		    if (this._oDialog) {
				var oCustomFilter = this._oDialog.getFilterItems()[0];
				var oCustomFilter1 = this._oDialog.getFilterItems()[1];
			//	var oSlider = oCustomFilter.getCustomControl().getAggregation("content")[0];
			//	oSlider.setValue(oSlider.getMin());
			//	oSlider.setValue2(oSlider.getMax());
			//	oCustomFilter.setFilterCount(0);
			//	oCustomFilter1.setFilterCount(0);
				this.byId("categoryInfoToolbar").setVisible(false);
				this.byId("categoryInfoToolbarTitle").setText("");
				this._oDialog._clearSelectedFilters();
				 
			 }
		}
	});
});