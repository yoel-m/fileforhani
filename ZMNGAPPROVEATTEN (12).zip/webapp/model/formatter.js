"use strict";
  
jQuery.sap.declare("model.formatter");

model.formatter = {

 
		price: function (sValue) {
			var numberFormat = NumberFormat.getFloatInstance({
				maxFractionDigits: 2,
				minFractionDigits: 2,
				groupingEnabled: true,
				groupingSeparator: ".",
				decimalSeparator: ","
			});
			return numberFormat.format(sValue);
		},

		/**
		 * Sums up the price for all products in the cart
		 * @param {object} oCartEntries current cart entries
		 * @return {string} string with the total value
		 */
		totalPrice: function (oCartEntries) {
			var oBundle = this.getResourceBundle(),
				fTotalPrice = 0;

			Object.keys(oCartEntries).forEach(function (sProductId) {
				var oProduct = oCartEntries[sProductId];
				fTotalPrice += parseFloat(oProduct.Price) * oProduct.Quantity;
			});

			return oBundle.getText("cartTotalPrice", [Formatter.price(fTotalPrice)]);
		},
		
	// -----------------------------------------------------------------------------------------------------------------
	//201804 ---> 04/2018	
	formatYYYYMMtoDate : function (sPeriod) {
		return sPeriod.substring(4,6) + "/" + sPeriod.substring(0,4);
	},

	// -----------------------------------------------------------------------------------------------------------------
		todayAsYYYYMMDD : function () {
		
		    var dToday = new Date();
		    var iCurrentYear = dToday.getFullYear();
		    var iCurrentMonth = dToday.getMonth() + 1;
		    var iCurrentDay = dToday.getDate();
	
		    var sToday = 
		    		((iCurrentDay < 10) ? "0" + iCurrentDay.toString() : iCurrentDay.toString()) +
		    	   "/" + 
		    	   ((iCurrentMonth < 10) ? "0" + iCurrentMonth.toString() : iCurrentMonth.toString()) +
		    	   "/" + 
		    	   iCurrentYear.toString();
		    
		    return model.formatter.formatDateToYYYYMMDD(sToday);
		},
		
	// -----------------------------------------------------------------------------------------------------------------
	//01/04/2018 ---> 20180401	
	formatDateToYYYYMMDD : function (sPeriod) {
		return sPeriod.substring(6,10) + sPeriod.substring(3,5) + sPeriod.substring(0,2);
	},
	// -----------------------------------------------------------------------------------------------------------------
	getDefaultPeriod : function() {
		var NUMBER_OF_DAYS_BEFORE_REPLACING_MONTH = 10;
		
		var sMonth;
		
	    var dCurrentDate = new Date();
	    var iCurrentYear = dCurrentDate.getFullYear();
	    var iCurrentMonth = dCurrentDate.getMonth() + 1;
	    var iCurrentDay = dCurrentDate.getDate();
	    
	    if (iCurrentDay<=NUMBER_OF_DAYS_BEFORE_REPLACING_MONTH) {
	    	iCurrentMonth = iCurrentMonth - 1;
    		if (iCurrentMonth == 0) {
				iCurrentMonth = 12;
				iCurrentYear = iCurrentYear - 1;
			}


	    }
		
	    if (iCurrentMonth < 10) {
	    	sMonth = "0" + iCurrentMonth.toString();
	    	
	    } else {
	    	sMonth = iCurrentMonth.toString();
	    }

	    return iCurrentYear.toString() + sMonth;
	},
	/**
	 * Returns the status text based on the product status
	 * @param {string} sStatus product status
	 * @return {string} the corresponding text if found or the original value
	 */
	statusText: function (sStatus) {
		var oBundle = this.getResourceBundle();

		var mStatusText = {
			"A": oBundle.getText("statusA"),
			"O": oBundle.getText("statusO"),
			"D": oBundle.getText("statusD")
		};

		return "O";
	},
	
	EmpTmStatus: function (sStatus) {
		var oBundle = this.getResourceBundle();

		var mStatusText = {
			"A": oBundle.getText("statusA"),
			"O": oBundle.getText("statusO"),
			"D": oBundle.getText("statusD")
		};

		return mStatusText[sStatus] || sStatus;
	},
	EmpTmStatusTxt: function (sStatus) {
		
		if (!sStatus) {
			sStatus = "" ; 
		}
		var stsText ; 
		switch (sStatus) {
		    case "":
		        stsText = "עובד טרם אישר";
		        this.removeStyleClass('mgrApproved');
		        this.removeStyleClass('empApproved');
		        
		        this.addStyleClass('empNotApprove');
		        break;
		    case "0":
		        stsText = "עובד טרם אישר";
		         this.removeStyleClass('mgrApproved');
		         this.removeStyleClass('empApproved');
		          
		         this.addStyleClass('empNotApprove');
		        break;			        
		    case "1":
		        stsText = "עובד אישר";
		         this.removeStyleClass('mgrApproved');
		         this.removeStyleClass('empNotApprove');
		         
		         this.addStyleClass('empApproved');
		        break;
		    case "2":
		        stsText = "מנהל אישר"; 
		        this.removeStyleClass('empApproved');
		        this.removeStyleClass('empNotApprove');
		        
		         this.addStyleClass('mgrApproved');
		        break;
		    case "4":
		        stsText = "מנהלן אישר";
		        this.removeStyleClass('empApproved');
		        this.removeStyleClass('empNotApprove');
		        		        
		         this.addStyleClass('mgrApproved');
		        break;

		}

		return stsText;
	},

	//---------------------------------------------------------------------------
	
	empHasManulyChanged: function(val) {
		if (val != null && val.length > 0) {
			return "img\\Edited_22x22.png" ;
		}else{
			return '' ;
		}
	},
	// -----------------------------------------------------------------------------------------------------------------	  	  
	  	  

	// 080100 --> 08:01
	
	  formatSapToTime : function(val) {
	  	
		  if (val != null && val.length > 0) {
		  	val = val.substr(0,4);
		  	var h = val.substr(0,2);
		  	var m = val.substr(2,4);
		  	
		    return h + ":" + m;
		  }
		  return null;  
	  },
	  
  	// -----------------------------------------------------------------------------------------------------------------
		//20181121 ---> 11/21/2018
		dateAsDDslashMMslashYYYY : function (val) {
			
		  if (val != null && val.length > 0) {
		  	var sDay = val.substr(6,7);
		  	var sMonth = val.substring(4,6);
		  	var sYear = val.substr(0,4);
		  	
		    return sDay + "/" + sMonth + "/" + sYear.toString(); 
		  }
		  return null;  
		},

		
	// -----------------------------------------------------------------------------------------------------------------	  


	  formatSapDate : function(v) {
	        
	        if (v != null ) {
	              v = v.substr(6, 10);
	              var dDate = new Date(v * 1000);
	
	              var iDay = dDate.getDate();
	              var iMonth = dDate.getMonth() + 1;
	              var iYear = dDate.getFullYear();
	
	              var sDay = "";
	              var sMonth = "";
	
	              if (iDay < 10) {
	                    sDay = "0" + iDay.toString();
	              } else {
	                    sDay = iDay.toString();
	              }
	
	              if (iMonth < 10) {
	                    sMonth = "0" + iMonth.toString();
	              } else {
	                    sMonth = iMonth.toString();
	              }
	
	              return sDay + "/" + sMonth + "/" + iYear.toString(); 
	        } else {
	              return "";
	        }
	  },
	  
// -----------------------------------------------------------------------------------------------------------------

		
		/**
		 * Returns the product state based on the status
		 * @param {string} sStatus product status
		 * @return {string} the state text
		 */
	 

		/**
		 * Returns the relative URL to a product picture
		 * @param {string} sUrl image URL
		 * @return {string} relative image URL
		 */
		pictureUrl: function (sUrl) {
			if (sUrl){
				return  sap.ui.require.toUrl(sUrl);
			} else {
				return undefined;
			}
		},

		/**
		 * Returns the footer text for the cart based on the amount of products
		 * @param {object} oSavedForLaterEntries the entries in the cart
		 * @return {string} "" for no products, the i18n text for >0 products
		 */
		footerTextForCart: function (oSavedForLaterEntries) {
			var oBundle = this.getResourceBundle();

			if (Object.keys(oSavedForLaterEntries).length === 0) {
				return "";
			}
			return oBundle.getText("cartSavedForLaterFooterText");
		},

        /**
		 * Checks if one of the collections contains items.
		 * @param {object} oCollection1 First array or object to check
		 * @param {object} oCollection2 Second array or object to check
		 * @return {boolean} true if one of the collections is not empty, otherwise - false.
		 */
		hasItems: function (oCollection1, oCollection2) {
			return !(jQuery.isEmptyObject(oCollection1) && jQuery.isEmptyObject(oCollection2));
		}
}