sap.ui.define([
		"ipa/org/il/zshavit/controller/BaseController"
	], function (BaseController) {
		"use strict";

		return BaseController.extend("ipa.org.il.zshavit.controller.NotFound", {

			/**
			 * Navigates to the worklist when the link is pressed
			 * @public
			 */
			onLinkPressed : function () {
				this.getRouter().navTo("worklist");
			}

		});

	}
);