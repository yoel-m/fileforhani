"use strict";

jQuery.sap.declare("clalit.org.il.ZEssAttendance.constants.MessagePool");

clalit.org.il.ZEssAttendance.constants.MessagePool =  new function() {
	
	this.ERROR_USERDATA_INVALID = "שגיאה בנסיון לשלוף פרטי משתמש";
	this.ERROR_CHECK_DAY_START_BIGGER_THAN_END = "שעת סיום קטנה משעת התחלה";
	this.ERROR_MSG_MISSING_VALUE = "X ערך חסר";
	//this.INFORMATION_MSG_SPLIT_DAY = "במעבר ימים יש לפצל את דיווח הנוכחות עד חצות, וביום למחרת מחצות";
	this.ERROR_WHILE_UPDATING_DATA = "ארעה שגיאה בנסיון לעדכן את הנתונים";
	this.ERROR_CHECK_DAY_MISSING_ORG_UNIT = "חובה להזין יחידה";
	
	this.DIALOG_SAVE_DATA_BTN_CONFIRM = "אישור";
	this.DIALOG_SAVE_DATA_TITLE = "שמירת נתונים";
	this.DIALOG_DATA_FULLY_SAVED = "הנתונים נשמרו בהצלחה";
	this.DIALOG_DATA_PARTLY_SAVED = "הנתונים התקינים נשמרו, נמצאו שגיאות שלא נשמרו במערכת";
	
	this.DIALOG_CONFIRM_DELETE_ROW = "האם ברצונך למחוק שורה זו?"

	
    
};