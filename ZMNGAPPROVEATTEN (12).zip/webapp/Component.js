sap.ui.define([
	'sap/ui/core/UIComponent',
	'sap/ui/demo/cart/model/LocalStorageModel',
	'jquery.sap.global',
	'sap/ui/demo/cart/model/models',
	'sap/ui/model/json/JSONModel',
	'sap/ui/demo/cart/model/formatter', 
	'sap/ui/demo/cart/model/MngAttendanceService'
], function (UIComponent, LocalStorageModel, $, models,JSONModel, formatter, MngAttendanceService) {
	"use strict";

	return UIComponent.extend("sap.ui.demo.cart.Component", {

		metadata: {
			manifest: "json"
		},
		formatter: formatter,
		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * In this function, the device models are set and the router is initialized.
		 * @public
		 * @override
		 */
		init: function () {
			UIComponent.prototype.init.apply(this, arguments);

			// update browser title
			this.getRouter().attachTitleChanged(function(oEvent) {
				var sTitle = oEvent.getParameter("title");
				$(document).ready(function(){
					document.title = sTitle;
				});
			});

			//create and set cart model
			var oCartModel = new LocalStorageModel("SHOPPING_CART", {
				cartEntries: {},
				savedForLaterEntries: {}
			});
			this.setModel(oCartModel, "cartProducts");

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			
			//var oView = this.getView();
			
			var oModelDates = new JSONModel();
			var dCurrentDate = new Date();
			var iCurrentYear = dCurrentDate.getFullYear();
			var iCurrentMonth = dCurrentDate.getMonth() + 1;
			var aDates = [];
			
			for (var i = 0; i <= 11; i++) {
				var oDDBKEntry = {};
				oDDBKEntry.dateKey = iCurrentYear.toString() + (iCurrentMonth < 10 ? "0" + iCurrentMonth.toString() : iCurrentMonth.toString());
				oDDBKEntry.dateText = (iCurrentMonth < 10 ? "0" + iCurrentMonth.toString() : iCurrentMonth.toString()) + "/" + iCurrentYear.toString();
				iCurrentMonth = iCurrentMonth - 1;
				if (iCurrentMonth == 0) {
					iCurrentMonth = 12;
					iCurrentYear = iCurrentYear - 1;
				}
				aDates.push(oDDBKEntry);
			}
			
			
			oModelDates.setData({
				"dates": aDates
			});
			sap.ui.getCore().setModel(oModelDates, "modelDates");	
			
			var monthSelectedValue = model.formatter.getDefaultPeriod();
			var monthSelectedText = model.formatter.formatYYYYMMtoDate(monthSelectedValue);
			sap.ui.getCore().setModel(oSelectedMonthModel, 'oSelectedMonthModel');

			var oSelectedMonthModel = new JSONModel(
				{ "monthSelectedKey" :  monthSelectedValue,
				  "monthSelectedText" : monthSelectedText
				}
			);
			
			sap.ui.getCore().setModel(oSelectedMonthModel, "oSelectedMonthModel");
			
			var oDialogFragment = sap.ui.xmlfragment("sap.ui.demo.cart.fragment.BusyDialog");
			var oBusyDialogModel = new JSONModel({
				"o" : oDialogFragment
			});
			sap.ui.getCore().setModel(oBusyDialogModel, "oBusyDialogModel");


			/*
			var oService = new MngAttendanceService(this,true);
		    oService.getSgiraDate(monthSelectedValue) ;	
		 		*/
			this.getRouter().initialize();
		},



		myNavBack: function () {
			var oHistory = sap.ui.core.routing.History.getInstance();
			var oPrevHash = oHistory.getPreviousHash();
			if (oPrevHash !== undefined) {
				window.history.go(-1);
			} else {
				this.getRouter().navTo("home", {}, true);
			}
		}
	});
});