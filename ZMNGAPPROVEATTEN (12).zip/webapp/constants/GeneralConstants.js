"use strict";

jQuery.sap.declare("sap.ui.demo.cart.constants.GeneralConstants");

sap.ui.demo.cart.constants.GeneralConstants =  new function() {
	
		// for Local running
		//this.SERVER_URL = "http://sapgwdev.clalit.org.il:8021";
		
		//for Remote runnig
		this.SERVER_URL = "";
		
		this.J2EE_SERVER_URL = "";
	
	    this.SERVICE_URL = this.SERVER_URL + "/sap/opu/odata/sap/ZHR_ESS_MENG_REPORTING_SRV";
		//this.TCODE_URL = this.J2EE_SERVER_URL + "/irj/servlet/prt/portal/prtroot/com.sap.portal.appintegrator.sap.Transaction?System=SAP_ERP&GuiType=WebGui&TCode=";
	    this.ERROR_PREFIX =  "--- ";
	    
	    this.DELAY_FOR_FOCUS = 1000; // 1sec
	    
		this.I_APPRV_USER_TYPE = "1";
		this.APPRV_ACTION_TYPE_APPROVE = "1";
		this.APPRV_ACTION_TYPE_REOPEN = "2";
		
	    this.EMPTY_DROPDOWN_KEY = "!!!!";
	    
	    this.SAP_FORMAT_BLANK_DATE = "/Date(-30609792000000)/";
	    this.SAP_FORMAT_BLANK_HOUR = "PT00H00M00S";
	    this.SAP_FORMAT_BLANK_ORG_HOUR = "000000";
	    
	    this.OVERTIME_NULLIFY = "0";
	    
	    this.HELP_URL = "http://homenew.clalit.org.il/sites/Communities/masabey%20enosh/hathum/marachot/sap-Hr/Documents/%D7%9E%D7%93%D7%A8%D7%99%D7%9A%20%D7%9E%D7%A7%D7%95%D7%A6%D7%A8%20%D7%9C%D7%9E%D7%A0%D7%94%D7%9C_%D7%A0%D7%95%D7%9B%D7%97%D7%95%D7%AA%20%D7%A1%D7%90%D7%A4.pdf";
    
};