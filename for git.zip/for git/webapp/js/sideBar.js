/*
document.addEventListener("DOMContentLoaded", () => {
    const panels = [
        { id: "panel1", iconPath: "../../img/bk-1.png" },
        { id: "panel2", iconPath: "../../img/bk-2.png" },
        { id: "panel3", iconPath: "../../img/bk-3.png" }
    ];
    
    panels.forEach(panel => {
        const container = document.getElementById(panel.id);
        if (container) {
            const virtualTable = document.createElement("div");
            virtualTable.classList.add("virtual-table");

            for (let i = 1; i <= 27; i++) {
                const cell = document.createElement("div");
                cell.classList.add("virtual-cell");

                const img = document.createElement("img");
                img.src = panel.iconPath;
                img.alt = `Icon ${i}`;
                img.classList.add("virtual-icon");

                img.addEventListener("click", () => {
                    sideBarIconClick(img, panel.id, i);
                });

                cell.appendChild(img);
                virtualTable.appendChild(cell);
            }

            container.appendChild(virtualTable);
        }
    });
    
    const cells = document.querySelectorAll(".virtual-cell");

    cells.forEach(cell => {
        const icon = cell.querySelector(".virtual-icon");
        const text = cell.querySelector(".icon-text");

        if (icon.src.includes("re_b_l")) {
            cell.classList.add("re");
        } else if (icon.src.includes("gr_b_l")) {
            cell.classList.add("gr");
        } else if (icon.src.includes("bl_b_l")) {
            cell.classList.add("bl");
        }

        const originalSrc = icon.src;
        const hoverSrc = originalSrc.replace("_b_", "_f_");

        cell.addEventListener("mouseover", () => {
            icon.src = hoverSrc;
        });

        cell.addEventListener("mouseout", () => {
            icon.src = originalSrc;
        });
    });
});

function sideBarIconClick(icon, panelId, index) {
    const iconDetails = {
        panel: panelId,
        index: index,
        iconSrc: icon.src,
        altText: icon.alt
    };

    const detailsString = `
        Panel: ${iconDetails.panel}
        Icon Index: ${iconDetails.index}
        Icon Source: ${iconDetails.iconSrc}
        Alt Text: ${iconDetails.altText}
    `;

    alert(detailsString);
}
*/