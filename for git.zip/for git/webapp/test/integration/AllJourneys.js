/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"ipa/org/il/zshavit/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"ipa/org/il/zshavit/test/integration/pages/Worklist",
	"ipa/org/il/zshavit/test/integration/pages/Object",
	"ipa/org/il/zshavit/test/integration/pages/NotFound",
	"ipa/org/il/zshavit/test/integration/pages/Browser",
	"ipa/org/il/zshavit/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "ipa.org.il.zshavit.view."
	});

	sap.ui.require([
		"ipa/org/il/zshavit/test/integration/WorklistJourney",
		"ipa/org/il/zshavit/test/integration/ObjectJourney",
		"ipa/org/il/zshavit/test/integration/NavigationJourney",
		"ipa/org/il/zshavit/test/integration/NotFoundJourney"
	], function () {
		QUnit.start();
	});
});