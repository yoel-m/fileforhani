sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter",
	"sap/m/GroupHeaderListItem",
	"sap/ui/Device",
	"sap/ui/core/Fragment",
	"../model/formatter",
	"sap/m/MessageBox",
	"sap/ui/core/format/DateFormat"
], function (BaseController, JSONModel, Filter, FilterOperator, Sorter, GroupHeaderListItem, Device, Fragment, formatter, MessageBox, DateFormat) {
	"use strict";

	return BaseController.extend("icl.group.com.PurchaseRequsiotions.controller.Master", {

		formatter: formatter,
		userDialogField: "",

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the master list controller is instantiated. It sets up the event handling for the master/detail communication and other lifecycle tasks.
		 * @public
		 */
		onInit : function () {
			// Control state model
			var oList = this.byId("list"),
				oViewModel = this._createViewModel(),
				oFilterModel = this._createFilterModel(),
				oSearchModel = this._createSearchModel(),
				// Put down master list's original value for busy indicator delay,
				// so it can be restored later on. Busy handling on the master list is
				// taken care of by the master list itself.
				iOriginalBusyDelay = oList.getBusyIndicatorDelay();
			
			this.fillSearcHelp();
			this._oList = oList;

		 
			this.setModel(oViewModel, "masterView");
			this.setModel(oFilterModel, "filterModel");
			this.setModel(oSearchModel, "searchModel");
			
			this.getHeaderSet() ; 
			
			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			oList.attachEventOnce("updateFinished", function(){
				// Restore original busy indicator delay for the list
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});
			
			/*
			this.getView().addEventDelegate({
				onBeforeFirstShow: function () {
					this.getOwnerComponent().oListSelector.setBoundMasterList(oList);
				}.bind(this)
			});
			*/
			this.getRouter().getRoute("master").attachPatternMatched(this._onMasterMatched, this);
			this.getRouter().attachBypassed(this.onBypassed, this);
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * After list data is available, this handler method updates the
		 * master list counter
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished : function (oEvent) {
			// update the master list object counter after new data is loaded
			this._updateListItemCount(oEvent.getParameter("total"));
		},

		/**
		 * Event handler for the master search field. Applies current
		 * filter value and triggers a new search. If the search field's
		 * 'refresh' button has been pressed, no new search is triggered
		 * and the list binding is refresh instead.
		 * @param {sap.ui.base.Event} oEvent the search event
		 * @public
		 */
		onSearch : function (oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
				return;
			}

			var sQuery = oEvent.getParameter("query");

			if (sQuery) {
				this._oListFilterState.aSearch = [new Filter("CustomerName", FilterOperator.Contains, sQuery)];
			} else {
				this._oListFilterState.aSearch = [];
			}
			this._applyFilterSearch();

		},

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh : function () {
			this._oList.getBinding("items").refresh();
		},
		
		/*
		closeSearchDialog: function (evt) {
		   var oDialog =  evt.getSource().getParent() ; 
		   oDialog.close() ; 
		   oDialog.destroy() ; 
		},
		
		closeFilerDialog : function (evt) {
		   var oDialog =  evt.getSource().getParent() ; 
		   oDialog.close() ; 
		   oDialog.destroy() ; 
		},
		*/
		
		parseStringToDate : function (str) {
			if (str.indexOf('.') == -1 ){
				var res = str.split("/");	
				var day =  parseInt (res[1]) ;
				var month =  parseInt (res[0]) -1 ;
				var year =  parseInt ("20"+res[2]) ;
				
				return new Date (year, month, day, 0, 0, 0, 0);
			}else {
				var res = str.split(".");	
				var day =  parseInt (res[0]) ;
				var month =  parseInt (res[1]) -1 ;
				var year =  parseInt (res[2]) ;
				
				return new Date ( year, month, day, 0, 0, 0, 0);				
			}
			
		},
		
		onSaveSearchDialog : function (evt) {

			var aFilters = [];

			var oSearchModelData = this.getView().getModel("searchModel").getData() ; 
			var oBundle = this.getView().getModel("i18n").getResourceBundle();
			var sMsg = oBundle.getText("mandatoryParm");
			
			if (!oSearchModelData.searchPR && !oSearchModelData.searchRequisitioner && !oSearchModelData.searchCreatedBy ){
				MessageBox.warning(sMsg);
				return ;
			}else {   
				if (oSearchModelData.bPR.trim().length===0 && oSearchModelData.sRequisitioner.trim().length===0 && oSearchModelData.sCreatedBy.trim().length===0 ) {
					MessageBox.warning(sMsg);
					return ;					
				}
			}
		 
			if (oSearchModelData.searchSystem){
				if (oSearchModelData.sSystem){
					var oFilter1 = new Filter("System", FilterOperator.EQ, this.getView().byId("searchSystem").getSelectedKey());
					aFilters.push(oFilter1);
				}
			}
			if (oSearchModelData.searchPR){
				if (oSearchModelData.bPR && oSearchModelData.ePR ){
					var oFilter2 = new Filter("PrNum", FilterOperator.BT, oSearchModelData.bPR,oSearchModelData.ePR );
					//var oFilter3 = new Filter("PrNum", FilterOperator.LE, oSearchModelData.ePR );
					aFilters.push(oFilter2);
				//	aFilters.push(oFilter3);
				}else {
					if (oSearchModelData.bPR){
						var oFilter2 = new Filter("PrNum", FilterOperator.EQ, oSearchModelData.bPR );
						aFilters.push(oFilter2);						
					}
				}
			}

			if (oSearchModelData.searchDate){
				if (oSearchModelData.bDate && oSearchModelData.eDate ){
					var bd = this.getView().byId("searchFromDate").getDateValue().getTime();
					//this.parseStringToDate(oSearchModelData.bDate) ; 
					var ed =  this.getView().byId("searchToDate").getDateValue().getTime();
					
					var oFilter4 = new Filter("PrDate", FilterOperator.BT, bd, ed );
					aFilters.push(oFilter4);
				}else {
					if (oSearchModelData.bDate){
						//var bd = this.parseStringToDate(oSearchModelData.bDate);
							var bd = this.getView().byId("searchFromDate").getDateValue().getTime();
						var oFilter4 = new Filter("PrDate", FilterOperator.EQ, bd);
						aFilters.push(oFilter4);						
					}
				}
			}			
			
			/*
			if (oSearchModelData.searchDate){
				if (oSearchModelData.bDate && oSearchModelData.eDate ){
					var bd = new Date (oSearchModelData.bDate) ; 
					var ed = new Date (oSearchModelData.eDate) ; 
					
					var oFilter4 = new Filter("PrDate", FilterOperator.BT, bd, ed );
					aFilters.push(oFilter4);
					 
				}
			}	*/		

			if (oSearchModelData.searchStatus){
				if (oSearchModelData.sStatus){
					var oFilter6 = new Filter("ProcStatCode", FilterOperator.EQ, this.getView().byId("searchStatus").getSelectedKey() );
					aFilters.push(oFilter6);
				}
			}		

			if (oSearchModelData.searchStatusApp){
				if (oSearchModelData.sStatusApp){
					var oFilter9 = new Filter("ApprStatCode", FilterOperator.EQ, this.getView().byId("searchStatusApp").getSelectedKey() );
					aFilters.push(oFilter9);
				}
			}				
			
			
			if (oSearchModelData.searchRequisitioner){
				if (oSearchModelData.sRequisitioner){
					var oFilter7 = new Filter("ReqUser", FilterOperator.EQ, oSearchModelData.sRequisitioner );
					aFilters.push(oFilter7);
				}
			}	

			if (oSearchModelData.searchCreatedBy){
				if (oSearchModelData.sCreatedBy){
					var oFilter8 = new Filter("CreatedByUser", 
					FilterOperator.EQ, oSearchModelData.sCreatedBy );
					aFilters.push(oFilter8);
				}
			}	
										
			this.getHeaderSet(aFilters);
			
			/*
			if (oSearchModelData.filterPR){sFiter=sFiter+"Purchase Requisition  ";  }
			if (oSearchModelData.filterDate){ sFiter=sFiter+"Date "; }
			if (oSearchModelData.filterStatus){ sFiter=sFiter+"Status "; }
			if (oSearchModelData.filterRequisitioner){ sFiter=sFiter+"Requisitioner "; }
			if (oSearchModelData.filterCreatedBy){ sFiter=sFiter+"CreatedBy "; }
			*/
 
			
			this.closeDialog(evt) ;
		},
		onSaveFilerDialog : function (evt) {
			var oFilterModelData = this.getView().getModel("filterModel").getData() ; 
			var sFiter = "" ; 
			var aFilters = [];
			if (oFilterModelData.filterSystem){ 
				sFiter=sFiter+"System"; 
				var oFilter1 = new Filter("System", FilterOperator.EQ, this.getView().byId("filterSystem").getSelectedKey());
				aFilters.push(oFilter1);
				
			}
			
			if (oFilterModelData.filterPR){
				if (oFilterModelData.bPR && oFilterModelData.ePR ){
					sFiter==="" ? sFiter=sFiter+"Purchase Requisition" : sFiter=sFiter+",Purchase Requisition  " ;  
					var oFilter2 = new Filter("PrNum", FilterOperator.BT, oFilterModelData.bPR,oFilterModelData.ePR );
					aFilters.push(oFilter2);
				}else {
					if (oFilterModelData.bPR){
						sFiter==="" ? sFiter=sFiter+"Purchase Requisition" : sFiter=sFiter+",Purchase Requisition  " ; 
						var oFilter2 = new Filter("PrNum", FilterOperator.EQ, oFilterModelData.bPR );
						aFilters.push(oFilter2);						
					}					
				}
			}

			if (oFilterModelData.filterDate){
				if (oFilterModelData.bDate && oFilterModelData.eDate ){
					sFiter==="" ? sFiter=sFiter+"Date" : sFiter=sFiter+",Date  " ; 
					
					var bd =  this.getView().byId("filterFromDate").getDateValue();
					var t1 = new Date (bd.getFullYear(), bd.getMonth(), bd.getDate() ,0,0  ,0,0).getTime() ;
					
					var ed =  this.getView().byId("filterToDate").getDateValue();
					var t2 = new Date (ed.getFullYear(), ed.getMonth(), ed.getDate() ,23,59 ,59,999).getTime() ;
					
					var bd = '/Date(' + t1 + ')/' ; 
					var ed = '/Date(' + t2 + ')/' ;
					var oFilter4 = new Filter("PrDate", FilterOperator.BT, bd, ed );
					aFilters.push(oFilter4);
				}else {
					if (oFilterModelData.bDate){
						sFiter==="" ? sFiter=sFiter+"Date" : sFiter=sFiter+",Date  " ; 
						var bd =  this.getView().byId("filterFromDate").getDateValue();
						var t1 = new Date (bd.getFullYear(), bd.getMonth(), bd.getDate() ,0,0  ,0,0).getTime() ;
						var t2 = new Date (bd.getFullYear(), bd.getMonth(), bd.getDate() ,23,59 ,59,999).getTime() ;
					//	var bd = '/Date(' +  this.parseStringToDate(oFilterModelData.bDate).getTime() + ')/' ; 
						var oFilter4 = new Filter("PrDate", FilterOperator.BT, "/Date(" + t1 + ")/" , "/Date("+ t2 +")/");
						aFilters.push(oFilter4);						
					}					
				}
			}			
			/*
			if (oFilterModelData.filterDate){ 
				//sFiter=sFiter+"Date "; 
				sFiter==="" ? sFiter=sFiter+"Date" : sFiter=sFiter+",Date  " ; 
				if (oFilterModelData.bDate && oFilterModelData.eDate ){
					var bd = '/Date(' +  new Date (oFilterModelData.bDate).getTime() + ')/' ; 
					var ed = '/Date(' +  new Date (oFilterModelData.eDate).getTime() + ')/' ; 
					var oFilter4 = new Filter("PrDate", FilterOperator.BT, bd, ed );
					aFilters.push(oFilter4);
				}				
			}*/
			if (oFilterModelData.filterStatus){ 
				//sFiter=sFiter+"Status "; 
				sFiter==="" ? sFiter=sFiter+"Status" : sFiter=sFiter+",Status  " ; 
				var oFilter5 = new Filter("ProcStatCode", FilterOperator.EQ, this.getView().byId("filterStatus").getSelectedKey() );
				aFilters.push(oFilter5);				
			}
			if (oFilterModelData.filterStatusApp){
				//sFiter=sFiter+"Approve Status "; 
				sFiter==="" ? sFiter=sFiter+"Approve Status" : sFiter=sFiter+",Approve Status  " ; 
				var oFilter6 = new Filter("ApprStatCode", FilterOperator.EQ, this.getView().byId("filterStatusApp").getSelectedKey() );
				aFilters.push(oFilter6);				
			}
			if (oFilterModelData.filterRequisitioner){
				//sFiter=sFiter+"Requisitioner "; 
				sFiter==="" ? sFiter=sFiter+"Requisitioner" : sFiter=sFiter+",Requisitioner  " ; 
				var oFilter7 =  new Filter("ReqUser", FilterOperator.EQ, oFilterModelData.sRequisitioner );
				aFilters.push(oFilter7);				
			}
			if (oFilterModelData.filterCreatedBy){ 
				//sFiter=sFiter+"CreatedBy "; 
				sFiter==="" ? sFiter=sFiter+"CreatedBy" : sFiter=sFiter+",CreatedBy  " ; 
				var oFilter8 = new Filter("CreatedByUser", FilterOperator.EQ, oFilterModelData.sCreatedBy );
				aFilters.push(oFilter8);	
			}
			
			if (sFiter.trim()==='') { sFiter = "None" ; }
			
			oFilterModelData.formattedFiltersCombine = sFiter ; 
			this.getView().getModel("filterModel").setData(oFilterModelData) ;
			
			var oList = this.getView().byId("list");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters);			
			
			
			this.closeDialog(evt) ;
		},
		/**
		 * Event handler for the filter, sort and group buttons to open the ViewSettingsDialog.
		 * @param {sap.ui.base.Event} oEvent the button press event
		 * @public
		 */
		onOpenFilterViewSettings : function (oEvent) {
			var sDialogTab = "filter";
			if (oEvent.getSource() instanceof sap.m.Button) {
				var sButtonId = oEvent.getSource().sId;
				if (sButtonId.match("sort")) {
					sDialogTab = "sort";
				} else if (sButtonId.match("group")) {
					sDialogTab = "group";
				}
			}
			// load asynchronous XML fragment
			if (!this.byId("ViewFilterDialog")) {
				Fragment.load({
					id: this.getView().getId(),
					name: "icl.group.com.PurchaseRequsiotions.view.ViewFilterDialog",
					controller: this
				}).then(function(oDialog){
					// connect dialog to the root view of this component (models, lifecycle)
					this.getView().addDependent(oDialog);
					oDialog.addStyleClass(this.getOwnerComponent().getContentDensityClass());
					oDialog.open(sDialogTab);
					//this.onConfirmViewFilterDialog(this.fireConfirm());                         
				}.bind(this));
			} else {
				this.byId("ViewFilterDialog").open(sDialogTab);
			}
		},
		onUserSelectionChange: function (oEvent) {	
	 	//debugger ;
			var selectedObject = oEvent.getSource().getSelectedItem().getBindingContext('usetSetModel').getObject()  ;
			if (this.userDialogField === "requisitioneS") {
				this.getView().getModel("searchModel").getData().sRequisitioner = selectedObject.Bname;
				this.getView().getModel("searchModel").getData().sRequisitionerFName = selectedObject.NameFirst;
				this.getView().getModel("searchModel").getData().sRequisitionerLName = selectedObject.NameLast;
				this.getView().getModel("searchModel").refresh();
			}
			if (this.userDialogField === "createdByS") {
				this.getView().getModel("searchModel").getData().sCreatedBy = selectedObject.Bname;
				this.getView().getModel("searchModel").getData().sCreatedByFName = selectedObject.NameFirst;
				this.getView().getModel("searchModel").getData().sCreatedByLName = selectedObject.NameLast;
				this.getView().getModel("searchModel").refresh();
			}
			if (this.userDialogField === "requisitioneF") {
				this.getView().getModel("filterModel").getData().sRequisitioner = selectedObject.Bname;
				this.getView().getModel("filterModel").getData().sRequisitionerFName = selectedObject.NameFirst;
				this.getView().getModel("filterModel").getData().sRequisitionerLName = selectedObject.NameLast;
				this.getView().getModel("filterModel").refresh();
			}
			if (this.userDialogField === "createdByF") {
				this.getView().getModel("filterModel").getData().sCreatedBy = selectedObject.Bname;
				this.getView().getModel("filterModel").getData().sCreatedByFName = selectedObject.NameFirst;
				this.getView().getModel("filterModel").getData().sCreatedByLName = selectedObject.NameLast;
				this.getView().getModel("filterModel").refresh();
			}	
			//this.closeDialog(oEvent) ;
			this.getView().byId("searchBtnDel").firePress() ;
		},
		onPressSearchUser: function (oEvent) {	
			
			var ctlList = this.getView().byId("userList") ; 
			ctlList.setVisible(true) ; 
			ctlList.setBusy(true) ;
			var aFilters = [];
			var oSearchUserModelData = this.getView().getModel("userSearchModel").getData() ; 

			if (oSearchUserModelData.sFirstName){
				var oFilter1 = new Filter("NameFirst", FilterOperator.EQ, oSearchUserModelData.sFirstName);
				aFilters.push(oFilter1);
			}
			if (oSearchUserModelData.sLastName){
				var oFilter2 = new Filter("NameLast", FilterOperator.EQ, oSearchUserModelData.sLastName);
				aFilters.push(oFilter2);
			}		 
			this.getUserSet(aFilters);
		},
		onOpenSearchViewSettings : function (oEvent) {
			var sDialogTab = "search";
			if (oEvent.getSource() instanceof sap.m.Button) {
				var sButtonId = oEvent.getSource().sId;
				if (sButtonId.match("sort")) {
					sDialogTab = "sort";
				} else if (sButtonId.match("group")) {
					sDialogTab = "group";
				}
			}
			// load asynchronous XML fragment
			if (!this.byId("ViewSearchDialog")) {
				Fragment.load({
					id: this.getView().getId(),
					name: "icl.group.com.PurchaseRequsiotions.view.ViewSearchDialog",
					controller: this
				}).then(function(oDialog){
					// connect dialog to the root view of this component (models, lifecycle)
					this.getView().addDependent(oDialog);
					oDialog.addStyleClass(this.getOwnerComponent().getContentDensityClass());
					oDialog.open(sDialogTab);
					//this.onConfirmViewSearchDialog(this.fireConfirm());                         
				}.bind(this));
			} else {
				this.byId("ViewSearchDialog").open(sDialogTab);
			}
		},
		/**
		 * Event handler called when ViewFilterDialog has been confirmed, i.e.
		 * has been closed with 'OK'. In the case, the currently chosen filters or groupers
		 * are applied to the master list, which can also mean that they
		 * are removed from the master list, in case they are
		 * removed in the ViewFilterDialog.
		 * @param {sap.ui.base.Event} oEvent the confirm event
		 * @public
		 */
		onConfirmViewFilterDialog : function (oEvent) {
			var aFilterItems = oEvent.getParameter("filterItems"),
				aFilters = [],
				aCaptions = [];
			aFilterItems.forEach(function (oItem) {
				switch (oItem.getKey()) {
					case "Shipped":
						aFilters.push(new Filter("ShippedDate", FilterOperator.NE, null));
						break;
					case "NotShipped":
						aFilters.push(new Filter("ShippedDate", FilterOperator.EQ, null));
						break;
					default:
					break;
				}
				aCaptions.push(oItem.getText());
			});
			this._oListFilterState.aFilter = aFilters;
			this._updateFilterBar(aCaptions.join(", "));
			this._applyFilterSearch();
			this._applyGrouper(oEvent);
		},

		/**
		 * Apply the chosen grouper to the master list
		 * @param {sap.ui.base.Event} oEvent the confirm event
		 * @private
		 */
		_applyGrouper: function (oEvent) {
			var mParams = oEvent.getParameters(),
				sPath,
				bDescending,
				aSorters = [];
			// apply sorter to binding
			if (mParams.groupItem) {
				mParams.groupItem.getKey() === "CompanyName" ?
					sPath = "Customer/" + mParams.groupItem.getKey() : sPath = mParams.groupItem.getKey();
				bDescending = mParams.groupDescending;
				var vGroup = this._oGroupFunctions[mParams.groupItem.getKey()];
				aSorters.push(new Sorter(sPath, bDescending, vGroup));
			}
			this._oList.getBinding("items").sort(aSorters);
		},

		/**
		 * Event handler for the list selection event
		 * @param {sap.ui.base.Event} oEvent the list selectionChange event
		 * @public
		 */
		onSelectionChange : function (oEvent) {
			var oList = oEvent.getSource(),
				bSelected = oEvent.getParameter("selected");

			// skip navigation when deselecting an item in multi selection mode
			if (!(oList.getMode() === "MultiSelect" && !bSelected)) {
				// get the list item, either from the listItem parameter or from the event's source itself (will depend on the device-dependent mode).
				this._showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
			}
		},

		/**
		 * Event handler for the bypassed event, which is fired when no routing pattern matched.
		 * If there was an object selected in the master list, that selection is removed.
		 * @public
		 */
		onBypassed : function () {
			this._oList.removeSelections(true);
		},

		/**
		 * Used to create GroupHeaders with non-capitalized caption.
		 * These headers are inserted into the master list to
		 * group the master list's items.
		 * @param {Object} oGroup group whose text is to be displayed
		 * @public
		 * @returns {sap.m.GroupHeaderListItem} group header with non-capitalized caption.
		 */
		createGroupHeader : function (oGroup) {
			return new GroupHeaderListItem({
				title : oGroup.text,
				upperCase : false
			});
		},

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */


		_createViewModel : function() {
			return new JSONModel({
				isFilterBarVisible: false,
				filterBarLabel: "",
				delay: 0,
				titleCount: 0,
				noDataText: this.getResourceBundle().getText("masterListNoDataText")
			});
		},
		onResetFilter: function() {
			var oFilterModel = this._createFilterModel() ; 
			this.setModel(oFilterModel, "filterModel");
		},
		onResetSearch: function() {
			var oFilterModel = this._createSearchModel() ; 
			this.setModel(oFilterModel, "searchModel");
			this.getHeaderSet() ;  
		},
		onSelectAllFilter: function(evt) {
			if ( evt.getSource().getSelected() ){
				var oFilterModelData = this.getView().getModel("filterModel").getData() ; 
				oFilterModelData.filterAll=true;
				oFilterModelData.filterSystem=true;
				oFilterModelData.filterPR=true;
				oFilterModelData.filterDate=true;
				oFilterModelData.filterStatus=true;
				oFilterModelData.filterStatusApp=true;
				oFilterModelData.filterRequisitioner=true;
				oFilterModelData.filterCreatedBy=true;
				this.getView().getModel("filterModel").setData(oFilterModelData) ;
			 
			}else {
				this.onResetFilter() ;	
			}
		},
		onSelectAllSearch: function(evt) {
			if ( evt.getSource().getSelected() ){
				var oSearchModelData = this.getView().getModel("searchModel").getData() ; 
				oSearchModelData.searchAll=true;
				oSearchModelData.searchSystem=true;
				oSearchModelData.searchPR=true;
				oSearchModelData.searchDate=true;
				oSearchModelData.searchStatus=true;
				oSearchModelData.searchStatusApp=true;
				oSearchModelData.searchRequisitioner=true;
				oSearchModelData.searchCreatedBy=true;
				this.getView().getModel("searchModel").setData(oSearchModelData) ;
			 
			}else {
				this.onResetSearch() ;	
			}
		},		
		_createFilterModel: function() {
			return new JSONModel({
				filterAll: false,
				filterSystem: false,
				filterPR: false,
				filterDate: false,
				filterStatus: false,
				filterStatusApp:false,
				filterRequisitioner:false,
				filterCreatedBy:false,
				
				sSystem:"",
				bPR:"", 
				ePR:"", 
				bDate:"",
				eDate:"",
				sStatus:"",
				sStatusApp:"",
				sRequisitioner:"",
				sRequisitionerFName:"",
				sRequisitionerLName:"",
				sCreatedBy:"",
				sCreatedByFName:"",
				sCreatedByLName:"",
				formattedFiltersCombine:"None"
			});
		},

		_createSearchModel: function() {
			return new JSONModel({
				searchAll: false,
				searchSystem: false,
				searchPR: false,
				searchDate: false,
				searchStatus: false,
				searchStatusApp: false,
				searchRequisitioner:false,
				searchCreatedBy:false,
				sSystem:"",
				bPR:"", 
				ePR:"", 
				bDate:"",
				eDate:"",
				sStatus:"",
				sStatusApp:"",
				sRequisitioner:"",
				sRequisitionerFName:"",
				sRequisitionerLName:"",
				sCreatedBy:"",
				sCreatedByFName:"",
				sCreatedByLName:"",
				formattedSearchsCombine:"None"
			});
		},

		_onMasterMatched :  function() {
			//Set the layout property of the FCL control to 'OneColumn'
			this.getModel("appView").setProperty("/layout", "OneColumn");
			this.getView().byId('list').removeSelections() ; 
		},

		/**
		 * Shows the selected item on the detail page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showDetail : function (oItem) {
			var bReplace = !Device.system.phone;
			var oMasterSelectedModel = new JSONModel(oItem.getBindingContext('HeaderSet').getObject()) ; 
			this.getOwnerComponent().setModel (oMasterSelectedModel, "oMasterSelectedModel");
			// set the layout property of FCL control to show two columns
			this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");
			this.getRouter().navTo("object", {
				prNum : oItem.getBindingContext('HeaderSet').getProperty("PrNum"),
				system : oItem.getBindingContext('HeaderSet').getProperty("System")
			}, bReplace);
		},

		/**
		 * Sets the item count on the master list header
		 * @param {int} iTotalItems the total number of items in the list
		 * @private
		 */
		_updateListItemCount : function (iTotalItems) {
			// only update the counter if the length is final
			if (this._oList.getBinding("items").isLengthFinal()) {
				this.getModel("masterView").setProperty("/titleCount", iTotalItems);
			}
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @private
		 */
		
		selectRequisitioneByS: function ( ) {
			this.getView().byId('requisitioneS').fireSelect();
		},
		selectUserCreatedByS : function ( ) {
			this.getView().byId('createdByS').fireSelect();
		},
		
		selectUser : function (evt) {
		 	if (evt.getSource().getSelected() ) {
				this.refreshUserSearchFilds();
				if (this.getView().byId('requisitioneS')) {
					if (evt.getSource().getId() === this.getView().byId('requisitioneS').getId()) {
						this.userDialogField = "requisitioneS" ; 
					}
		 		}
		 		if (this.getView().byId('requisitioneF')) {
					if (evt.getSource().getId() === this.getView().byId('requisitioneF').getId()) {
						this.userDialogField = "requisitioneF" ; 
					}
		 		}
		 		if (this.getView().byId('createdByS')) {
					if (evt.getSource().getId() === this.getView().byId('createdByS').getId()) {
						this.userDialogField = "createdByS" ; 
					}
		 		}
		 		if (this.getView().byId('createdByF')) {
					if (evt.getSource().getId() === this.getView().byId('createdByF').getId()) {
						this.userDialogField = "createdByF" ; 
					}
		 		}
				var sDialogTab = "searchUserDialog";
				if (!this.byId("searchUserDialog")) {
					Fragment.load({
						id: this.getView().getId(),
						name: "icl.group.com.PurchaseRequsiotions.view.searchUserDialog",
						controller: this
					}).then(function(oDialog){
						// connect dialog to the root view of this component (models, lifecycle)
						this.getView().addDependent(oDialog);
						oDialog.addStyleClass(this.getOwnerComponent().getContentDensityClass());
						oDialog.open(sDialogTab);
						//this.onConfirmViewFilterDialog(this.fireConfirm());                         
					}.bind(this));
				} else {
					this.byId("searchUserDialog").open(sDialogTab);
				}
		 	}
		 },
		_applyFilterSearch : function () {
			var aFilters = this._oListFilterState.aSearch.concat(this._oListFilterState.aFilter),
				oViewModel = this.getModel("masterView");
			this._oList.getBinding("items").filter(aFilters, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (aFilters.length !== 0) {
				oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("masterListNoDataWithFilterOrSearchText"));
			} else if (this._oListFilterState.aSearch.length > 0) {
				// only reset the no data text to default when no new search was triggered
				oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("masterListNoDataText"));
			}
		},

		/**
		 * Internal helper method that sets the filter bar visibility property and the label's caption to be shown
		 * @param {string} sFilterBarText the selected filter value
		 * @private
		 */
		_updateFilterBar : function (sFilterBarText) {
			var oViewModel = this.getModel("masterView");
			oViewModel.setProperty("/isFilterBarVisible", (this._oListFilterState.aFilter.length > 0));
			oViewModel.setProperty("/filterBarLabel", this.getResourceBundle().getText("masterFilterBarText", [sFilterBarText]));
		}

	});
});