sap.ui.define([
	'sap/ui/demo/cart/controller/BaseController',
	'sap/ui/demo/cart/model/formatter',
	'sap/ui/model/Filter',
	'sap/ui/model/FilterOperator',
	'sap/ui/model/json/JSONModel',
	'sap/ui/demo/cart/model/MngAttendanceService',
	'sap/ui/demo/cart/constants/MessagePool'
], function (
	BaseController,
	formatter,
	Filter,
	FilterOperator,
	JSONModel,
	MngAttendanceService,
	MessagePool) {
	"use strict";

	return BaseController.extend("sap.ui.demo.cart.controller.Home", {
		formatter : formatter,

		onInit: function () {


			this._oView = this.getView();
			
			var aData =  {homeView: this.getView().getId() } ; 
			var viewModel = new sap.ui.model.json.JSONModel();
			viewModel.setData(aData);
			sap.ui.getCore().setModel(viewModel, "homeViewModel");	
			
			
			/*
			this._oView.attachAfterRendering(function() {
			  // create the filter for UnitsInStock
			  var sPath1 = "Month";
			  var sOperator1 = "EQ";
			  var sValue1 = "201811";
			  var oFilter1 = new sap.ui.model.Filter(sPath1, sOperator1, sValue1);
  
			  var oBinding = this.byId("categoryList").getBinding("items");

			  oBinding.filter( [oFilter1] , true );
			 
			}); 		*/	
			
			var oComponent = this.getOwnerComponent();
			this._router = oComponent.getRouter();
			// trigger first search to set visibilities right
			
			var monthSelectedValue = sap.ui.getCore().getModel('oSelectedMonthModel').getData().monthSelectedKey ;
			var oView  = this.getView();
			var oService = new MngAttendanceService(oView,false);
			
			this.openBusyDialog();
			
		    oService.getMngDep(monthSelectedValue) ;	

			this._router.attachRoutePatternMatched(this._handleRouteMatched, this);
			this._search();
			
			var otbl  = this.byId ('categoryList'); 
			otbl.addEventDelegate({ 
				onAfterRendering: function(o){ 
					$(".sapMListHdr").css({"font-weight":"700", "font-size":"0.8rem"});
				}
			});			
		},



		getMngDepCallback : function(o) {
			var oView = o.oView;
			var oModel = o.oModel;
		//	var oCtrl = oView.getController();
			
			//var oModelData = o.oModel.getData().sgiraDatesModel ;
		//	oModel.setData(oModelData[0]); 
		//	oView.setModel(oModel, "empDetailModel"); 
			/*
			var sgiraDatesModel = new JSONModel( ) ; 
			sgiraDatesModel.setData(oModelData) ; */
		//	sap.ui.getCore().setModel(oModel, "sgiraDatesModel");
		
			// משתמש לא מוגדר היטב במערכת
			if(oModel.getData()[0].EErrorMsg.length > 0){
				var EErrorMsg = oModel.getData()[0].EErrorMsg;
	
	
				//oModel.EMessage;
				var oModelDialog = new JSONModel();
				oModelDialog.setData(
					{
						"dialogTitle" : MessagePool.ERROR_USERDATA_INVALID,             
						"dialogMessage" : EErrorMsg
					}
				);
					
				sap.ui.getCore().setModel(null, "oModelDialog");
				sap.ui.getCore().setModel(oModelDialog, "oModelDialog");
				
				if (!this._oViewDialogConfirm) {
					this._oViewDialogConfirm = sap.ui.xmlfragment("sap.ui.demo.cart.fragment.DialogConfirm", this);
					
				}
				
				if (this._oViewDialogApproveHourReporting) {
				this._oViewDialogApproveHourReporting.close();
				//sap.ui.getCore().setModel(null, "oModelDialog");
				this._oViewDialogApproveHourReporting = null;
				}
	
				this._oViewDialogConfirm.addStyleClass("sapUiSizeCompact").addStyleClass("myDialog");
				this._oViewDialogConfirm.open();
	
			}
			
			else{
			 	oView.setModel(oModel, "MngDepModel");
			 	
			 	var oMngHeaderDetails = new JSONModel(
					{ "NameMng" :  oModel.getData()[0].NameMng}
				);
	
				oView.setModel(oMngHeaderDetails, "mngHeaderDetails");	
				//sap.ui.getCore().setModel(oMngHeaderDetails, "mngHeaderDetails");		
	
			}
			
			this.closeBusyDialog();
		},
		
	// -------------------------------------------------------------------------------------------------------------------------
		onCloseDialogConfirm : function() {
			if (this._oViewDialogConfirm) {
				this._oViewDialogConfirm.close();
				sap.ui.getCore().setModel(null, "oModelDialog");
				this._oViewDialogConfirm = null;
			}

		},
	// -------------------------------------------------------------------------------------------------------------------------
		onSearch: function () {
			this._search();
		},

		onRefresh: function () {
			// trigger search again and hide pullToRefresh when data ready
			var oProductList = this.byId("productList");
			var oBinding = oProductList.getBinding("items");
			var fnHandler = function () {
				this.byId("pullToRefresh").hide();
				oBinding.detachDataReceived(fnHandler);
			}.bind(this);
			oBinding.attachDataReceived(fnHandler);
			this._search();
		},

		_search: function () {
			var oView = this.getView();
			var oProductList = oView.byId("productList");
			var oCategoryList = oView.byId("categoryList");
			var oSearchField = oView.byId("searchField");

			// switch visibility of lists
			/*
			var bShowSearchResults = oSearchField.getValue().length !== 0;
		//	oProductList.setVisible(bShowSearchResults);
			oCategoryList.setVisible(!bShowSearchResults);

			if (bShowSearchResults) {
				this._changeNoDataTextToIndicateLoading(oProductList);
			}
*/

			// filter product list
			/*
			var oBinding = oProductList.getBinding("items");
			if (oBinding) {
				if (bShowSearchResults) {
					var oFilter = new Filter("Name", FilterOperator.Contains, oSearchField.getValue());
					oBinding.filter([oFilter]);
				} else {
					oBinding.filter([]);
				}
			}*/
		},

		_changeNoDataTextToIndicateLoading: function (oList) {
			var sOldNoDataText = oList.getNoDataText();
			oList.setNoDataText("Loading...");
			oList.attachEventOnce("updateFinished", function () {
				oList.setNoDataText(sOldNoDataText);
			});
		},

		onCategoryListItemPress: function (oEvent) {
			/*
			var oBindContext = oEvent.getSource().getBindingContext();
			var oModel = oBindContext.getModel();
	    	var sCategoryId = oModel.getData(oBindContext.getPath()).Manager;
	    	*/
	    	
	    	var selectedObject = oEvent.getParameter("listItem").getBindingContext("MngDepModel").getObject();
	    	var sCategoryId = selectedObject.Manager ; 
	    	
	    	var oMngHeaderDetails = new JSONModel() ; 
	    	oMngHeaderDetails.setData(selectedObject) ;
	    	sap.ui.getCore().setModel(oMngHeaderDetails, "oMngHeaderDetails");

			this._router.navTo("emplist", {Manager: sCategoryId});
		},

		onProductListSelect: function (oEvent) {
			var oItem = oEvent.getParameter("listItem");
			this._showProduct(oItem);
		},

		onProductListItemPress: function (oEvent) {
			var oItem = oEvent.getSource();
			this._showProduct(oItem);
		},

		_showProduct: function (oItem) {
			var oBindContext = oItem.getBindingContext();
			var oModel = oBindContext.getModel();
			var sId = oModel.getData(oBindContext.getPath()).ProductId;
			this._router.navTo("cartProduct", {productId: sId}, !sap.ui.Device.system.phone);
		},

		onNavButtonPress : function () {
			this.getOwnerComponent().myNavBack();
		},

		onCartButtonPress: function () {
			this._router.navTo("cart");
		},
		_handleRouteMatched: function (evt) {
			var a ;
			a= 5;
		},
		
	//---------------------------------------------------------------------------------------------------
		openBusyDialog : function() {
			var oDialogFragment = sap.ui.xmlfragment("sap.ui.demo.cart.fragment.BusyDialog");

			var oBusyDialogModel = sap.ui.getCore().getModel("oBusyDialogModel");
			if (oBusyDialogModel) {
				oDialogFragment = oBusyDialogModel.getData().o;
				oDialogFragment.open();
			}
		},
		
	//---------------------------------------------------------------------------------------------------
		closeBusyDialog : function() {
			var oDialogFragment = sap.ui.xmlfragment("sap.ui.demo.cart.fragment.BusyDialog");
	
			var oBusyDialogModel = sap.ui.getCore().getModel("oBusyDialogModel");
			if (oBusyDialogModel) {
				oDialogFragment = oBusyDialogModel.getData().o;
				oDialogFragment.close();
			}
		},
		
	// -------------------------------------------------------------------------------------------------------------------------
	});
});