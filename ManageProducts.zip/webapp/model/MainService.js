sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/odata/v2/ODataModel",
	], function (Object, JSONModel, ODataModel) {
	"use strict";
	return Object.extend("clalit.org.il.ODataTimeout.model.MainService", {

		// -----------------------------------------------------------------------------------------------------------------
		
		 // TODO: Add metadata (if any)
		 metadata : {
	         properties : {
	        	 //oView : {type : "sap.ui.view"},
	        	 //sUrl  : {type : "string"}
	         }
		 },

		// -----------------------------------------------------------------------------------------------------------------

		 // TODO: init properties (if any) 
		 constructor: function(view,isComponent) {
			 //this.oView = view;
	         //this.bMock = false;
	         //this.bMock = true;
	         //this.sUrl = GeneralConstants.SERVICE_URL;
	         if (!isComponent) {
				this.sUrl = view.getController().getOwnerComponent().getModel().sServiceUrl ; 
			}else{
				this.sUrl = view.getModel().sServiceUrl ; 
			}
		 },

		 // -----------------------------------------------------------------------------------------------------------------
		 
		 setODataTimerOn: function (nTimeout) {
			 return new Promise((resolve, reject) => {
			     setTimeout(() => { reject({timeout: true}); }, nTimeout);
			 });
		},
		 
		// -----------------------------------------------------------------------------------------------------------------
		
		getUserDetails: function() {
			const sUrl =  this.sUrl ; //  "/sap/opu/odata/sap/ZBO_ODATA_BKPF_SRV/";  ;
            return new Promise(function(resolve, reject) {
           
               const oModel = new ODataModel(sUrl);
               
               sap.ui.core.BusyIndicator.show(0);
               oModel.read("/EtOdataSet", {
            	   success: (oData, oResponse)  => resolve({oData, oResponse}),
                   error:   (oError) => reject(oError)
               });
            });           
		}
		
		// -----------------------------------------------------------------------------------------------------------------
	 
	});
});