sap.ui.define([
	"./model/formatter",
	"./model/EmailType",
	"./model/LocalStorageModel",
	"./model/models",
	"./controller/Checkout.controller"
], function() {
	"use strict";
});
