"use strict";
  
jQuery.sap.declare("clalit.org.il.ZEssAttendance.controls.MaterialIcon");
  
sap.ui.core.Control.extend("clalit.org.il.ZEssAttendance.controls.MaterialIcon", {
	  metadata : {
          properties : {
        	  iconName              : {type : "string", defaultValue : ""},        
        	  text                  : {type : "string", defaultValue : ""},
        	  classMaterialIconText : {type : "string", defaultValue : ""},
          },
  		  events : {
  			  "press" : {}
  		  }
	  },
	  
	  
	  onclick : function(evt) {
		  this.firePress();
	  },
	  
	  
	  onAfterRendering : function() {
		  var that = this;
          $("." + that.getId()).click(function() {
          	that.firePress();  
        });
	  },
	  
	  
	  
	  renderer : {
		  render : function(oRm, oControl) {
			  oRm.write("<div>");
			  oRm.write("<div>");
			  oRm.write("<i");
              oRm.writeControlData(oControl);
              oRm.addClass("material-icons");
//            oRm.addClass("orange600");
//            oRm.addClass("md-22");
              oRm.writeClasses();
              oRm.writeStyles();
              oRm.write(">");
              oRm.write(oControl.getIconName());
              //oRm.write("face");
              oRm.write("</i>");
              oRm.write("</div>");
              
              oRm.write("<div style='cursor:pointer' class='" + oControl.getId() + "'>");
              
	              if (oControl.getClassMaterialIconText() !== "") {
	                  oRm.write("<div class='" + oControl.getClassMaterialIconText() + "'>");
	              } else {
	                  oRm.write("<div>");
	              }
	
	             // oRm.write("<div style='font-size:18px;font-family:open sans hebrew' class='materialIconText'>");
	              
	              oRm.write(oControl.getText());
	              oRm.write("</div>");
	              oRm.write("</div>");
              oRm.write("</div>");	              
		  }
	  }
});