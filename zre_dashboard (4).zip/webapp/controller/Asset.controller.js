sap.ui.define([
	"./BaseController",
	 'sap/ui/model/json/JSONModel',
	 'sap/ui/model/FilterOperator',
	'sap/viz/ui5/format/ChartFormatter',
	 'sap/viz/ui5/data/FlattenedDataset',
	 'sap/viz/ui5/api/env/Format'
], function(BaseController,JSONModel,FilterOperator, ChartFormatter,FlattenedDataset,Format) {
	"use strict";

	return BaseController.extend("sap.ui.demo.masterdetail.controller.Asset", {


        onInit: function () {
        	this.getOwnerComponent().getRouter().getRoute("asset").attachPatternMatched(this._onMasterMatched, this);
        },
         _onMasterMatched: function () {
        	this.setGrapshData () ; 
       		this.get_ChargesAndPaymentSet () ; 
         },
		
		get_ChargesAndPaymentSet: function(){
			const entity = "ChargesAndPaymentSet";
			const filters = [
			    { parm: "IvYear", op: FilterOperator.EQ, val: "2009" }  
			];
			this.operateReadEntity(entity,filters).then(function (oModel) {
				const selectedPort = this.getView().byId("ports").getSelectedKey() ; 
				let dt = this.filterJsonArray (oModel.getData(), "Sobjlage" , selectedPort ); 
				dt[0].Totalcharged= parseInt(dt[0].Totalcharged) ; 
				oModel.setData(dt[0]) ; 
				console.log(	oModel.getData()); 
				this.getView().setModel(oModel, "ChargesAndPaymentSetModel") ;
			}.bind(this))
            .catch(function (error) {
                console.log(error);
            });  
		},
        
        

	    setGrapshData: function(){
            Format.numericFormatter(ChartFormatter.getInstance());
            var formatPattern = ChartFormatter.DefaultPattern;

            // Set up the chart properties
            var oVizFrame = this.getView().byId("idVizFrame");
            oVizFrame.setVizProperties({
                plotArea: {
                    dataLabel: {
                        formatString: formatPattern.SHORTFLOAT_MFD2,
                        visible: true,
                        showTotal: false
                    },
                    series: {
                        dataShape: {
                            primaryAxis: ['bar', 'bar'],
                            secondaryAxis: ['bar', 'bar']
                        }
                    }
                },
                valueAxis: {
                    label: {
                        formatString: formatPattern.SHORTFLOAT
                    },
                    title: {
                        visible: false
                    }
                },
                categoryAxis: {
                    title: {
                        visible: false
                    }
                },
                title: {
                    visible: false,
                    text: 'Costs by Week'
                }
            });

            // Load data model
           var dataPath = jQuery.sap.getModulePath("sap.ui.demo.masterdetail", "/localService/mockdata/betterMedium.json");
            
            var oModel = new JSONModel(dataPath);
            this.getView().setModel(oModel);

            // Define dataset and bind it to the VizFrame
            var oDataset = new FlattenedDataset({
                dimensions: [{
                    name: "Week",
                    value: "{Week}"
                }],
                measures: [{
                    name: "Cost1",
                    value: "{Cost1}"
                }, {
                    name: "Cost2",
                    value: "{Cost2}"
                }, {
                    name: "Cost3",
                    value: "{Cost3}"
                }, {
                    name: "Cost4",
                    value: "{Cost4}"
                }],
                data: {
                    path: "/milk"
                }
            });
            oVizFrame.setDataset(oDataset);

            // Add feed items
            var feedValueAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
                uid: "valueAxis",
                type: "Measure",
                values: ["Cost1", "Cost2"]
            });
            var feedValueAxis2 = new sap.viz.ui5.controls.common.feeds.FeedItem({
                uid: "valueAxis2",
                type: "Measure",
                values: ["Cost3", "Cost4"]
            });
            var feedCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
                uid: "categoryAxis",
                type: "Dimension",
                values: ["Week"]
            });

            oVizFrame.removeAllFeeds();
            oVizFrame.addFeed(feedValueAxis);
            oVizFrame.addFeed(feedValueAxis2);
            oVizFrame.addFeed(feedCategoryAxis);
            
        	var sPath = jQuery.sap.getModulePath("sap.ui.demo.masterdetail", "/localService/mockdata/SampleData.json");
			this.oModel = new JSONModel(sPath);
			this.getView().setModel(this.oModel,"t1");
			this.getView().setModel(this.oModel,"t2");
			this.getView().setModel(this.oModel,"t3");	    	
	    }
	    
	    
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf sap.ui.demo.masterdetail.view.Asset
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf sap.ui.demo.masterdetail.view.Asset
		 */
		//	onExit: function() {
		//
		//	}

	});

});