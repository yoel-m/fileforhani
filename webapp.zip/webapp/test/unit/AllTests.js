sap.ui.define([
	"project3/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
