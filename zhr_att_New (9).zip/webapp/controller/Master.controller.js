sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter",
	"sap/m/GroupHeaderListItem",
	"sap/ui/Device",
	"sap/ui/core/Fragment",
	"sap/ui/hani/att/model/formatter",
	"sap/ui/core/format/DateFormat",
	'sap/ui/unified/DateTypeRange',
	'sap/ui/unified/CalendarLegendItem',
	"sap/ui/hani/att/model/MainService",
	"sap/m/MessageToast"
	
		
], function (BaseController, JSONModel, Filter, FilterOperator, Sorter, GroupHeaderListItem, 
		Device, Fragment, formatter, DateFormat,DateTypeRange,CalendarLegendItem, MainService,MessageToast) {
	"use strict";

	return BaseController.extend("sap.ui.hani.att.controller.Master", {
 
		formatter: formatter,

		onInit : function () {
			// Control state model
			
			let oLeg1 = this.byId("legend1");
			oLeg1.addItem(new CalendarLegendItem({
					type : sap.ui.unified.CalendarDayType.Type08 ,
					text : "ימים שאושרו"
				}));
			oLeg1.addItem(new CalendarLegendItem({
					type : sap.ui.unified.CalendarDayType.Type06 ,
					text : "עודכן ע''י מנהלן או העובד"
				}));				
				
			oLeg1.addItem(new CalendarLegendItem({
					type : sap.ui.unified.CalendarDayType.Type13 ,
					text : "ימים עם שעות חסרות"
				}));	
			

			this.getEtTypes() ;
			//this.handleNavigate() ; 
		
			
			
			let oViewModel = this._createViewModel();
		//	oList = this.byId("list"),
				
				// Put down master list's original value for busy indicator delay,
				// so it can be restored later on. Busy handling on the master list is
				// taken care of by the master list itself.
			//	iOriginalBusyDelay = oList.getBusyIndicatorDelay();
			/*	
			this._oGroupFunctions = {
				CompanyName: function (oContext) {
					let sCompanyName = oContext.getProperty("Customer/CompanyName");
					return {
						key: sCompanyName,
						text: sCompanyName
					};
				},

				OrderDate: function (oContext) {
					let oDate = oContext.getProperty("OrderDate"),
						iYear = oDate.getFullYear(),
						iMonth = oDate.getMonth() + 1,
						sMonthName = this._oMonthNameFormat.format(oDate);

					return {
						key: iYear + "-" + iMonth,
						text: this.getResourceBundle().getText("masterGroupTitleOrderedInPeriod", [sMonthName, iYear])
					};
				}.bind(this),

				ShippedDate: function (oContext) {
					let oDate = oContext.getProperty("ShippedDate");
					// Special handling needed because shipping date may be empty (=> not yet shipped).
					if (oDate != null) {
						let iYear = oDate.getFullYear(),
							iMonth = oDate.getMonth() + 1,
							sMonthName = this._oMonthNameFormat.format(oDate);

						return {
							key: iYear + "-" + iMonth,
							text: this.getResourceBundle().getText("masterGroupTitleShippedInPeriod", [sMonthName, iYear])
						};
					} else {
						return {
							key: 0,
							text: this.getResourceBundle().getText("masterGroupTitleNotShippedYet")
						};
					}
				}.bind(this)
			};
			this._oMonthNameFormat = DateFormat.getInstance({ pattern: "MMMM"});

			this._oList = oList;

			// keeps the filter and search state
			this._oListFilterState = {
				aFilter : [],
				aSearch : []
			};
             */
			this.setModel(oViewModel, "masterView");
			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			/*
			oList.attachEventOnce("updateFinished", function(){
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			}); 

			this.getView().addEventDelegate({
				onBeforeFirstShow: function () {
					this.getOwnerComponent().oListSelector.setBoundMasterList(oList);
				}.bind(this)
			}); */
 
			//this.getRouter().getRoute("master").attachPatternMatched(this._onMasterMatched, this);
			this.getOwnerComponent().getRouter().getRoute("master").attachPatternMatched(this._onMasterMatched, this);
			//this.getRouter().attachBypassed(this.onBypassed, this);
		},

		onRefresh : function () {
			//this._oList.getBinding("items").refresh();
		},

		/**
		 * Event handler for the filter, sort and group buttons to open the ViewSettingsDialog.
		 * @param {sap.ui.base.Event} oEvent the button press event
		 * @public
		 */
		 /*
		onOpenViewSettings : function (oEvent) {
			let sDialogTab = "filter";
			if (oEvent.getSource() instanceof sap.m.Button) {
				let sButtonId = oEvent.getSource().sId;
				if (sButtonId.match("sort")) {
					sDialogTab = "sort";
				} else if (sButtonId.match("group")) {
					sDialogTab = "group";
				}
			}
			// load asynchronous XML fragment
			if (!this.byId("viewSettingsDialog")) {
				Fragment.load({
					id: this.getView().getId(),
					name: "sap.ui.hani.att.view.ViewSettingsDialog",
					controller: this
				}).then(function(oDialog){
					// connect dialog to the root view of this component (models, lifecycle)
					this.getView().addDependent(oDialog);
					oDialog.addStyleClass(this.getOwnerComponent().getContentDensityClass());
					oDialog.open(sDialogTab);
				}.bind(this));
			} else {
				this.byId("viewSettingsDialog").open(sDialogTab);
			}
		},
		*/

		/**
		 * Event handler called when ViewSettingsDialog has been confirmed, i.e.
		 * has been closed with 'OK'. In the case, the currently chosen filters or groupers
		 * are applied to the master list, which can also mean that they
		 * are removed from the master list, in case they are
		 * removed in the ViewSettingsDialog.
		 * @param {sap.ui.base.Event} oEvent the confirm event
		 * @public
		 */
		 
		 /*
		onConfirmViewSettingsDialog : function (oEvent) {
			let aFilterItems = oEvent.getParameter("filterItems"),
				aFilters = [],
				aCaptions = [];
			aFilterItems.forEach(function (oItem) {
				switch (oItem.getKey()) {
					case "Shipped":
						aFilters.push(new Filter("ShippedDate", FilterOperator.NE, null));
						break;
					case "NotShipped":
						aFilters.push(new Filter("ShippedDate", FilterOperator.EQ, null));
						break;
					default:
					break;
				}
				aCaptions.push(oItem.getText());
			});
			this._oListFilterState.aFilter = aFilters;
			this._updateFilterBar(aCaptions.join(", "));
			this._applyFilterSearch();
			this._applyGrouper(oEvent);
		},

	    */

		/**
		 * Event handler for the list selection event
		 * @param {sap.ui.base.Event} oEvent the list selectionChange event
		 * @public
		 */
		 /*
		onSelectionChange : function (oEvent) {
			let oList = oEvent.getSource(),
				bSelected = oEvent.getParameter("selected");

			// skip navigation when deselecting an item in multi selection mode
			if (!(oList.getMode() === "MultiSelect" && !bSelected)) {
				// get the list item, either from the listItem parameter or from the event's source itself (will depend on the device-dependent mode).
				this._showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
			}
		},
        */
		/**
		 * Event handler for the bypassed event, which is fired when no routing pattern matched.
		 * If there was an object selected in the master list, that selection is removed.
		 * @public
		 */
		 
		onBypassed : function () {
			this._oList.removeSelections(true);
		},
         
		/**
		 * Used to create GroupHeaders with non-capitalized caption.
		 * These headers are inserted into the master list to
		 * group the master list's items.
		 * @param {Object} oGroup group whose text is to be displayed
		 * @public
		 * @returns {sap.m.GroupHeaderListItem} group header with non-capitalized caption.
		 */
		 /*
		createGroupHeader : function (oGroup) {
			return new GroupHeaderListItem({
				title : oGroup.text,
				upperCase : false
			});
		},
         */
		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */


		_createViewModel : function() {
			return new JSONModel({
				isFilterBarVisible: false,
				filterBarLabel: "",
				delay: 0,
				titleCount: 0,
				noDataText: this.getResourceBundle().getText("masterListNoDataText")
			});
		},

		_onMasterMatched :  function() {
		 
		 	this.getModel("appView").setProperty("/layout", "OneColumn");

			//this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");
		},
		onAfterRendering : function () {
			let  demoClasses = document.querySelectorAll('.sapUiContainer-Narrow');
		 	demoClasses[0].setAttribute('style' , 'width:60%') ; 
		},
		/**
		 * Shows the selected item on the detail page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showDetail : function (oItem) {
			let bReplace = false ; 			// !Device.system.phone;
			// set the layout property of FCL control to show two columns
			this.getModel("appView").setProperty("/layout", "TwoColumnsBeginExpanded");

	    	let diff =  this.calculateTimeDifference (oItem.LclockIn , oItem.LclockOut ) ; 
	    	oItem.diffMain = diff ;       
	    	
	    	diff =  this.calculateTimeDifference (oItem.LtimeIn.replace(':' , '' )  , oItem.LtimeOut.replace(':' , '' )  ) ; 
	    	oItem.diffMan1 = diff ;      

	    	
	    	diff =  this.calculateTimeDifference (oItem.LtimeIn2.replace(':' , '' )  , oItem.LtimeOut2.replace(':' , '' )  ) ; 
	    	oItem.diffMan2 = diff ;
	    	
	    	this.setSelectedRecord(oItem) ; 
			
			/*
			this.getRouter().navTo("object", {
				objectId : oItem.Pdsnr 
			}, bReplace); 
			*/
			this.getOwnerComponent().getRouter()
				.navTo("object",
					{objectId:oItem.Pdsnr },
					!Device.system.phone);
			
		},

 
	    handleCalendarSelect: function (oEvent) {
	    	
	    	let selectedCalendar = this.byId('calendar1' ) ; 
	    	let selectedMonth = selectedCalendar.getStartDate().getMonth()+1 ; 
	    	let oDate = oEvent.getSource().getSelectedDates()[0].getStartDate() ;
	    	let selectedMonthDay = oDate.getMonth()+1 ; 
	    	
	    	/*
	    	if (selectedMonthDay != selectedMonth ) {
	    		MessageToast.show("יש לבחור יום בטווח ימים של החודש הנבחר");
	    		return ; 
	    	}
	    	*/

			//sap.ui.core.BusyIndicator.show();
	    	let oFormatddMMyyyy = sap.ui.core.format.DateFormat.getInstance({pattern: "dd/MM/yyyy", calendarType: sap.ui.core.CalendarType.Gregorian});
	    	let selectedFormattedVal = oFormatddMMyyyy.format(oDate) ; 
 
			let fMounthSelected = this.getFormattedMonthDate(oDate) ; 
			let selectedmounthModel = new JSONModel({date:oDate, formatdDate:selectedFormattedVal }); 
		    this.getView().setModel ( selectedmounthModel, "selectedmounthModel");
			let oSelectedRecord  ;
	    	let SelectedMonthItemsModel = this.getSelectedMonthItems() ; 
	    	let SelectedMonthItems = SelectedMonthItemsModel.getData() ; 
	    	for (let i=0; i<SelectedMonthItems.length; i++) {
	    		if (SelectedMonthItems[i].Ldate  == selectedFormattedVal ){
	    			oSelectedRecord = SelectedMonthItems[i] ; 
	    			break  ; 
	    		}
	    	}
	    	
	    	let absTypeText = this.getAbsTypeVal(oSelectedRecord.AttType) ; 
	    	oSelectedRecord.AttText = absTypeText ; 
	    	
             
	    	
	    	
	    	//this.setSelectedRecord(oSelectedRecord) ; 
	    	this._showDetail (oSelectedRecord) ;

	    	
	    	/*
	    	let oDate = oEvent.getSource().getSelectedDates()[0].getStartDate() ;
	    	let oFormatddMMyyyy = sap.ui.core.format.DateFormat.getInstance({pattern: "dd/MM/yyyy", calendarType: sap.ui.core.CalendarType.Gregorian});
	    	let selectedFormattedVal = oFormatddMMyyyy.format(oDate) ; 
			
			let fMounthSelected = oDate.getMonth()+1 +'' + oDate.getFullYear()  ; 
			if (fMounthSelected.length < 6 ) {
				fMounthSelected = '0' + fMounthSelected ; 
			}
			
			let selectedmounthModel = new JSONModel({date:oDate, formatdDate:selectedFormattedVal }); 
		    this.getView().setModel ( selectedmounthModel, "selectedmounthModel");
		     
			const oCtrl = this;
			const oService = new MainService(this.getView(),false);
			
			let getItms = oService.getEmpDataSet(fMounthSelected); 
			
			getItms.then(function(oODataResult) {
					if ((oODataResult) && (oODataResult.oData)) {
						sap.ui.core.BusyIndicator.hide();
						console.log("Success");
 
						if (oODataResult.oResponse.statusCode == "200") { 
							
							let oModel = new JSONModel(oODataResult.oData.results); 
							let selectedmounthModel =  this.getView().getModel ( "selectedmounthModel").getData().formatdDate ;
						 	let modelData = oODataResult.oData.results ; 

					    	let oSelectedRecord  ;
					    	for (let i=0; i<modelData.length; i++) {
					    		if (modelData[i].Ldate  == selectedFormattedVal ){
					    			oSelectedRecord = modelData[i] ; 
					    			break  ; 
					    		}
					    	}
					    	this.setSelectedRecord(oSelectedRecord) ; 
					    	this._showDetail (oSelectedRecord) ;						 	

							this.getView().setModel ( oModel, "clientModel");
					 	
						} else {
						 
							MessageToast.show(`Status Code ${oODataResult.oResponse.statusCode}`);
						}
						
					} else {
						MessageToast.show("No Data");
					}}.bind(oCtrl))
				.catch(function(oError) {
					sap.ui.core.BusyIndicator.hide();
					if (oError.timeout) {
						MessageToast.show("Error connecting to server, try again");
					} else {
					 
						MessageToast.show(oError.message);
					}}.bind(oCtrl))     ; 
                   */

	    },
	    getFormattedMonthDate: function (oDate) { 
	    	let fMounthSelected = oDate.getMonth()+1 +'';
			if (fMounthSelected.length < 2 ) {
				fMounthSelected = '0' + fMounthSelected ; 
			}			
			fMounthSelected = oDate.getFullYear()  + fMounthSelected ; 
			return fMounthSelected ; 
	    },
	    handleNavigate:  function (evt) {
 	
	    	let oDate  ;
	    	 
			if (evt) {
				oDate = evt.getSource().getStartDate() ; 
			}else {
				//Set the calender one mont back
				oDate = this.byId('calendar1').getStartDate() ;  
				oDate.setMonth(oDate.getMonth() -1 ) ; 
				this.byId('calendar1').displayDate(oDate); 
			}
		 
			oDate.setDate(25) ;
	    	let oFormatddMMyyyy = sap.ui.core.format.DateFormat.getInstance({pattern: "dd/MM/yyyy", calendarType: sap.ui.core.CalendarType.Gregorian});
	    	let selectedFormattedVal = oFormatddMMyyyy.format(oDate) ; 			
		
			oDate.setMonth(oDate.getMonth()+1) ; 
			let fMounthSelected = this.getFormattedMonthDate(oDate) ; 
	 
			let selectedmounthModel = new JSONModel({date:oDate, formatdDate:selectedFormattedVal }); 
		    this.getView().setModel ( selectedmounthModel, "selectedmounthModel");
		     
			const oCtrl = this;
			const oService = new MainService(this.getView(),false);
			
			let getItms = oService.getEmpDataSet(fMounthSelected); 
			
			getItms.then(function(oODataResult) {
				if ((oODataResult) && (oODataResult.oData)) {
					sap.ui.core.BusyIndicator.hide();
	
					if (oODataResult.oResponse.statusCode == "200" ||
					   (oODataResult.oResponse.statusCode === "201") ||
					   (oODataResult.oResponse.statusCode === "202") ||
					   (oODataResult.oResponse.statusCode == "0")
						
						) { 				

						let oModel = new JSONModel(oODataResult.oData.results); 
						this.setSelectedMonthItems(oModel)  ;
						//let selectedmounthModel =  this.getView().getModel ( "selectedmounthModel").getData().formatdDate ;
					 	let modelData = oODataResult.oData.results ; 
					 	this.outOfTherange() ; 
					 	if (modelData.length > 0 ) {
						 	this.updateApproveDateCal(modelData) ; 
						 	this.updateByAdminCal(modelData) ; 
						 	this.updateMissingDateCal(modelData) ; 
					    	let oSelectedRecord  ;
					    	for (let i=0; i<modelData.length; i++) {
					    		if (modelData[i].Ldate  == selectedFormattedVal ){
					    			oSelectedRecord = modelData[i] ; 
					    			break  ; 
					    		}
					    	}
					    	if (oSelectedRecord){
						    	let absTypeText = this.getAbsTypeVal(oSelectedRecord.AttType) ; 
						    	oSelectedRecord.AttText = absTypeText ; 
					    	}
					    	
					    	//this.setSelectedRecord(oSelectedRecord) ; 
					     	this._showDetail (oSelectedRecord) ;
					     		    
					     
					    	
					 	}else {
					 			MessageToast.show("חודש הנבחר עוד לא זמין במערכת");
					 	}
					} else {
						MessageToast.show(`Status Code ${oODataResult.oResponse.statusCode}`);
					}
					
				} else {
					MessageToast.show("No Data");
				}}.bind(oCtrl))
			.catch(function(oError) {
				sap.ui.core.BusyIndicator.hide();
				{
					MessageToast.show(oError.message);
				}
			}.bind(oCtrl)) ;  

	    },
	    getEtTypes : function() {

			const oCtrl = this;
			const oService = new MainService(this.getView(),false);
			
			let getEtTypes = oService.getEtTypesSet(); 
			
			getEtTypes.then(function(oODataResult) {
				if ((oODataResult) && (oODataResult.oData)) {
					sap.ui.core.BusyIndicator.hide();
					
					if (oODataResult.oResponse.statusCode == "200" ||
					   (oODataResult.oResponse.statusCode === "201") ||
					   (oODataResult.oResponse.statusCode === "202") ||
					   (oODataResult.oResponse.statusCode == "0"))
					{ 
						//this.setAbsTypesModel (oODataResult.oData.results);
						let oModel = new JSONModel(oODataResult.oData.results); 
						this.getOwnerComponent().setModel(oModel , "absTypesModel");
						this.handleNavigate() ; 
					} else {
						MessageToast.show(`Status Code ${oODataResult.oResponse.statusCode}`);
					}
				} else {
					MessageToast.show("No Data");
				}}.bind(oCtrl))
			.catch(function(oError) {
				sap.ui.core.BusyIndicator.hide();
				{
					MessageToast.show(oError.message);
				}
			}.bind(oCtrl)) ;  	    	
	    	
	    },      
	    outOfTherange: function() {
 
			let oCal = this.getView().byId('calendar1') ; 
			oCal.removeAllSpecialDates() ; 
			let d =  oCal.getStartDate();
			d.setDate (d.getDate() -1) ;
			for (let i=0; i<24; i++) {
				d.setDate (d.getDate() +1) ;
				oCal.addSpecialDate(new DateTypeRange({
					startDate : new Date(d),
					type : "Type09",
					tooltip : ""
				}));							
			}	 
			d = oCal.getStartDate(); 
			d.setMonth(d.getMonth() + 1);
			d =  new Date(d.getFullYear(), d.getMonth() + 1, 0);
			//d.setDate (d.getDate() +1) ;
		 
			let day = d.getDate() ;  
			while (day>24) {
				oCal.addSpecialDate(new DateTypeRange({
					startDate : new Date(d),
					type : "Type09",
					tooltip : ""
				}));	
				d.setDate (d.getDate() -1) ;
				day = d.getDate() ;  
			}
			/*
			for (let i=0; i<7; i++) {
				d.setDate (d.getDate() -1) ;
				oCal.addSpecialDate(new DateTypeRange({
					startDate : new Date(d),
					type : "Type09",
					tooltip : ""
				}));							
			}*/

			
	    },	 
	    
	    updateApproveDateCal: function(modelData) {
			let foundApproved = modelData.filter(function(item) { return item.Status === '02'; });
			let oCal = this.getView().byId('calendar1') ; 
			
			for (let i=0; i<foundApproved.length; i++) {
				const [day, month, year] = foundApproved[i].Ldate.split('/');
				const oRefDate = new Date(year, month - 1, day);
				oCal.addSpecialDate(new DateTypeRange({
					startDate : new Date(oRefDate),
					type : "Type08",
					tooltip : "אושר"
				}));							
			}	    	
	    },	   

	    updateByAdminCal: function(modelData) {
			let foundUpdateByAdmin = modelData.filter(function(item) { 
				
				return  item.OrigfIn  == 'M' 	||  item.OrigfOut  == 'M' || item.OrigfIn  == 'E' 	||  item.OrigfOut  == 'E' ; 
				
			});
			let oCal = this.getView().byId('calendar1') ; 
			
			for (let i=0; i<foundUpdateByAdmin.length; i++) {
				const [day, month, year] = foundUpdateByAdmin[i].Ldate.split('/');
				const oRefDate = new Date(year, month - 1, day);
				oCal.addSpecialDate(new DateTypeRange({
					startDate : new Date(oRefDate),
					type : "Type06",
					tooltip : "עודכן ע''י מנהלן או העובד" 
				}));							
			}	    	
	    },	    
	    
	    updateMissingDateCal: function(modelData) {
			let foundMiss = modelData.filter(function(item) { 
				
				return parseFloat (item.LclockIn) == '00' 
				|| parseFloat (item.LclockOut) == '00' 
				|| !item.LclockIn || !item.LclockOut; 
				
			});
			let oCal = this.getView().byId('calendar1') ; 
			
			for (let i=0; i<foundMiss.length; i++) {
				const [day, month, year] = foundMiss[i].Ldate.split('/');
				const oRefDate = new Date(year, month - 1, day);
				oCal.addSpecialDate(new DateTypeRange({
					startDate : new Date(oRefDate),
					type : "Type13",
					tooltip : "חסר שעות" 
				}));							
			}	    	
	    }

	});
});

	    	//let surl = ".././localService/mockdata/Att.json" ; 
	    	//let sPath = ".././localService/mockdata/Att.json" ; 
	        //let sPath = "http://localhost:50466/webapp/localService/mockdata/Att.json" ;