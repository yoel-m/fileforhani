window.addEventListener("load", () => {

 
    scaleIcons();
    scaleFooter(); // Ensure footer scales correctly
    window.addEventListener("resize", () => {
        scaleIcons();
        scaleFooter();
    });
    initializeIconEvents();
});
function scaleFooter() {
    const backgroundWrapper = document.querySelector('.background-wrapper');
    const footer = document.querySelector('.footer-strip');
    const baselineWidth = 1000; // The baseline width for the background
    const scaleFactor = backgroundWrapper.clientWidth / baselineWidth;

    // Keep the footer fixed in size regardless of scaling
    const fixedScaleFactor = 1 / scaleFactor; // Inverse of the scaling factor
    footer.style.transform = `scale(${fixedScaleFactor}) translateX(-50%)`;
    footer.style.width = `${baselineWidth}px`; // Match the baseline width
    footer.style.height = `60px !important;`; // Maintain fixed height
}


function scaleIcons() {
    const backgroundWrapper = document.querySelector('.background-wrapper');
    const icons = document.querySelectorAll('.icon');
    const statusBar = document.getElementById('statusBar'); // Handle statusBar separately
    const footerStrip = document.querySelector('.footer-strip'); // Handle footer-strip separately

    const icon45d = document.querySelectorAll('.icon45d');
    const icon90d = document.querySelectorAll('.icon90d');

    // Get the scale factor based on the width of the background-wrapper
    const scaleFactor = backgroundWrapper.clientWidth / 1000; // Max width as baseline

  


    const panelIcons = document.querySelectorAll('.panel-icon');
    panelIcons.forEach(icon => {
        icon.style.transform = `scale(${scaleFactor})`;
    });

    const fixedScaleFactor = 1; // Keep these elements fixed
    footerStrip.style.transform = `scale(${fixedScaleFactor})`; // No scaling for footer
    statusBar.style.transform = `scale(${fixedScaleFactor})`; 

    // Apply the scale factor to each regular icon
    icons.forEach(icon => {
        icon.style.transform = `scale(${scaleFactor})`; // Scale only
    });

    // Apply scaling with rotation to 45-degree icons
    icon45d.forEach(icon => {
        icon.style.transform = `scale(${scaleFactor}) rotate(135deg)`;
    });

    // Apply scaling with rotation to 90-degree icons
    icon90d.forEach(icon => {
        icon.style.transform = `scale(${scaleFactor}) rotate(270deg)`;
    });
}


function initializeIconEvents() {
    let selectedIcon = null;

    // Mapping of background image URLs to text colors

    // B17F22   yellow
    // 267A4C   green
    // 3F6987   gray
    // BC3658   red 
    // 265CBC   blue
    
    const colorMap = {
        '/img/Bakcground@2x-54.png': '#B17F22',
        '/img/Bakcground@2x-58.png': '#B17F22',
        '/img/Bakcground@2x-2.png': '#3F6987',
        '/img/Bakcground@2x-90.png': '#267A4C',
        '/img/Bakcground@2x-6.png': '#267A4C',
        '/img/Bakcground@2x-18.png': '#B17F22',
        '/img/Bakcground@2x-22.png': '#BC3658',
        '/img/Bakcground@2x-46.png': '#267A4C',
        '/img/Bakcground@2x-26.png': '#BC3658',
        '/img/Bakcground@2x-34.png': '#265CBC',
        '/img/Bakcground@2x-74.png': '#265CBC',
        '/img/Bakcground@2x-114.png': '#265CBC',
        '/img/Bakcground@2x-98.png': '#B17F22',
        '/img/Bakcground@2x-10.png': '#267A4C',
        '/img/Bakcground@2x-30.png': '#265CBC',
        '/img/Bakcground@2x-86.png': '#267A4C',
        '/img/Bakcground@2x-106.png': '#BC3658',
        '/img/Bakcground@2x-14.png': '#B17F22',
        '/img/Bakcground@2x-70.png': '#265CBC',
        '/img/Bakcground@2x-42.png': '#3F6987',
        '/img/Bakcground@2x-38.png': '#3F6987',
        '/img/Bakcground@2x-66.png': '#BC3658',
        '/img/Bakcground@2x-104.png': '#BC3658',
        '/img/Bakcground@2x-14.png': '#B17F22',
        '/img/Bakcground@2x-70.png': '#265CBC',
        '/img/Bakcground@2x-42.png': '#3F6987',
        '/img/Bakcground@2x-38.png': '#3F6987',
        '/img/Bakcground@2x-66.png': '#BC3658',
        '/img/Bakcground@2x-78.png': '#3F6987',
        '/img/Bakcground@2x-62.png': '#BC3658',
        '/img/Bakcground@2x-94.png': '#B17F22',
        '/img/Bakcground@2x-82.png': '#3F6987',
        '/img/Bakcground@2x-50.png': '#267A4C',
        '/img/Bakcground@2x-102.png': '#BC3658',
        '/img/Bakcground@2x-110.png': '#265CBC',
        '/img/Frame 1150@3x.png': '#3F6987'

    };

    document.querySelectorAll('.icon-container').forEach(icon => {
        // Use `getComputedStyle` to get the background image
        const computedStyle = window.getComputedStyle(icon);
        const originalBg = computedStyle.backgroundImage;  

        console.log('Computed background image:', originalBg);

        // Extract the relative URL from `backgroundImage`
        const bgUrlMatch = originalBg.match(/url\("(.*)"\)/);
        if (!bgUrlMatch) {
            console.error('Failed to extract URL from backgroundImage:', originalBg);
            return;
        }
        let bgUrl = bgUrlMatch[1];

        // Ensure the URL is relative (remove protocol and host if present)
        const locationOrigin = window.location.origin ; // E.g., "http://localhost:8081"
        if (bgUrl.startsWith(locationOrigin)) {
            bgUrl = bgUrl.replace(locationOrigin, '');
        }

        console.log('Extracted relative URL:', bgUrl);

        // Lookup the corresponding text color
        const originalColor = colorMap[bgUrl ] || 'black'; // Default to black if no match
        console.log('Original color:', originalColor);

        const hoverBg = bgUrl.replace(/@2x-(\d+)/, (_, num) => `@2x-${parseInt(num) + 2}`); // Hover/selected icon URL
        console.log('Hover background URL:', hoverBg);

        // Set initial text color
        icon.style.color = originalColor;

        // Hover behavior
        icon.addEventListener('mouseover', () => {
            if (!icon.classList.contains('icon-selected')) {
                icon.style.backgroundImage = `url("${hoverBg}")`;
                icon.style.color = "white"; // Change text to white on hover
                icon.classList.add('icon-hover');
            }
        });

        icon.addEventListener('mouseout', () => {
            if (!icon.classList.contains('icon-selected')) {
                icon.style.backgroundImage = `url("${bgUrl}")`;
                icon.style.color = originalColor; // Restore original text color
                icon.classList.remove('icon-hover');
            }
        });

        // Double-click behavior
        icon.addEventListener('dblclick', () => {
            // Deselect previous icon
            if (selectedIcon && selectedIcon !== icon) {
                selectedIcon.style.backgroundImage = `url("${selectedIcon.dataset.originalBg}")`;
                selectedIcon.style.color = selectedIcon.dataset.originalColor; // Restore previous icon text color
                selectedIcon.classList.remove('icon-selected');
            }

            // Select the new icon
            selectedIcon = icon;
            selectedIcon.dataset.originalBg = bgUrl; // Save the original background
            selectedIcon.dataset.originalColor = originalColor; // Save the original text color
            selectedIcon.style.backgroundImage = `url("${hoverBg}")`;
            selectedIcon.style.color = "white"; // Change text to white
            selectedIcon.classList.add('icon-selected');
            
      
            // Show a popup with the icon's text
            //alert(`Selected Icon: ${icon.textContent.trim()}`);
        });
    });
}


document.addEventListener("DOMContentLoaded", () => {
    const footer = document.querySelector('.footer-strip');
    const statusBarIcon = document.getElementById("statusBar");
    const iconImg = statusBarIcon.querySelector("img");
    const sideBarContainer = document.getElementById("sideBarContainer");
    const drawer = document.getElementById('floatingDrawer');

    // Function to hide the corresponding icon in shavit.html
    const hideIcon = (iconText) => {
        const iconInShavit = document.getElementById(`icon-${iconText}`);
        if (iconInShavit) {
            iconInShavit.style.display = 'none';
        }
    };

    // Function to handle icon click actions in ship.html
    const handleIconClick = (iconText, message) => {
        const popupTitle = document.getElementById('popup-title').textContent;
        alert(`${message} ${popupTitle}`);
        hideIcon(popupTitle); // Hide the corresponding icon in shavit.html
    };

    // Function to add event listeners to the icons in ship.html after it's loaded
    const addIconEventListeners = () => {
        const windIcon = document.querySelector('img[alt="Wind"]');
        const vectorIcon = document.querySelector('img[alt="Vector"]');
        const islandIcon = document.querySelector('img[alt="Island"]');

        // Add event listeners for the status icons
        if (windIcon) {
            windIcon.addEventListener('click', () => handleIconClick('Wind', 'כלי שייט יצא להפלגה'));
        }

        if (vectorIcon) {
            vectorIcon.addEventListener('click', () => handleIconClick('Vector', 'כלי שייט יצא לתיקון'));
        }

        if (islandIcon) {
            islandIcon.addEventListener('click', () => handleIconClick('Island', 'כלי שייט יצא ליבשה'));
        }
    };

    // Function to load ship.html content into the drawer and add event listeners
    const loadDrawerContent = () => {
        fetch('ship.html')
            .then(response => response.text())
            .then(html => {
                drawer.innerHTML = html; // Load the HTML content into the drawer

                // Once the content is loaded, add event listeners to the icons
                addIconEventListeners(); 
            })
            .catch(err => {
                console.warn('Error loading ship.html:', err);
            });
    };

    // Load ship.html content into the drawer when required
    loadDrawerContent();

    // Function to enforce fixed sizes for footer and status bar icon
    const enforceFixedSize = () => {
        footer.style.height = "60px";
        footer.style.width = "100%";
        statusBarIcon.style.width = "50px";
        statusBarIcon.style.height = "50px";
        iconImg.style.width = "50px";
        iconImg.style.height = "50px";
    };

    // Function to load the sidebar dynamically
    const loadSideBar = () => {
        fetch('sideBar.html')
            .then(response => {
                if (!response.ok) {
                    throw new Error(`Failed to load sidebar: ${response.statusText}`);
                }
                return response.text();
            })
            .then(html => {
                sideBarContainer.innerHTML = html;

                const sideBar = document.getElementById("sideBar");
                const closeSideBar = document.getElementById("closeSideBar");

                // Open sidebar on status bar icon click
                statusBarIcon.addEventListener("click", () => {
                    sideBar.style.right = "0";
                });

                // Close sidebar on close button click
                closeSideBar.addEventListener("click", () => {
                    sideBar.style.right = "-321px";
                });
            })
            .catch(err => console.error(`Error loading sidebar: ${err}`));
    };

    // Initialize functionality
    enforceFixedSize();
    window.addEventListener("resize", enforceFixedSize);
    loadSideBar();
});

function windClick() {
    
    const iconId = localStorage.getItem('iconId');
    if (iconId) {
        hideIconInShavit(iconId);
    }
}

function vectorClick()  {
    
    const iconId = localStorage.getItem('iconId');
    if (iconId) {
        hideIconInShavit(iconId);
    }
}

function islandClick()  {
    
    const iconId = localStorage.getItem('iconId');
    if (iconId) {
        hideIconInShavit(iconId);
    }
}

function hideIconInShavit(iconId) {
    const iconInShavit = document.getElementById(iconId);
    if (iconInShavit) {
        iconInShavit.style.display = 'none';
    }
}

function initializePanelIconEvents() {
    const panelIcons = document.querySelectorAll('.panel-icon');

    panelIcons.forEach(icon => {
        // Add hover effects
        icon.addEventListener('mouseover', () => {
            icon.style.transform = 'scale(1.1)';
        });

        icon.addEventListener('mouseout', () => {
            icon.style.transform = 'scale(1)';
        });

        // Double-click functionality
        icon.addEventListener('dblclick', () => {
            alert(`Selected Panel Icon: ${icon.dataset.name || 'Unknown'}`);
        });

        // Add text below the icon
        const textElement = document.createElement('div');
        textElement.classList.add('panel-icon-text');
        textElement.innerText = icon.dataset.name || 'Default Name'; // Use dataset for dynamic naming
        icon.appendChild(textElement);
    });
}


function openDrawer(icon, id) {
    const iconText = icon.innerText || icon.textContent; // Get the text from the clicked icon
						  

    // Open the popup and pass the ID of the clicked icon
   // loadDrawerContent(id);   
    localStorage.setItem('iconId', id);		

    const iconRect = icon.getBoundingClientRect();
    const drawer = document.getElementById('floatingDrawer');

    // Position the drawer next to the icon
    const windowWidth = window.innerWidth;
    const windowHeight = window.innerHeight;

    let drawerLeft = iconRect.right + 10;
    let drawerTop = iconRect.top;

    if (drawerLeft + drawer.offsetWidth > windowWidth) {
        drawerLeft = iconRect.left - drawer.offsetWidth - 10;
    }

    if (drawerTop + drawer.offsetHeight > windowHeight) {
        drawerTop = iconRect.top - drawer.offsetHeight - 10;
    }

    drawer.style.top = `${drawerTop}px`;
    drawer.style.left = `${drawerLeft}px`;

    drawer.classList.add('open');
    drawer.style.display = 'block';  // Ensure the drawer is visible
}

function loadDrawerContent(iconId) {
	 localStorage.setItem('iconId', iconId);									   

    fetch('ship.html')
        .then(response => response.text())
        .then(html => {
            const drawer = document.getElementById('floatingDrawer');
            drawer.innerHTML = html;
        })
        .catch(err => console.warn('Error loading ship.html:', err));
}


function hideIconInShavit(iconId) {
    const iconInShavit = document.getElementById(iconId);
    if (iconInShavit) {
        iconInShavit.style.display = 'none';  // Hide the icon in shavit.html
    }
}


/*

function openDrawer(icon,id) {
    const iconText = icon.innerText || icon.textContent; // Get the text from the clicked icon

     
    const iconRect = icon.getBoundingClientRect();
    const drawer = document.getElementById('floatingDrawer');

    
    const windowWidth = window.innerWidth;
    const windowHeight = window.innerHeight;

    let drawerLeft = iconRect.right + 10;  
    let drawerTop = iconRect.top;  

     
    if (drawerLeft + drawer.offsetWidth > windowWidth) {
        drawerLeft = iconRect.left - drawer.offsetWidth - 10;  
    }
 
    if (drawerTop + drawer.offsetHeight > windowHeight) {
        drawerTop = iconRect.top - drawer.offsetHeight - 10;  
    }

    
    drawer.style.top = `${drawerTop}px`;
    drawer.style.left = `${drawerLeft}px`;

     
    loadDrawerContent(iconText);

     
    drawer.classList.add('open');
    drawer.style.display = 'block'; 
} */

function loadDrawerContent(iconText) {
    const drawer = document.getElementById('floatingDrawer');

    // Use AJAX or Fetch to load the content from ship.html
    fetch('ship.html')
        .then(response => response.text())
        .then(html => {
            // Insert the content from ship.html into the floating drawer
            drawer.innerHTML = html;

            // Optionally, update the title dynamically based on the clicked icon's text
            const popupTitle = document.getElementById('popup-title');
            popupTitle.textContent = iconText; // Set the drawer title to the icon's text
        })
        .catch(err => {
            console.warn('Error loading ship.html:', err);
        });
}



// Function to close the floating drawer
function closeDrawer() {
    const drawer = document.getElementById('floatingDrawer');
    drawer.classList.remove('open');
    drawer.style.display = 'none'; // Hide the drawer
}
document.addEventListener('click', function(event) {
    const drawer = document.getElementById('floatingDrawer');
    const iconContainer = document.querySelector('.background-container');
    
    // Close the drawer if the click is outside the icon or drawer
    if (!drawer.contains(event.target) && !iconContainer.contains(event.target)) {
        closeDrawer();
    }
});

 
document.addEventListener('DOMContentLoaded', initializePanelIconEvents);
