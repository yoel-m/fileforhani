sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"clalit/org/il/ZEssAttendance/model/service/EssAttendanceService",
	"sap/ui/model/json/JSONModel",
	"clalit/org/il/ZEssAttendance/util/Formatter",
	"sap/ui/core/ValueState",
	"clalit/org/il/ZEssAttendance/constants/MessagePool",
	"clalit/org/il/ZEssAttendance/constants/TableCells",
	"clalit/org/il/ZEssAttendance/common/CommonUtils",
	"clalit/org/il/ZEssAttendance/constants/GeneralConstants",
	"sap/m/Dialog",
	"sap/m/Label",
	"sap/m/LabelDesign",
	"sap/m/Button",
	"sap/ui/table/Table",
	"sap/ui/table/Column"

], function(Controller, EssAttendanceService, JSONModel, Formatter, ValueState, MessagePool, TableCells, CommonUtils, GeneralConstants, Dialog, Label, LabelDesign, Button, Table, Column) {
	"use strict";
	return Controller.extend("clalit.org.il.ZEssAttendance.controller.Main", {
		onInit: function() {
			var oView = this.getView();
			var oCtrl = this;
	
			// Set clalit Images
		    var oClalitLogo = oView.byId("clalitLogoImg");
		    oClalitLogo.setSrc("./" + window.clalitEssAttendanceAppVer + "/images/ClalitLogo.png");
			
			var oClalitIconImg = oView.byId("clalitIconImg");
			oClalitIconImg.setSrc("./" + window.clalitEssAttendanceAppVer + "/images/time-reporting-icon.png");
			 
			var showHoursBtn = oView.byId("showHours");
			showHoursBtn.setIcon("./" + window.clalitEssAttendanceAppVer + "/images/ShowHours.png");
		
			var mClockIn = oView.byId("mClockIn");
			mClockIn.setSrc("./" + window.clalitEssAttendanceAppVer + "/images/Edited_22x22.png");
			
			var mClockOut = oView.byId("mClockOut");
			mClockOut.setSrc("./" + window.clalitEssAttendanceAppVer + "/images/Edited_22x22.png");
			
			this.buildMonthListSelect();
			
			// var oMonthDDBK = oView.byId("monthSelectList");
			// var sPeriod = oMonthDDBK.getSelectedKey();
		
			// // שליפת נתוני משתמש מכסות ודיווחי שעות
			// var oService = new EssAttendanceService(this.getView());
			// oService.getEmloyeeDataAndAttendance( sPeriod);
			this.refreshHoursTable();


	   
	   // ------------------------------------------------------------------------------------------------------------------
			// טיפול ביישור לימין
			var oUserDetailsForm = oView.byId("userDetailsForm");
			oUserDetailsForm.addEventDelegate({
				onAfterRendering: function() {
					oUserDetailsForm.$().find('label').attr({"style" : 'text-align: right!important;content: "no-close-quote" !important;'});
					oUserDetailsForm.$().find('text').attr({"style" : 'text-align: right!important;'});
					oUserDetailsForm.$().find('title').attr({"style" : 'font-family: "Open Sans Hebrew";'});
				}
			}, oUserDetailsForm);
			

			// טיפול בשדות הזנה בתוך הטבלה שיהיו ללא המסגרת
			var oTable = oView.byId("mainTable");
			oTable.setBusy(true);
			//oTable.setBusyIndicatorDelay(10);
		
			oTable.addEventDelegate({
				onAfterRendering: function() {
					oTable.$().find('input').attr({"style" : 'border: none!important; hover: none'});
					oTable.$().attr({"style" : 'width: 100% !important'});
					
					// טיפול בגלילת טבלה
				    $("#" + oCtrl.byId("mainTable").getId() + "-vsb").scroll(function() {
					  oCtrl.handleRows(true);
					  oCtrl.markCheckBeforeSaveErrorsRows();
		        	  oTable.$().attr({"style" : 'width: 100% !important'});

             		});
				
				}
			}, oTable);


	// -------------------------------------------------------------------------------------------------------------------------
	
		// var oMessageStrip = this.getView().byId("message"); 
		
		// oMessageStrip.addEventDelegate({
		// 	onAfterRendering: function() {
		// 		oMessageStrip.setText(MessagePool.INFORMATION_MSG_SPLIT_DAY);
		// 		}
		// 	}, oMessageStrip);
			
	},//end onInit

		
	//-------------------------------------------------------------------------------------------------------------
		getUserDataCallback: function(o) {
			var oModel = o.oModel;
			
			if (oModel !== undefined) {

				// נתוני מערכת כותרת - חודש פתוח או סגור,  סוג משתשמש
				var oUserHeaderData = oModel.getData();
				var oModelUserHeaderData = new JSONModel();
				
				oModelUserHeaderData.setData({
					"mainPernr" : oUserHeaderData.EMainPernr,
					"isEmpMultiPosition" : oUserHeaderData.EEmpType === "C" ? true : false,
					"isMonthOpen" : oUserHeaderData.EStatusSgira === "X" ? true : false,
					"isMonthOpenText" : oUserHeaderData.EPortalStatus ,
					"totalMonth" : oUserHeaderData.ETmTotal,
					"statusMonth" : oUserHeaderData.ETmStatus,
					"dateSgiraHSource" : oUserHeaderData.EDateSgirah,
					"dateSgira" : util.Formatter.formatSapDate(oUserHeaderData.EDateSgiram),
					"dateSgiraSource" : oUserHeaderData.EDateSgiram,
					"dateSgiraEmpSource" : oUserHeaderData.EDateSgiraemp,
					"dateSgiraStartMngSource" : oUserHeaderData.EDateStartMng,
					"dateSgiraEndMngSource" : oUserHeaderData.EDateEndMng
					
				});
				
				//משתמש לא פעיל בנוכחות	
				if(oUserHeaderData.EEmpType === 'X')	{
					console.log(MessagePool.ERROR_USERDATA_INVALID);
					this.openDialog("E", MessagePool.ERROR_USERDATA_INVALID);
				}
				
				this.getView().setModel(oModelUserHeaderData, "oModelUserHeaderData");
				//נתוני משתמש תצוגתיים - שורה ראשונה
				var oUserData = oModel.getData().headerempnav.results[0];
				var oModelEmpData = new JSONModel();

				oModelEmpData.setData({
					"pernr": oUserData.Pernr,
					"userID": oUserData.Idnumber,
					"userCard": oUserData.TmId,
					"userName": oUserData.Ename,
					"orgText": oUserData.Orgtx,
					"site": oUserData.WerksText,
					"parentSite": oUserData.Zem,
					"sector": oUserData.BtrtlText,
					"position": oUserData.Postx,
					"wrkGroup": oUserData.PersgText,
					"wrkSubGroup": oUserData.PerskText,
					"wrkStartDate": util.Formatter.formatSapDate(oUserData.TchilatAvoda)
					
				});
				
				//נתוני משתמש תצוגתיים - כל השורות- - משתמש רב מינוי או רב שיבוץ
				var oUserDataTable = oModel.getData().headerempnav.results;
				var oModelEmpDataTable = new JSONModel();

				// ----- שורות -----
				var oRow = {};
				var aRow = [];
				var oRowSource = {};

				for (var i=0; i<oUserDataTable.length; i++) {
					oRowSource = oUserDataTable[i];
					oRow = {};
					
					oRow.pernr = oRowSource.Pernr;
					oRow.userID = oRowSource.Idnumber;
					oRow.userCard = oRowSource.TmId;
					oRow.userName = oRowSource.Ename;
					oRow.orgUnit = oRowSource.Orgeh;
					oRow.orgText = oRowSource.Orgtx;
					oRow.site = oRowSource.Werks;
					oRow.siteText = oRowSource.WerksText;
					oRow.parentSite = oRowSource.Zem;
					oRow.sector = oRowSource.BtrtlText;
					oRow.position = oRowSource.Postx;
					oRow.wrkGroup = oRowSource.PersgText;
					oRow.wrkSubGroup = oRowSource.PerskText;
					oRow.isEmpMultiAssignment = oRowSource.MultiAssignment === "X" ? true : false;
					
					aRow.push(oRow);
				}

				oModelEmpDataTable.setData({"lines" : aRow});	


				this.getView().setModel(oModelEmpDataTable, "oModelEmpDataTable");// משתמש רב מינוי או רב שיבוץ
				this.getView().setModel(oModelEmpData, "oModelEmpData");

				//קביעה מה סוג המשתמש: רגיל, רב מינוי או רב שיבוץ
				this.isEmpMultiPositionOrAssignment();
				
				// נתוני מכסות עובד
				var oEmpQuotaData = oModel.getData().headerquatanav.results[0];
				var oModelEmpQuotaData = new JSONModel();

				oRow = {};
				aRow = [];
					
				oRow = {};	
				oRow.entitleType = "מכסה";
				oRow.vacation = oEmpQuotaData.VacationCov;
				oRow.sick = oEmpQuotaData.SicknessCov;
				oRow.training = oEmpQuotaData.TrainingCov;
				aRow.push(oRow);
				
				oRow = {};
				oRow.entitleType = "ניצול";
				oRow.vacation = oEmpQuotaData.VacationUse;
				oRow.sick = oEmpQuotaData.SicknessUse;
				oRow.training = oEmpQuotaData.TrainingUse;
				aRow.push(oRow);
				
				oRow = {};
				oRow.entitleType = "יתרה";
				oRow.vacation = oEmpQuotaData.VacationRest;
				oRow.sick = oEmpQuotaData.SicknessRest;
				oRow.training = oEmpQuotaData.TrainingRest;
				aRow.push(oRow);

				oModelEmpQuotaData.setData({"lines" : aRow});
				
				
				//טבלת נתוני סטאטוס עובד לכל המופעים
				
				var oTableStatus = oModel.getData().Tm_statusnav.results;
				var oModelStatusTable = new JSONModel();
				// ----- שורות -----
				oRow = {};
				aRow = [];
				oRowSource = {};

				for (i=0; i<oTableStatus.length; i++) {
					oRowSource = oTableStatus[i];
					oRow = {};
					
					oRow.pernr = oRowSource.Orgunit;
					oRow.orgUnit = oRowSource.Orgunit;
					oRow.status = oRowSource.Status;
					oRow.statusText = oRowSource.StatusText;
					
					aRow.push(oRow);
				}
				
				oModelStatusTable.setData({"lines" : aRow});
				
				this.getView().setModel(oModelStatusTable, "oModelStatusTable");	
								
				//טיפול במצב תצוגה ועריכה
				this.isTblEditabled();
				
				//נתוני טבלת דיווח השעות
				var oTableData = oModel.getData().header_linesnav.results;
				var oModelEmpAttendanceTable = new JSONModel();
					// ----- שורות -----
					oRow = {};
					aRow = [];
					oRowSource = {};
					
					for (i=0; i<oTableData.length; i++) {
						oRowSource = oTableData[i];
						oRow = {};
						oRow.pernr = oRowSource.Pernr;
						oRow.dateReport = util.Formatter.formatSapDate(oRowSource.Ldate);
						oRow.dateReportSource = oRowSource.Ldate;
						
						//במידה ויש חג נרצה להציג את תיאור החג במקום תיאור היום בשבוע
						if(oRowSource.DayType != "" && oRowSource.DayType.length > 0){
							oRow.dayDesc = oRowSource.DayType;
						}
							
						else{
							oRow.dayDesc = oRowSource.DayText;
						}
							
						oRow.werksTxt = oRowSource.WerksText;
						
						this.isEmpMultiPositionOrAssignmentPerLine(oRow, oRowSource.Pernr);
						
						//בניית רשימת יחידות לבחירה
						var aEmpDataSource = oModelEmpDataTable.getData();
						var aOrgUnits = [];
						
						var oOrgUnits = {};
						
						//ערך ריק ברשימת יחידות מוצג רק לרב שיבוץ היות ואצל רב מינוי הוא חייב להיות מלא כי כך נבחר המספר עובד
						if(oRow.isEmpMultiAssignmentPerRow){
							oOrgUnits.orgUnitKey = GeneralConstants.EMPTY_DROPDOWN_KEY;
							oOrgUnits.orgUnitText = "";
							aOrgUnits.push(oOrgUnits);
						}
						
						for (var k=0; k<aEmpDataSource.lines.length; k++) {
							
							oOrgUnits = {};
							//רב מינוי - הקוד הוא מספר עובד
							if(oRow.isEmpMultiPositionDisplayPerRow){
								oOrgUnits.orgUnitKey = aEmpDataSource.lines[k].pernr;
							}
							//רב שיבוץ - הקוד הוא קוד יחידה
							else{
								oOrgUnits.orgUnitKey = aEmpDataSource.lines[k].orgUnit;
							}
						
							oOrgUnits.orgUnitText = aEmpDataSource.lines[k].orgText;
				
							aOrgUnits.push(oOrgUnits);
						}
						
						oRow.itemsOrgUnits = aOrgUnits;
						
						oRow.orgUnit = oRowSource.Orgunit;
						oRow.orgUnitTxt = oRowSource.OrgunitTxt;
						
						oRow.pernrKey = oRowSource.PernrKey;
						oRow.orgIn = oRowSource.OrgIn;
						oRow.orgOut = oRowSource.OrgOut;
						
						// האם מדובר על שורת נוכחות
						if(oRowSource.AttAbsNum.length === 0 || oRowSource.AttAbsNum === ""){
							oRow.clockInDisplay = util.Formatter.formatSapToTime(oRowSource.Begtm);
							oRow.clockOutDisplay = util.Formatter.formatSapToTime(oRowSource.Endtm);
						}
						//העדרות
						else{
							oRow.clockInDisplay = util.Formatter.formatSapToTime(oRowSource.StartAbs);
							oRow.clockOutDisplay = util.Formatter.formatSapToTime(oRowSource.EndAbs);
						}
						
						oRow.clockIn = util.Formatter.formatSapToTime(oRowSource.Begtm);
						oRow.clockOut = util.Formatter.formatSapToTime(oRowSource.Endtm);
						
						oRow.attandanceDaily = oRowSource.AttandanceDaily.trim() === "0.00" ? "" : oRowSource.AttandanceDaily;
						oRow.tekenDaily = oRowSource.TekenDaily.trim() === "0.00" ? "" : oRowSource.TekenDaily;
						
 						oRow.startAbs = oRowSource.StartAbs;
						oRow.endAbs = oRowSource.EndAbs;
						
						//עבור כניסה או יציאה בתפקיד
						oRow.attP11 = oRowSource.AttP11;
						
						//האם לאפשר היעדרות יום מלא - רק אם לא הוזנה נוכחות בשום שורה בתאריך
						oRow.isAbsFullDayEnabled = this.handleAbsFullDayEnabledRow(oRowSource.Ldate ,oTableData, false);
						
						oRow.isFullDay = oRowSource.PeridFullDayInd === "X" ? true : false;
						
						oRow.empComment = oRowSource.EmpComment;
						oRow.mngComment = oRowSource.MngComment;
					
						//בניית רשימת בחירה של סיבת היעדרות או נוכחות
						var oAbsTypes = {};
						var aAbsTypes = [];
						
						for (var j=0; j<oRowSource.t554subtynav.results.length; j++) {
							
							oAbsTypes = {};
							
							oAbsTypes.typeKey = oRowSource.t554subtynav.results[j].Subty;
							oAbsTypes.typeText = oRowSource.t554subtynav.results[j].Atext;

							aAbsTypes.push(oAbsTypes);
						}
			
						oRow.itemsAattendance = aAbsTypes;
						
						//במידה וחוזר סוג תנועה מיוחדת, היא תוצג כערך נבחר ברשימת היעדרות
						if(oRowSource.AttP11.length > 0){
							oRow.attAbsNum = oRowSource.AttP11;
						}
						else{
							oRow.attAbsNum = oRowSource.AttAbsNum;
						}
							
						
						//האם מדובר על הזנה של כניסה או יציאה ידנית - מוצג אייקון לצד השעה
						oRow.manualClockIn = oRowSource.BChange  === "X" ? true : false;
						oRow.manualClockOut = oRowSource.EChange  === "X" ? true : false;
						
						// טיפול בימים שלא פתוחים לעריכה כאשר החודש סגור או שישי שבת או תאריך עתידי
						oRow.btnVisible = false;
						
						if(util.Formatter.formatDateToYYYYMMDD(oRow.dateReport) <= util.Formatter.todayAsYYYYMMDD() && oModelUserHeaderData.getData().isTblEditabled && oRowSource.t554subtynav.results.length > 0){ 
 							oRow.isRowEditable = true;
 							oRow.addBtnImg = "./" + window.clalitEssAttendanceAppVer + "/images/AddRow.png";
 							oRow.delBtnImg = "./" + window.clalitEssAttendanceAppVer + "/images/DelRow.png";
						}
						else{	// תאריך עתידי או חודש סגור
 							oRow.isRowEditable = false;
 							oRow.addBtnImg = "./" + window.clalitEssAttendanceAppVer + "/images/AddRowX.png";
 							oRow.delBtnImg = "./" + window.clalitEssAttendanceAppVer + "/images/DelRowX.png";
						}
						
						aRow.push(oRow);
					}

				oModelEmpAttendanceTable.setData({"lines" : aRow});	

				this.getView().setModel(oModelEmpAttendanceTable, "oModelEmpAttendanceTable");
				this.getView().setModel(oModelEmpQuotaData, "oModelEmpQuotaData");	
								
				//טיפול במצב תצוגה ועריכה
				this.isTblEditabled();

				//בנייה של רשימת בחירה עבור יחידה אירגונית עבור משתמש רב שיבוץ או רב מינוי
				this.buildOrgUnitsListSelect();

				 jQuery.sap.delayedCall(100, this, function() {
				 	this.unMergeColumns();
             		this.mergeColumns(false);
             		this.updateRows();
             		jQuery(".clalitSelectMandatory").closest( "td" ).css( "background-color", "rgba(254, 240, 158, 0.48)" );
				 });


				var oTable = this.getView().byId("mainTable");
				oTable.setBusy(false);
		  //      var oTable = this.getView().byId("mainTable");
		  //      var binding = oTable.getBinding("rows");
		  //      while(true){
				// 	if(binding){
				// 		that.mergeColumns();
				// 	}
				// }
				
				

			}
		},
		
		getPrintFileAttendanceCallback: function(oPrintResponseData){
			
			
					var url = oPrintResponseData.getData().url;
					 
					window.open(url);
			
		},
		
		
		saveAttendanceDataCallback: function(oSaveResponseData) {
			
			var oView = this.getView();
			var oCtrl = this;
			
			// כאשר חוזרים מבדיקה שגיאות לפני שמירה
			if(oSaveResponseData.IAction === GeneralConstants.ACTION_TYPE_CHEACK){
				if(oSaveResponseData.Check_errorsnav !== null && oSaveResponseData.Check_errorsnav.results.length > 0){
				
				var errorResultTable = oSaveResponseData.Check_errorsnav.results;
				var oModelCheckErrors = new JSONModel();

				var oRow = {};
				var aRow = [];
				var oRowSource = {};
	
				for (var i=0; i<errorResultTable.length; i++) {
					oRowSource = errorResultTable[i];
					oRow = {};
					
					oRow.clockIn = oRowSource.Begtm;
					oRow.clockOut = oRowSource.Endtm;
					oRow.errorText = oRowSource.Error;
					oRow.errorType = oRowSource.ErrorType;
					oRow.dateReport = util.Formatter.formatSapDate(oRowSource.Ldate);
					oRow.dateReportSource = oRowSource.Ldate;
					oRow.pernr = oRowSource.Pernr;
					
					oRow.isCriticalError = oRow.errorType === "9" ? true : false;
					oRow.isLowError = oRow.errorType === "0" ? true : false;
					
					
					aRow.push(oRow);
				}
	             
				oModelCheckErrors.setData({"lines" : aRow});
				
				sap.ui.getCore().setModel(oModelCheckErrors, "oModelCheckErrors");


				this.markCheckBeforeSaveErrorsRows();
				
				if (! this._errorsAfterSaveDialog) {
					this._errorsAfterSaveDialog = sap.ui.xmlfragment("clalit.org.il.ZEssAttendance." + window.clalitEssAttendanceAppVer + ".fragment.DialogErrorsAfterSave", this);				
				}
			
				this._errorsAfterSaveDialog.addStyleClass("sapUiSizeCompact").addStyleClass("myDialog").addStyleClass("myDialog");
				this._errorsAfterSaveDialog.open();

				}
			}
				
			//השמירה לא החזירה שגיאות לוגיות או שחוזר אחרי שמור בכל זאת - צריך לרענן את המסך ולהציג דיאלוג את
			 if(oSaveResponseData.IAction === GeneralConstants.ACTION_TYPE_CREATE || (oSaveResponseData.Check_errorsnav === null || oSaveResponseData.Check_errorsnav.results.length === 0)) {
				
				var oModelDialog = new JSONModel();
				oModelDialog.setData(
					{
						"dialogMessage" : oSaveResponseData.EMessage
					}
				);
				
				sap.ui.getCore().setModel(oModelDialog, "oModelDialog");
				
					// oModelCheckErrors = new JSONModel();
					// oModelCheckErrors.setData({"lines" : []});
					
					// sap.ui.getCore().setModel(oModelCheckErrors, "oModelCheckErrors");
					
					this.refreshHoursTable();
					
					if (! this._confirmSaveDialog) {
						this._confirmSaveDialog = sap.ui.xmlfragment("clalit.org.il.ZEssAttendance." + window.clalitEssAttendanceAppVer + ".fragment.DialogConfirm", this);				
					}
				
					this._confirmSaveDialog.addStyleClass("sapUiSizeCompact").addStyleClass("myDialog").addStyleClass("myDialog");
					this._confirmSaveDialog.open();
				
					// this.openConfirmDialog(
					// 	MessagePool.DIALOG_DATA_FULLY_SAVED,
					// 	MessagePool.DIALOG_SAVE_DATA_TITLE
					// );
			}
		},
	
		//-----------------------------------------------------
		
		// סגירת דיאלוג של אישור לאחר שמירה
		onCloseDialogDeleteRow : function(e) {

			if (this._confirmDeleteRowDialog) {
				this._confirmDeleteRowDialog.close();
				sap.ui.getCore().setModel(null, "oModelDialog");
			}
		},
		
		
		//-----------------------------------------------------
		
		// סגירת דיאלוג של אישור לאחר שמירה
		onCloseDialogConfirm : function(e) {

			if (this._confirmSaveDialog) {
				this._confirmSaveDialog.close();
				sap.ui.getCore().setModel(null, "oModelDialog");
			}
		},

		
		//-----------------------------------------------------
		
		// סגירת דיאלוג של שגיאות שמירה
		onCloseDialogErrorAfterSave : function(e) {
			if (this._errorsAfterSaveDialog) {
				this._errorsAfterSaveDialog.close();
				sap.ui.getCore().setModel(null, "oModelDialog");
			}
		},
		//-----------------------------------------------------
		
		// שמירה חלקית - גם אם יש שגיאות בחלק מהשורות
		onSaveAnyway : function(e) {
			
			if (this._errorsAfterSaveDialog) {
				this._errorsAfterSaveDialog.close();
			}
			
			this.handleSaveData(GeneralConstants.ACTION_TYPE_CREATE);

		},
		//-----------------------------------------------------
		//מחיקת שורה בטבלה
		onDeleteRowAfterConfirm : function(e) {

			var oView = this.getView();

			var iCurrentIndex = sap.ui.getCore().getModel("oModelDialog").getData().iCurrentIndex;
			var isRemovable = sap.ui.getCore().getModel("oModelDialog").getData().isRemovable;
			var oMyModelData = oView.getModel("oModelEmpAttendanceTable").getData().lines;
			
			if(isRemovable){
				//ביצוע מחיקה של שורה מהטבלה
	            oMyModelData.splice(iCurrentIndex, 1);
	            oView.getModel("oModelEmpAttendanceTable").refresh();
				 jQuery.sap.delayedCall(100, this, function() {
				 	this.unMergeColumns();
	         		this.mergeColumns(false);
	         		
	         		this.updateRows();
	         		
				 });
			}
			else{
					oMyModelData[iCurrentIndex].clockInDisplay = "";
					oMyModelData[iCurrentIndex].clockOutDisplay = "";
					oMyModelData[iCurrentIndex].clockIn = "";
					oMyModelData[iCurrentIndex].clockOut = "";
					
					oView.getModel("oModelEmpAttendanceTable").setProperty('/modelData/lines', oMyModelData);
					
					oView.getModel("oModelEmpAttendanceTable").refresh();
					jQuery.sap.delayedCall(100, this, function() {
             			this.updateRows();
					});

			}
			

			 
 			if (this._confirmDeleteRowDialog) {
				this._confirmDeleteRowDialog.close();
				sap.ui.getCore().setModel(null, "oModelDialog");
			}


		},
		
		//-----------------------------------------------------
		
		onOpenHelp: function() {
			
			// אם לא הוזנה לפחות שורה אחת ולא הגענו ממחיקת שורה יש להציג הודעת שגיאה
			// if ((e != null) && (oModelTable.getData().lines.length === 0)) { 
			// 	isOK = false;
			// 	sMessages += MessagePool.ERROR_MANDATORY_AT_LEAST_ONE_ROW; 
			// }
		},
		//----------------------------------------------------------------------------------------------------------
		onReplaceMonthSelected: function(e) {
				// var monthSelectedKey = e.getSource().getSelectedKey();
				
				// var oService = new EssAttendanceService(this.getView());
				// oService.getEmloyeeDataAndAttendance(monthSelectedKey);
				
				this.refreshHoursTable();

		}, 
		

		//----------------------------------------------------------------------------------------------------------
		onOrgUnitSelected: function(e) {
			
			var oView = this.getView();
			var orgUnitSelectedKey = e.getSource().getSelectedKey();
				
			var oBindingContext = e.getSource().getBindingContext("oModelEmpAttendanceTable");
			var sPath = oBindingContext.sPath;
			var oModel = oBindingContext.getModel();
			
			var clockIn = oModel.getProperty(sPath + "/clockInDisplay");
			var clockOut = oModel.getProperty(sPath + "/clockOutDisplay");
				
			var sMissingValue = MessagePool.ERROR_MSG_MISSING_VALUE;
				
			//מאפסים בהתחלה את השגיאה בשדה יחידה ובודקים אם יש שגיאות במצב הנוכחי
		 	var oOrgUnitCell = jQuery("#" + e.getSource().sId).closest(".clalitNotValid").closest( "td" );
		 	oOrgUnitCell.removeClass("clalitInvalidCellValue");
		 	oModel.setProperty(sPath + "/orgUnitMsg", "");
				 	
			 //במשתמש רב שיבוץ חובה למלא יחידה אירגונית
            if ((!this.isEmptyCell(clockIn, sMissingValue)) || (!this.isEmptyCell(clockOut, sMissingValue))) {
				 	if(this.isEmptyCell(orgUnitSelectedKey, GeneralConstants.EMPTY_DROPDOWN_KEY)){
				 		
						 var oOrgUnitTag = oView.byId(e.getSource().oParent.oParent.mAggregations.cells[TableCells.ORG_UNIT].mAggregations.items[0].sId);
							 						 		
						// oOrgUnitTag.setValueState(ValueState.Error);
						// oOrgUnitTag.setValueStateText(MessagePool.ERROR_CHECK_DAY_MISSING_ORG_UNIT);
							
						oModel.setProperty(sPath + "/orgUnitMsg", MessagePool.ERROR_CHECK_DAY_MISSING_ORG_UNIT);
						oOrgUnitCell.addClass("clalitInvalidCellValue");
				 	}
			}
			
			//pernrבמשתמש רב מינוי שדה יחידה הוא קובע את מספר עובד
			if(oModel.isEmpMultiPositionDisplayPerRow){
				oModel.setProperty(sPath + "/orgUnit", "");
				oModel.setProperty(sPath + "/pernr", orgUnitSelectedKey);
			}


			
		

				
				
		},
		
			
		//--------------------------------------------------------------------------------------------------------------

		openUserDetails: function() {
			var oView = this.getView();
			
			var oUserDetailsForm = oView.byId("userDetailsForm");
			var userDetailsBtn = oView.byId("openUserDetailsBtn");
			
			if(userDetailsBtn.getIcon() == "sap-icon://expand"){
				oUserDetailsForm.setVisible(true);
				userDetailsBtn.setIcon("sap-icon://collapse");
			} else {
				oUserDetailsForm.setVisible(false);
				userDetailsBtn.setIcon("sap-icon://expand");
			}
			//oUserDetailsForm.setVisible(true);
			
		},
		
		//----------------------------------------------------------------------------------------------------------
		//בחירה מתוך רשימת סוגי נוכחות או העדרות
		onItemsAattendanceSelected: function(e) {
			
			var subtypeSelectedKey = e.getSource().getSelectedKey();
				
			var oBindingContext = e.getSource().getBindingContext("oModelEmpAttendanceTable");
			var sPath = oBindingContext.sPath;
			var oModel = oBindingContext.getModel();
			var dateReport = oModel.getProperty(sPath + "/dateReport");
			
			//פתיחת השורה לעידכון גם במקרה שמדובר בדיווח עתידי
			if(util.Formatter.formatDateToYYYYMMDD(dateReport) > util.Formatter.todayAsYYYYMMDD()){
				if(subtypeSelectedKey.length > 0 && subtypeSelectedKey !== GeneralConstants.EMPTY_DROPDOWN_KEY){
					oModel.setProperty(sPath + "/isRowEditable", true);	
					oModel.setProperty(sPath + "/addBtnImg","./" + window.clalitEssAttendanceAppVer + "/images/AddRow.png");
	 				oModel.setProperty(sPath + "/delBtnImg", "./" + window.clalitEssAttendanceAppVer + "/images/DelRow.png");
	
				}
				else{
					oModel.setProperty(sPath + "/isRowEditable", false);
					oModel.setProperty(sPath + "/addBtnImg", "./" + window.clalitEssAttendanceAppVer + "/images/AddRowX.png");
	 				oModel.setProperty(sPath + "/delBtnImg", "./" + window.clalitEssAttendanceAppVer + "/images/DelRowX.png");
	
				}
			}
			//במידה ומסומן יום מלא והמשתמש מנסה לבחור ערך מרשימת היעדרות - צריך למנוע בחירה של תנועה מיוחדת כמו בתפקיד ומעבר יום
			if(subtypeSelectedKey.length > 0 && subtypeSelectedKey !== GeneralConstants.EMPTY_DROPDOWN_KEY && ((subtypeSelectedKey === GeneralConstants.ON_DUTY) || (subtypeSelectedKey === GeneralConstants.FOLLOWING_DAY))){
				
				if(oModel.getProperty(sPath + "/isAbsFullDayEnabled")){
					alert("יש לנקות בחירת היעדרות יום מלא לפני בחירת סוג נוכחות");
					return;
				}
				else{
					oModel.setProperty(sPath + "/attP11", subtypeSelectedKey);
				}
				
			}
			
			var isAbsFullDayEnabled = this.handleAbsFullDayEnabledRow(dateReport, oModel.getData().lines, true);
			oModel.setProperty(sPath + "/isAbsFullDayEnabled", isAbsFullDayEnabled);
			
		}, 
			
		//--------------------------------------------------------------------------------------------------------------
		
		
		onSelectRowTable: function(oEvent) {

		var oCurrentRowContext = oEvent.getParameter("rowContext");
		
		if(oCurrentRowContext !== null){
			
			var sPath = oCurrentRowContext.sPath;
			var oModel = oCurrentRowContext.getModel();
			
		 
			var sIsRowEditable = oModel.getProperty(sPath + "/isRowEditable");
			var oModelRowSelection = this.getView().getModel("oModelRowSelection");
    	
			// Get previousSelectedRowModel data (sPath)
			var oPreviousSelectedRow = oModelRowSelection.getObject('/modelData');
	
    		if (oPreviousSelectedRow!==oCurrentRowContext) {
    		oModel.setProperty(oPreviousSelectedRow + "/btnVisible", false);
    	}

		oModel.setProperty(sPath + "/btnVisible", true);
		oModelRowSelection.setData({modelData : sPath});

		}
		 
	 
		},
		
		
	onSave: function() {
		
		this.handleSaveData(GeneralConstants.ACTION_TYPE_CHEACK);
		
	},
	
	
	
	//-----------------------------------------------------

		handleSaveData : function(sActionType) {
			var oView = this.getView();
			//נתוני טבלת דיווח השעות
			var aTableData = oView.getModel("oModelEmpAttendanceTable").getData().lines;
			
			if (aTableData.length > 0) {

			var oMonthDDBK = oView.byId("monthSelectList");
			var sPeriod = oMonthDDBK.getSelectedKey();
			
			
			var oModelUserHeaderData = oView.getModel("oModelUserHeaderData").getData();
			var oModelEmpData = oView.getModel("oModelEmpData").getData();

			var oData = {};
			
			oData.IPerid = oModelEmpData.userID;
			oData.IMainPernr = oModelUserHeaderData.mainPernr;
			oData.IMonth = sPeriod;
			oData.IAction = sActionType;
			oData.EDateSgirah = oModelUserHeaderData.dateSgiraHSource;
			oData.EDateSgiram = oModelUserHeaderData.dateSgiraSource;
			oData.EDateSgiraemp = oModelUserHeaderData.dateSgiraEmpSource;
			oData.EDateStartMng = oModelUserHeaderData.dateSgiraStartMngSource;
			oData.EDateEndMng = oModelUserHeaderData.dateSgiraEndMngSource;
			
			var oEntry = {};
			var a = [];
			
			for (var i=0; i<aTableData.length; i++) {
				oEntry = {};
				
				oEntry.Pernr = aTableData[i].pernr;
				
				if(aTableData[i].orgUnit === GeneralConstants.EMPTY_DROPDOWN_KEY){
					aTableData[i].orgUnit = "";
				}
				
				oEntry.Ldate = aTableData[i].dateReportSource;
				
				oEntry.Orgunit = aTableData[i].orgUnit;
				
				if(aTableData[i].clockInDisplay === undefined || aTableData[i].clockInDisplay === MessagePool.ERROR_MSG_MISSING_VALUE || aTableData[i].clockInDisplay === null){
					aTableData[i].clockInDisplay = "";
				}
				if(aTableData[i].clockOutDisplay === undefined || aTableData[i].clockOutDisplay === MessagePool.ERROR_MSG_MISSING_VALUE || aTableData[i].clockOutDisplay === null){
					aTableData[i].clockOutDisplay = "";
				}
				
				// האם מדובר על שורת נוכחות
				if(aTableData[i].attAbsNum === GeneralConstants.EMPTY_DROPDOWN_KEY)
					aTableData[i].attAbsNum = "";
				
				if((aTableData[i].attAbsNum === undefined || aTableData[i].attAbsNum.length === 0 || aTableData[i].attAbsNum === "") || (aTableData[i].attP11 !== undefined && aTableData[i].attP11.length > 0)){
					oEntry.Begtm = util.Formatter.formatTimeToSap(aTableData[i].clockInDisplay);
					oEntry.Endtm = util.Formatter.formatTimeToSap(aTableData[i].clockOutDisplay);

				}
				//העדרות
				else{
					oEntry.StartAbs = util.Formatter.formatTimeToSap(aTableData[i].clockInDisplay);
					oEntry.EndAbs = util.Formatter.formatTimeToSap(aTableData[i].clockOutDisplay);
				}
				
				oEntry.PeridFullDayInd = aTableData[i].isFullDay === true ? "X" : "";
				
				oEntry.BChange = aTableData[i].manualClockIn === true ? "X" : "";
				oEntry.EChange = aTableData[i].manualClockOut === true ? "X" : "";
				
				//תנועה מיוחדת לא היעדרות
				if(aTableData[i].attP11 !== undefined && aTableData[i].attP11.length > 0){
					oEntry.AttP11 = aTableData[i].attP11;
				}
				else{
					oEntry.AttAbsNum = aTableData[i].attAbsNum;
				}
				
				oEntry.MultiAssignment = aTableData[i].isEmpMultiAssignmentPerRow === true ? "X" : "";
				
				oEntry.EmpComment = aTableData[i].empComment;
				oEntry.MngComment = aTableData[i].mngComment;
				
				a.push(oEntry);
				
				  //"Check_errorsnav": []
				
				 var oCheck_errorsnavEntry = {};
				 var aCheck_errorsnav = [];
			}
			oData.header_linesnav = a;
			oData.Check_errorsnav = aCheck_errorsnav;

			
			// var oDialogFragment = sap.ui.xmlfragment("clalit.org.il.SterileSupply.fragment.BusyDialog");
			// var oBusyDialogModel = sap.ui.getCore().getModel("oBusyDialogModel");
			// if (oBusyDialogModel) {
			// 	oDialogFragment = oBusyDialogModel.getData().o;
			// 	oDialogFragment.open();
			// }
			
			//שולח את השגיאות אחרי שהמשתמש בחר שמור בכל זאת
			if(sActionType === GeneralConstants.ACTION_TYPE_CREATE){
				
				var oModelCheckSaveErrors = sap.ui.getCore().getModel("oModelCheckErrors");
				var oErrorsTableData = oModelCheckSaveErrors.getData().lines;
					debugger;
				for (i=0; i<oErrorsTableData.length; i++) {
					
					oCheck_errorsnavEntry.Ldate = oErrorsTableData[i].dateReportSource;
					oCheck_errorsnavEntry.Pernr = oErrorsTableData[i].pernr;
					oCheck_errorsnavEntry.Begtm = oErrorsTableData[i].clockIn;
					oCheck_errorsnavEntry.Endtm = oErrorsTableData[i].clockOut;
					oCheck_errorsnavEntry.ErrorType = oErrorsTableData[i].errorType;
					oCheck_errorsnavEntry.Error = oErrorsTableData[i].errorText;

					aCheck_errorsnav.push(oCheck_errorsnavEntry);

				}
			}
			
	debugger;
			var oService = new EssAttendanceService(oView);
			oService.saveAttendanceReportData(oData);
			
		}
			
	},
	//-----------------------------------------------------
	
	
	onPrint: function() {
		var oView = this.getView();
		
		var oMonthDDBK = oView.byId("monthSelectList");
		var sPeriod = oMonthDDBK.getSelectedKey();
		
		var oService = new EssAttendanceService(this.getView());
		oService.getPrintFileAttendance(sPeriod);
	},
	
	onApprovalManager: function() {
		var dCurrentDate = new Date();
		alert(dCurrentDate.toLocaleTimeString()); // TODO: onApprovalManager
	},


	onReOpenMonth: function() {
		var dCurrentDate = new Date();
		alert(dCurrentDate.toLocaleTimeString()); // TODO: onReOpenMonth
	},
		
	// -------------------------------------------------------------------------------------------------------------------------
	
	checkDay : function(sDate) {
		var o, o1, o2;
		var iStart1, iEnd1;
		var iStart2, iEnd2;

		var i18Model = sap.ui.getCore().getModel("i18n");
		var bundle = i18Model.getResourceBundle();
		var sMissingValue = bundle.getText("err_msg_missing_value");

		var oView = this.getView();

		var oModel = oView.getModel("oModelEmpAttendanceTable");
		var oCtrl = this;

		var iErrCode = -1;
		var sErrMsg = "";

		var aMonth = oModel.getProperty('/modelData/table');
		var aPartialCodes = oModel.getProperty("/AttAbsNums");
		
		// שורות שהוזנו עבור יום
		var aDay = aMonth.filter(function(value) {
			return (value.theDate2 === sDate);
		});


		// -----------------------------------------------------------------------------------------------------

		// העדרויות מלאות
		var aAbsenceFull = aDay.filter(function(value) { 
			//return ((value.startHour === '') && (value.endHour === '') && ((value.type === '0001') || (value.type === '0003')));
			return ((value.startHour === '') && (value.endHour === '') && (aPartialCodes.indexOf(value.type) > -1));
		});

		
		// Cond: 10
		if (aAbsenceFull.length > 1) {
			iErrCode = 9;
			sErrMsg = bundle.getText("err_check_day_overlap_full_absence"); // חפיפה בין העדרויות מלאות
		}
		// -----------------------------------------------------------------------------------------------------

		// Cond: 8
		// הוזנה יותר משורה אחת עבור יום ואחת השורות היא העדרות מלאה		 
		if ((aDay.length > 1) && ((aAbsenceFull.length == 1))) {
			iErrCode = 9;
			sErrMsg = bundle.getText("err_check_day_attendance_and_absence_on_same_day"); // אי אפשר לדווח נוכחות והעדרות מלאה באותו היום
		}
		
		// -----------------------------------------------------------------------------------------------------

		// העדרות חלקית שהוזנו בה גם שעת כניסה וגם שעת יציאה
		var aAbsencePartial = aDay.filter(function(value) { 
			//return (value.startHour !== '') && (value.endHour !== '') && ((value.type === '0001') || (value.type === '0003'));
			return (value.startHour !== '') && (value.endHour !== '') && (aPartialCodes.indexOf(value.type) > -1);
		});

		// Cond: 7
		for ( var i = 0; i < aAbsencePartial.length; i++) {
			o = aAbsencePartial[i];

			var dTimeStart = new Date("01/01/2007 " + o.startHour);
			var dTimeEnd = new Date("01/01/2007 " + o.endHour);

			var iHourDiff = (dTimeEnd - dTimeStart) / (60 * 60 * 1000);

			if (iHourDiff > 9) {
				iErrCode = 9;
				sErrMsg = bundle.getText("err_check_day_more_than_9_hours"); // הוקלדו יותר מ 9 שעות העדרות
				break;
			}
		}
		// -----------------------------------------------------------------------------------------------------

		// Cond: 5
		// חפיפות
		for ( var i = 0; i < aDay.length - 1; i++) {
			for ( var j = i + 1; j < aDay.length; j++) {
				o1 = aDay[i];
				o2 = aDay[j];

				// --------------------------------------------------------------------------------------------------------------------
				if ((!oCtrl.isEmptyCell(o1.startHour, sMissingValue)) && 
						(!oCtrl.isEmptyCell(o2.startHour, sMissingValue)) && 
						(!oCtrl.isEmptyCell(o1.endHour, sMissingValue)) && 
						(!oCtrl.isEmptyCell(o2.endHour, sMissingValue)))
				{
					if ((oCtrl.isDiffOK(o1.startHour, o1.endHour)) && (oCtrl.isDiffOK(o2.startHour, o2.endHour))) {
						if ((o1.startHour < o2.endHour) && (o2.startHour < o1.endHour)) {
							iErrCode = 9;
							jQuery.sap.log.info("overlap1");
							sErrMsg = bundle.getText("err_check_day_overlap"); // "חפיפה בין דיווחים"
							break;
						}
					}
					
					else if ((!oCtrl.isDiffOK(o1.startHour, o1.endHour)) && (oCtrl.isDiffOK(o2.startHour, o2.endHour))) {
						if ((o2.startHour > o1.startHour) || (o2.endHour > o1.startHour)) {
							iErrCode = 9;
							jQuery.sap.log.info("overlap11");
							sErrMsg = bundle.getText("err_check_day_overlap"); // "חפיפה בין דיווחים"
							break;
						}
					}
					else if ((oCtrl.isDiffOK(o1.startHour, o1.endHour)) && (!oCtrl.isDiffOK(o2.startHour, o2.endHour))) {
						if ((o1.startHour > o2.startHour) || (o1.endHour > o2.startHour)) {
							iErrCode = 9;
							jQuery.sap.log.info("overlap111");
							sErrMsg = bundle.getText("err_check_day_overlap"); // "חפיפה בין דיווחים"
							break;
						}
					}
					else if ((!oCtrl.isDiffOK(o1.startHour, o1.endHour)) && (!oCtrl.isDiffOK(o2.startHour, o2.endHour))) {
						
						iStart1 = parseInt((o1.startHour).replace(":",""));
						iStart2 = parseInt((o2.startHour).replace(":",""));
						
						iEnd1 = parseInt((o1.endHour).replace(":",""));
						iEnd1 += 2400;		
						
						iEnd2 = parseInt((o2.endHour).replace(":",""));
						iEnd2 += 2400;		

						if ((iStart1 < iEnd2) && (iStart2 < iEnd1)) {
							iErrCode = 9;
							sErrMsg = bundle.getText("err_check_day_overlap"); // "חפיפה בין דיווחים"
							break;
						}
					}
					
				}

				// --------------------------------------------------------------------------------------------------------------------

				if ((!oCtrl.isEmptyCell(o1.startHour, sMissingValue)) && 
					(!oCtrl.isEmptyCell(o2.startHour, sMissingValue)) && 
					(!oCtrl.isEmptyCell(o1.endHour, sMissingValue)) && 
					(oCtrl.isEmptyCell(o2.endHour, sMissingValue)))

				{
					
					if ((oCtrl.isDiffOK(o1.startHour, o1.endHour))) { 
						//if ((o2.startHour > o1.startHour) && (o2.startHour < o1.endHour)) {
						if ((o2.startHour >= o1.startHour) && (o2.startHour < o1.endHour)) {
							iErrCode = 9;
							jQuery.sap.log.info("overlap2");
							sErrMsg = bundle.getText("err_check_day_overlap"); // "חפיפה בין דיווחים"
						}
					} else {
						iStart1 = parseInt((o1.startHour).replace(":",""));
						iStart2 = parseInt((o2.startHour).replace(":",""));
						
						iEnd1 = parseInt((o1.endHour).replace(":",""));
						iEnd1 += 2400;						
						
						if ((iStart2 > iStart1) && (iStart2 < iEnd1)) {
							iErrCode = 9;
							jQuery.sap.log.info("overlap22");
							sErrMsg = bundle.getText("err_check_day_overlap"); // "חפיפה בין דיווחים"
						}
					}
				}

				// --------------------------------------------------------------------------------------------------------------------

				if ((!oCtrl.isEmptyCell(o1.startHour, sMissingValue)) && 
					(!oCtrl.isEmptyCell(o2.startHour, sMissingValue)) && 
					(oCtrl.isEmptyCell(o1.endHour, sMissingValue)) && 
					(!oCtrl.isEmptyCell(o2.endHour, sMissingValue)))
				{
					if ((oCtrl.isDiffOK(o2.startHour, o2.endHour))) {
						//if ((o1.startHour > o2.startHour) && (o1.startHour < o2.endHour)) {
						if ((o1.startHour >= o2.startHour) && (o1.startHour < o2.endHour)) {
							iErrCode = 9;
							jQuery.sap.log.info("overlap3");
							sErrMsg = bundle.getText("err_check_day_overlap"); // "חפיפה בין דיווחים"
						}
					} else {
						iStart1 = parseInt((o1.startHour).replace(":",""));
						iStart2 = parseInt((o2.startHour).replace(":",""));
						
						iEnd2 = parseInt((o2.endHour).replace(":",""));
						iEnd2 += 2400;						
						
						if ((iStart1 > iStart2) && (iStart1 < iEnd2)) {
							iErrCode = 9;
							jQuery.sap.log.info("overlap33");
							sErrMsg = bundle.getText("err_check_day_overlap"); // "חפיפה בין דיווחים"
						}
					}
				}

				// --------------------------------------------------------------------------------------------------------------------

				if ((oCtrl.isEmptyCell(o1.startHour, sMissingValue)) && 
					(!oCtrl.isEmptyCell(o2.startHour, sMissingValue)) && 
					(!oCtrl.isEmptyCell(o1.endHour, sMissingValue)) && 
					(!oCtrl.isEmptyCell(o2.endHour, sMissingValue)))

				{
					if ((oCtrl.isDiffOK(o2.startHour, o2.endHour))) {
						//if ((o1.endHour < o2.endHour) && (o1.endHour > o2.startHour)) {
						if ((o1.endHour <= o2.endHour) && (o1.endHour > o2.startHour)) {
							iErrCode = 9;
							jQuery.sap.log.info("overlap4");
							sErrMsg = bundle.getText("err_check_day_overlap"); // "חפיפה בין דיווחים"
						}
					} else {
						iEnd1 = parseInt((o1.endHour).replace(":",""));
						if (iEnd1<60) {
							iEnd1 += 2400;
						}

						
						iStart2 = parseInt((o2.startHour).replace(":",""));
						
						iEnd2 = parseInt((o2.endHour).replace(":",""));
						iEnd2 += 2400;						
						
						
						if ((iEnd1 < iEnd2) && (iEnd1 > iStart2)) {
							iErrCode = 9;
							jQuery.sap.log.info("overlap44");
							sErrMsg = bundle.getText("err_check_day_overlap"); // "חפיפה בין דיווחים"
						}
					}
				}

				// --------------------------------------------------------------------------------------------------------------------

				if ((!oCtrl.isEmptyCell(o1.startHour, sMissingValue)) && 
						(oCtrl.isEmptyCell(o2.startHour, sMissingValue)) && 
						(!oCtrl.isEmptyCell(o1.endHour, sMissingValue)) && 
						(!oCtrl.isEmptyCell(o2.endHour, sMissingValue)))

				{
					if ((oCtrl.isDiffOK(o1.startHour, o1.endHour))) {
						//if ((o1.endHour > o2.endHour) && (o1.startHour < o2.endHour)) {
						if ((o1.endHour >= o2.endHour) && (o1.startHour < o2.endHour)) {
							iErrCode = 9;
							jQuery.sap.log.info("overlap5");
							sErrMsg = bundle.getText("err_check_day_overlap"); // "חפיפה בין דיווחים"
						}
					} else {
						iStart1 = parseInt((o1.startHour).replace(":",""));
						
						
						iEnd2 = parseInt((o2.endHour).replace(":",""));
						if (iEnd2<60) {
							iEnd2 += 2400;
						}
						
						
						iEnd1 = parseInt((o1.endHour).replace(":",""));
						iEnd1 += 2400;						
						
						
						if ((iEnd1 > iEnd2) && (iStart1 < iEnd2)) {
							iErrCode = 9;
							jQuery.sap.log.info("overlap55");
							sErrMsg = bundle.getText("err_check_day_overlap"); // "חפיפה בין דיווחים"
						}
					}
				}
			} // end j loop
		} // end i loop
			
		// --------------------------------------------------------------------------------------------------------------------
		
		if (iErrCode != 9) {
			// Cond: 2
			// שעת כניסה גדולה משעת יציאה
			var aStartBiggerThanEnd = aDay.filter(function(value) {
				return (
						(!oCtrl.isEmptyCell(value.startHour, sMissingValue)) && 
						(!oCtrl.isEmptyCell(value.endHour, sMissingValue)) &&
						(oCtrl.isValidCellValue(value.startHour)) && 
						(oCtrl.isValidCellValue(value.endHour)) &&
						(!oCtrl.isDiffOK(value.startHour, value.endHour))
					);
			});
			
			if (aStartBiggerThanEnd.length > 0) {
				iErrCode = 0;
				sErrMsg = bundle.getText("err_check_day_start_bigger_than_end"); // "שעת התחלה גדולה משעת סיום";
				//sErrMsg = bundle.getText("DEF");
			}
			
			// --------------------------------------------------------------------------------------------------------------------
			
			// Cond 3,4
			// שעת כניסה הוזנה ושעת יציאה לא הוזנה או להפך
			var aEmptySiblings = aDay.filter(function(value) {
				return (
						(!oCtrl.isEmptyCell(value.startHour, sMissingValue)) && (oCtrl.isValidCellValue(value.startHour)) && (oCtrl.isEmptyCell(value.endHour, sMissingValue))
						||
						(!oCtrl.isEmptyCell(value.endHour, sMissingValue)) && (oCtrl.isValidCellValue(value.endHour)) && (oCtrl.isEmptyCell(value.startHour, sMissingValue))
					);
			});
			
			if (aEmptySiblings.length > 0) {
				iErrCode = 0;
				jQuery.sap.log.info("aEmptySiblings-->"+aEmptySiblings.length);
				sErrMsg = bundle.getText("err_check_day_missing_value");
			}
		}
		
		if (iErrCode != (-1)) {
			jQuery.sap.log.info("iErrCode-->"+iErrCode);
			jQuery.sap.log.info("sErrMsg-->"+sErrMsg + " (" + sDate + ") ");
			oCtrl.showErrorMessage(sDate + " - " + sErrMsg);
		} else {
			jQuery.sap.log.info("checkDay - OK!");
		}
	},
	
		// -------------------------------------------------------------------------------------------------------------------------	
	
	isEmptyCell : function(sString, sMissingValue) {
		if ((sString === null) || (sString === "") ||(sString === sMissingValue)) {
			return true;
		} else {
			return false;
		}		
	},

	mergeColumns : function(isAfterAddRow) {
        var oTable;
        oTable = this.getView().byId("mainTable");
 
		var isEmpMultiPositionOrAssignment = this.getView().getModel("oModelEmpData").getData().isEmpMultiPositionOrAssignment;
		var isEmpMulti = isEmpMultiPositionOrAssignment === true ? 1 : 0;
		
		//טיפול במיזוג שורות כאשר יש מספר שורות באותו תאריך
        var aRows = oTable.getRows();
         if (aRows && aRows.length > 0) {
             var pRow = {};
             for (var i = 0; i < aRows.length; i++) {
             	
                 if (i > 0) {
                 	
                     var pCell = pRow.getCells()[TableCells.DATE_REPORT];
                     var cCell = aRows[i].getCells()[TableCells.DATE_REPORT];

                     if (cCell.getText() === pCell.getText()) {
                     	//מיזוג עמודת התאריך
                         $("#" + cCell.getId()).css("visibility", "hidden");
                         $("#" + pRow.getId() + "-col" + TableCells.DATE_REPORT).css("border-bottom-style", "hidden");
        
                         //מיזוג עמודת היום
                         $("#" + aRows[i].getCells()[TableCells.DAY].getId()).css("visibility", "hidden");
                         $("#" + pRow.getId() + "-col" + TableCells.DAY).css("border-bottom-style", "hidden");

						  // מיזוג עמודת היעדרות יום מלא
						  var absFullDayIndex = TableCells.ABS_FULL_DAY + isEmpMulti;

		                  $("#" + aRows[i].getCells()[absFullDayIndex].getId()).css("visibility", "hidden");
		                  $("#" + pRow.getId() + "-col" + absFullDayIndex).css("border-bottom-style", "hidden");

						  //מיזוג עמודת הערה
						  var commentIndex = TableCells.COMMENT + isEmpMulti;
		                 
		                  $("#" + aRows[i].getCells()[commentIndex].getId()).css("visibility", "hidden");
		                  $("#" + pRow.getId() + "-col" + commentIndex).css("border-bottom-style", "hidden");

						//משתמש שמוגדר רב שיבוץ או רב מינוי יש עמודה נוספת של יחידה
						  if(isEmpMultiPositionOrAssignment){
						  			
				    		if (pRow.getBindingContext("oModelEmpAttendanceTable")) {
		            			var pObj = pRow.getBindingContext("oModelEmpAttendanceTable").getObject();
				    		}
				    		if (aRows[i].getBindingContext("oModelEmpAttendanceTable")) {
		            			var cObj = aRows[i].getBindingContext("oModelEmpAttendanceTable").getObject();
				    		}
		                    var pCellOrgUnit = pRow.getCells()[TableCells.ORG_UNIT];
	                        var cCellOrgUnit = aRows[i].getCells()[TableCells.ORG_UNIT];
		                    if (pObj !== undefined && cObj !== undefined ){
		                     	//בדיקה האם מדובר באותה יחידה
			                     if(pObj.pernr === cObj.pernr){
			                     //&& cCellOrgUnit.getItems()[0].getSelectedKey() === pCellOrgUnit.getItems()[0].getSelectedKey() && cCellOrgUnit.getItems()[0].getSelectedKey() !== GeneralConstants.EMPTY_DROPDOWN_KEY) {    
			               //      	if(! isAfterAddRow){
				 				         ////מיזוג עמודת יחידה
				              //           $("#" + aRows[i].getCells()[TableCells.ORG_UNIT].getId()).css("visibility", "hidden");
				              //           $("#" + pRow.getId() + "-col" + TableCells.ORG_UNIT).css("border-bottom-style", "hidden");
			               //      	}
			                         
			                         //מיזוג עמודת סה"כ יומי
			                         var attendanceDayIndex = TableCells.ATTENDANCE_DAILY + isEmpMulti;
			                         $("#" + aRows[i].getCells()[attendanceDayIndex].getId()).css("visibility", "hidden");
			                         $("#" + pRow.getId() + "-col" + attendanceDayIndex).css("border-bottom-style", "hidden");
			                         
			                         //מיזוג עמודת תקן
			                         var tekenDailyIndex = TableCells.TEKEN_DAILY + isEmpMulti;
			                         $("#" + aRows[i].getCells()[tekenDailyIndex].getId()).css("visibility", "hidden");
			                         $("#" + pRow.getId() + "-col" + tekenDailyIndex).css("border-bottom-style", "hidden");
			                     }
		                     }
	                     }
						  
						  else{
							  //מיזוג עמודת סה"כ יומי
			                  $("#" + aRows[i].getCells()[TableCells.ATTENDANCE_DAILY].getId()).css("visibility", "hidden");
			                  $("#" + pRow.getId() + "-col" + TableCells.ATTENDANCE_DAILY).css("border-bottom-style", "hidden");
			                  
								//מיזוג עמודת תקן
			                  $("#" + aRows[i].getCells()[TableCells.TEKEN_DAILY].getId()).css("visibility", "hidden");
			                  $("#" + pRow.getId() + "-col" + TableCells.TEKEN_DAILY).css("border-bottom-style", "hidden");

						  }
                     }
            	 }
            	 pRow = aRows[i];
	          }
	      }
		},
	// -------------------------------------------------------------------------------------------------------------------------		
		
		unMergeColumns : function() {
        var oTable;

        oTable = this.getView().byId("mainTable");

		//טיפול במיזוג שורות כאשר יש כמה דיווחים באותו תאריך
        var aRows = oTable.getRows();
         if (aRows && aRows.length > 0) {
             var pRow = {};
             for (var i = 0; i < aRows.length; i++) {
             	pRow = aRows[i];
				for(var j=0; j < pRow.getCells().length; j++ ){
					var oCell = pRow.getCells()[j];
					
					$("#" + oCell.getId()).css("visibility", "visible");
            		$("#" + pRow.getId() + "-col" + j  ).css("border-bottom-style", "solid");
				}
				
             }
             
	       }
	      
		},
		
		
		
		
	// -------------------------------------------------------------------------------------------------------------------------
	buildMonthListSelect : function() {				
		// בניית רשימת בחירה לחודש דיווח
		var oView = this.getView();
		
		var oModelDates = new JSONModel();
		var dCurrentDate = new Date();
		var iCurrentYear = dCurrentDate.getFullYear();
		var iCurrentMonth = dCurrentDate.getMonth() + 1;
		var aDates = [];
		
		for (var i = 0; i <= 11; i++) {
			var oDDBKEntry = {};
			oDDBKEntry.dateKey = iCurrentYear.toString() + (iCurrentMonth < 10 ? "0" + iCurrentMonth.toString() : iCurrentMonth.toString());
			oDDBKEntry.dateText = (iCurrentMonth < 10 ? "0" + iCurrentMonth.toString() : iCurrentMonth.toString()) + "/" + iCurrentYear.toString();
			iCurrentMonth = iCurrentMonth - 1;
			if (iCurrentMonth == 0) {
				iCurrentMonth = 12;
				iCurrentYear = iCurrentYear - 1;
			}
			aDates.push(oDDBKEntry);
		}
		
		
		oModelDates.setData({
			"dates": aDates
		});
		oView.setModel(oModelDates, "modelDates");

		var monthSelectedValue = util.Formatter.getDefaultPeriod();
		var oSelectedMonthModel = new JSONModel(
			{ "monthSelectedKey" :  monthSelectedValue}
		);
		
		oView.setModel(oModelDates, "modelDates");
		oView.setModel(oSelectedMonthModel, "oSelectedMonthModel");
	},
	
	// ------------------------------------------------------------------------------------------------------------------
		
	// -------------------------------------------------------------------------------------------------------------------------
	buildOrgUnitsListSelect : function() {				
		// בניית רשימת בחירה ליחידה אירגונית
		
		var oView = this.getView();
		
		var oModelOrgUnits = new JSONModel();
		var aEmpDataSource = oView.getModel("oModelEmpDataTable").getData();
		
		// var isMultiAssignment = this.getView().getModel("oModelUserHeaderData").getData().empMultiPosition;
		// var isMultiPosition = this.getView().getModel("oModelEmpData").getData().empMultiAssignment;

		var aOrgUnits = [];
			// ----- שורות -----
		var oRowSource = {};

		for (var i=0; i<aEmpDataSource.lines.length; i++) {
			oRowSource = aEmpDataSource.lines[i];
			
			var oDDBKEntry = {};
			//oDDBKEntry.orgUnitKey = oRowSource.orgUnit + oRowSource.site;
			oDDBKEntry.orgUnitKey = oRowSource.orgUnit;
			oDDBKEntry.orgUnitText = oRowSource.orgText + "-" +oRowSource.siteText;

			aOrgUnits.push(oDDBKEntry);
		}
		
		oModelOrgUnits.setData({
			"orgUnits": aOrgUnits
		});
		
		// var orgUnitsSelectedValue = "";
		// var oSelectedOrgUnitModel = new JSONModel( 
		// 	{ "orgUnitSelectedKey" :  orgUnitsSelectedValue} 
		// );
		
		oView.setModel(oModelOrgUnits, "modelOrgUnits");
		// oView.setModel(oSelectedOrgUnitModel, "oSelectedOrgUnitModel");
	},
	
	// ------------------------------------------------------------------------------------------------------------------

		 onAddRow : function(o) {
		 	
		 	debugger;
			var oView = this.getView();
		
			var oCtrl = this;
			
			var iCurrentIndex = o.getSource().getParent().getParent().getIndex();
			
            var oBindingContext = o.getSource().getBindingContext("oModelEmpAttendanceTable");
			var oModel = oBindingContext.getModel();
            var oMyModelData = oModel.getData().lines;
            var isEmpMultiAssignmentDisplayPerRow = false;
            var currPernr = oMyModelData[iCurrentIndex].pernr;
            var currOrgUnit = oMyModelData[iCurrentIndex].orgUnit;
            var currOrgUnitTxt = oMyModelData[iCurrentIndex].orgUnitTxt;
            
            //PERNR תיקון למקרה שרב מינוי מוסיף שורה ידנית ואז הוא חייב לבחור יחידה 
            if(oMyModelData[iCurrentIndex].isEmpMultiAssignmentPerRow || oMyModelData[iCurrentIndex].isEmpMultiPositionDisplayPerRow){
            	isEmpMultiAssignmentDisplayPerRow = true; 
            }
            
            //PERNR תיקון למקרה שרב מינוי מוסיף שורה ידנית ואז הוא חייב לבחור יחידה 
            if(oMyModelData[iCurrentIndex].isEmpMultiPositionDisplayPerRow){
            	currPernr = oMyModelData[iCurrentIndex].itemsOrgUnits[0].orgUnitKey;
            }
            
            //משתמש רב שיבוץ - להשאיר את רשימת בחירה של יחידה ללא ערך נבחר
            if(oMyModelData[iCurrentIndex].isEmpMultiAssignmentPerRow){
            	currOrgUnit = GeneralConstants.EMPTY_DROPDOWN_KEY;
            	currOrgUnitTxt = "";
            }
            
            var oNewElement = {	
              
              pernr : currPernr,
              dateReportSource : oMyModelData[iCurrentIndex].dateReportSource,
              dateReport : oMyModelData[iCurrentIndex].dateReport,
              dayDesc : oMyModelData[iCurrentIndex].dayDesc,
              pernrKey : oMyModelData[iCurrentIndex].pernrKey,
              werksTxt : oMyModelData[iCurrentIndex].werksTxt,
              itemsOrgUnits : oMyModelData[iCurrentIndex].itemsOrgUnits,
              orgUnit : currOrgUnit,
              orgUnitTxt : currOrgUnitTxt,
              
              clockInDisplay : "",
              clockOutDisplay : "",
              
              attandanceDaily : oMyModelData[iCurrentIndex].attandanceDaily,
              
              //tekenDaily : oMyModelData[iCurrentIndex].tekenDaily,
              tekenDaily : "",
              
              attAbsNum : "",
              itemsAattendance : oMyModelData[iCurrentIndex].itemsAattendance,
              isAbsFullDayEnabled : oMyModelData[iCurrentIndex].isAbsFullDayEnabled,
              
              isEmpMultiPositionDisplayPerRow : oMyModelData[iCurrentIndex].isEmpMultiPositionDisplayPerRow,
              isEmpMultiAssignmentDisplayPerRow : isEmpMultiAssignmentDisplayPerRow,
              isEmpMultiAssignmentPerRow : oMyModelData[iCurrentIndex].isEmpMultiAssignmentPerRow,
              empComment : oMyModelData[iCurrentIndex].empComment,
              addBtnImg : "./" + window.clalitEssAttendanceAppVer + "/images/AddRow.png",
			  btnVisible : false,
              delBtnImg	: "./" + window.clalitEssAttendanceAppVer + "/images/DelRow.png",
			  isRowEditable : true,
			  //האם מדובר על הזנה של כניסה או יציאה ידנית - מוצג אייקון לצד השעה
			  manualClockIn : false,
			  manualClockOut : false
            };
            
            debugger;
            
            oMyModelData.splice(iCurrentIndex+1, 0, oNewElement);
            oModel.setProperty('/modelData/lines', oMyModelData);
            
            oModel.refresh();
            
			 jQuery.sap.delayedCall(100, this, function() {
			 	this.updateRows();
			 	this.unMergeColumns();
         		this.mergeColumns(true);
			 });
	            
		}, // end onAddRow

	// ------------------------------------------------------------------------------------------------------------------

		 onDeleteRow : function(o) {
		 	
		 	debugger;
			var oView = this.getView();
		
			// var oModelRowButtons = oView.getModel("oModelRowButtons");
			// var sAddBtnEnabled = oModelRowButtons.getProperty("/modelData/addBtnEnabled");
			
			// if (sAddBtnEnabled === "t") {
			var oCtrl = this;
				// oCtrl.closePopup();
			var iCurrentIndex = o.getSource().getParent().getParent().getIndex();
            var oBindingContext = o.getSource().getBindingContext("oModelEmpAttendanceTable");
			var sPath = oBindingContext.sPath;
			var oModel = oBindingContext.getModel();
            var oMyModelData = oModel.getData().lines;
            
            var currDateReport = oMyModelData[iCurrentIndex].dateReport;
            var currPernr = oMyModelData[iCurrentIndex].pernr;
            var teken = oMyModelData[iCurrentIndex].tekenDaily;
            
            var pernrOccurs = 0;
            var isRemovable = false;
            
            // שורות שהוזנו עבור יום
			var aDay = oMyModelData.filter(function(value) {
				return (value.dateReport === currDateReport);
			});

			for(var i=0; i<aDay.length; i++){

					if(aDay[i].pernr === currPernr){
						pernrOccurs = pernrOccurs + 1;
						
						if(pernrOccurs > 1){
							if(aDay[i].tekenDaily !== null && aDay[i].tekenDaily.length > 0){
								isRemovable = true;
							}
						}
				}

			}
				
			var oModelDialog = new JSONModel();
			oModelDialog.setData(
				{
					"dialogMessage" : MessagePool.DIALOG_CONFIRM_DELETE_ROW,
					"iCurrentIndex" : iCurrentIndex,
					"isRemovable"		: isRemovable
				}
			);
			
			sap.ui.getCore().setModel(oModelDialog, "oModelDialog");
				
				
//			if(isRemovable){
				
				if (! this._confirmDeleteRowDialog) {
					this._confirmDeleteRowDialog = sap.ui.xmlfragment("clalit.org.il.ZEssAttendance." + window.clalitEssAttendanceAppVer + ".fragment.DialogConfirmDeleteRow", this);				
				}
				
				
				this._confirmDeleteRowDialog.addStyleClass("sapUiSizeCompact").addStyleClass("myDialog").addStyleClass("myDialog");
				this._confirmDeleteRowDialog.open();
				
			// }
			
			// else{
			// //מופע בודד לאותו תאריך - לא מוחקים שאת שורה רק מרוקנים
			// 	//לעשות דיאלוג
			// 		oMyModelData[iCurrentIndex].clockInDisplay = "";
			// 		oMyModelData[iCurrentIndex].clockOutDisplay = "";
			// 		oMyModelData[iCurrentIndex].clockIn = "";
			// 		oMyModelData[iCurrentIndex].clockOut = "";
					
			// 		oModel.setProperty('/modelData/lines', oMyModelData);
					
			// 		oModel.refresh();
			// 		jQuery.sap.delayedCall(100, this, function() {
   //          			this.updateRows();
			// 		});
			// 	}

		}, // end onDeleteRow
		
	// -------------------------------------------------------------------------------------------------------------------------
	
	
	
	
	
	isTblEditabled : function() {
		//בדיקה שהחודש פתוח לעידכון וגם ברמת המשתמש הוא לא שלח לאישור מנהל
		var saveAndApproveBtnEnabled = false;
		var reOpenMonthBtnEnabled = false;
		
		var oView = this.getView();
		var oModelUserHeaderData = oView.getModel("oModelUserHeaderData");
		var oModelStatusTable = oView.getModel("oModelStatusTable").getData();
		
		var isMonthOpen = oModelUserHeaderData.getProperty('/isMonthOpen');

		if (isMonthOpen === true) {
			for (var i=0; i<oModelStatusTable.lines.length; i++) {
				var status = oModelStatusTable.lines[i].status;
				//אם הסטאטוס ריק, זה כמו פתוח
				if(status === ""){
					status = "0";
				}
				switch(status){
					//פתוח
					case "0":
						saveAndApproveBtnEnabled = true;	
						reOpenMonthBtnEnabled = false;
					break;
					// נשלח לאישור מנהל
					case "1":
						saveAndApproveBtnEnabled = false;	
						reOpenMonthBtnEnabled = true;
					break;
					
					//מנהל אישר
					case "2":
						saveAndApproveBtnEnabled = false;	
						reOpenMonthBtnEnabled = false;
					break;
				}
			}
		}
		
		else{
				saveAndApproveBtnEnabled = false;	
				reOpenMonthBtnEnabled = false;
		}
		
		oModelUserHeaderData.setProperty("/saveAndApproveBtnEnabled",saveAndApproveBtnEnabled);
		oModelUserHeaderData.setProperty("/reOpenMonthBtnEnabled",reOpenMonthBtnEnabled);
		oModelUserHeaderData.setProperty("/isTblEditabled",saveAndApproveBtnEnabled);
		
	},
	
	// -------------------------------------------------------------------------------------------------------------------------
	
	isEmpMultiPositionOrAssignment : function() {
		
		var oView = this.getView();
		var oModelEmpData = oView.getModel("oModelEmpData");
		var oModelEmpDataTable = oView.getModel("oModelEmpDataTable").getData();
		
		var isEmpMultiAssignment = false;
		
		if(oModelEmpDataTable.lines.length > 1){
			oModelEmpData.setProperty("/isEmpMultiPositionOrAssignment", true);
		}
		else{
			oModelEmpData.setProperty("/isEmpMultiPositionOrAssignment", false);
		}

		for(var i=0; i<oModelEmpDataTable.lines.length; i++) {

			if( oModelEmpDataTable.lines[i].isEmpMultiAssignment){
				isEmpMultiAssignment = true;
				break;
			}
		}
		oModelEmpData.setProperty("/isEmpMultiAssignment", isEmpMultiAssignment);
	},
	
		
	// -------------------------------------------------------------------------------------------------------------------------
	
	//עבור כל שורת דיווח בחודש בדיקה האם רב שיבוץ או רב מינוי או רב מינוי שהוא גם רב שיבוץ
	isEmpMultiPositionOrAssignmentPerLine : function(row, pernr) {
		
		var oView = this.getView();
		var oModelEmpDataTable = oView.getModel("oModelEmpDataTable").getData();
		var oModelUserHeaderData = oView.getModel("oModelUserHeaderData").getData();

		//בודק אם רב מינוי ברמת הכותרת
		if(oModelUserHeaderData.isEmpMultiPosition){
			
			//עוד אינדיקציה למצב שרב מינוי מוסיף שורה ואז הוא צריך לראות את רשימת הבחירה של יחידה כמו רב שיבוץ אבל עדיין הוא לא רב שיבוץ
			row.isEmpMultiAssignmentPerRow = false;
			row.isEmpMultiAssignmentDisplayPerRow = false;
			
			row.isEmpMultiPositionDisplayPerRow = true;
		}
				
		for(var i=0; i<oModelEmpDataTable.lines.length; i++) {
				if(pernr === oModelEmpDataTable.lines[i].pernr){
					//במספר עובד שמסומן רב שיבוץ הוא מבטל את הרב מינוי
					if(oModelEmpDataTable.lines[i].isEmpMultiAssignment){
						row.isEmpMultiAssignmentPerRow = true;
						row.isEmpMultiAssignmentDisplayPerRow = true;
						
						row.isEmpMultiPositionDisplayPerRow = false;
						break;
					}
				}
		}

	},
	
	// -------------------------------------------------------------------------------------------------------------------------
	onHourChange: function(e) {
		debugger;
		var oView = this.getView();
		var oCtrl = oView.getController();
		var bCellOK = true;
		
		var iCurrentIndex = e.getSource().getParent().getParent().getIndex();
        
        var oBindingContext = e.getSource().getBindingContext("oModelEmpAttendanceTable");
		var oModel = oBindingContext.getModel();
        var oMyModelData = oModel.getData().lines;
        
		var oCell, sHour, sColName, sHourType, sTimePicker;
		var oSiblingCell, sSiblingHour, sSiblingColName, sSiblingTimePicker;
		//e.getSource().getValue(); current LiveValue 22:00
		//e.getSource()  = "__xmlview0--startHour-__clone3"
		
		var oModelEmpData = oView.getModel("oModelEmpData");
		var isEmpMulti = oModelEmpData.getData().isEmpMultiPositionOrAssignment === true ? 1 : 0;
		
		// startHour, endHour
		if(e.getSource().sId.indexOf("startHour") > -1){
				sColName = "startHour"; 
		}
		else{
			sColName = "endHour"; 
		}
		sHourType = sColName + "Type";   // startHourType, endHourType

		
		if (sHourType==="startHourType") {
			oCell = jQuery("#" + e.getSource().oParent.oParent.mAggregations.cells[TableCells.START_HOUR + isEmpMulti].mAggregations.items[0].sId).closest(".clalitNotValid").closest( "td" );
			oSiblingCell = jQuery("#" + e.getSource().oParent.oParent.mAggregations.cells[TableCells.END_HOUR + isEmpMulti].mAggregations.items[0].sId).closest(".clalitNotValid").closest( "td" );
			
			sTimePicker = oView.byId(e.getSource().sId);
			sSiblingTimePicker = oView.byId(e.getSource().oParent.oParent.mAggregations.cells[TableCells.END_HOUR + isEmpMulti].mAggregations.items[0].sId);
			
			sSiblingColName = "endHour";
			
		    sHour = oMyModelData[iCurrentIndex].clockInDisplay;
    	    sSiblingHour = oMyModelData[iCurrentIndex].clockOutDisplay;
    	    
		} else {
			oCell = jQuery("#" + e.getSource().oParent.oParent.mAggregations.cells[TableCells.END_HOUR + isEmpMulti].mAggregations.items[0].sId).closest(".clalitNotValid").closest( "td" );
			oSiblingCell = jQuery("#" + e.getSource().oParent.oParent.mAggregations.cells[TableCells.START_HOUR + isEmpMulti].mAggregations.items[0].sId).closest(".clalitNotValid").closest( "td" );
			
			sTimePicker = oView.byId(e.getSource().sId);
			sSiblingTimePicker = oView.byId(e.getSource().oParent.oParent.mAggregations.cells[TableCells.START_HOUR + isEmpMulti].mAggregations.items[0].sId);
			
			sSiblingColName = "startHour";
			
			sHour = oMyModelData[iCurrentIndex].clockOutDisplay;
    	    sSiblingHour = oMyModelData[iCurrentIndex].clockInDisplay;
		}

		var sMissingValue = MessagePool.ERROR_MSG_MISSING_VALUE;

		// בהתחלה מאפסים את העיצוב מ2 התאים כניסה ויציאה ואז רצים על כל הבדיקות של שגיאות
		oCell.removeClass("clalitInvalidCellValue");
		oSiblingCell.removeClass("clalitInvalidCellValue");
		
		
		oCell.removeClass("clalitManualClock");
		oSiblingCell.removeClass("clalitManualClock");
		
		sTimePicker.mProperties.Value = "";
		sSiblingTimePicker.mProperties.Value = "";
		
		sTimePicker.setValueState(ValueState.None);
		sSiblingTimePicker.setValueState(ValueState.None);
		
		sTimePicker.setValueStateText("");
		sSiblingTimePicker.setValueStateText("");
		
		oMyModelData[iCurrentIndex].endHourMsg = "";
		oMyModelData[iCurrentIndex].startHourMsg = "";
		  		
		  		
		if ((oCtrl.isEmptyCell(sHour, sMissingValue)) && (!oCtrl.isEmptyCell(sSiblingHour, sMissingValue))) { // תא נוכחי ריק ותא שכן מלא
		  oCell.addClass("clalitInvalidCellValue");
		 
		  sTimePicker.mProperties.Value = sMissingValue;
		  sTimePicker.setValueState(ValueState.Error);
		  sTimePicker.setValueStateText(sMissingValue);
		  
		  if(sColName === "startHour"){
		  	oMyModelData[iCurrentIndex].startHourMsg = MessagePool.sMissingValue;
		  }
		  else{
		  	oMyModelData[iCurrentIndex].endHourMsg = MessagePool.sMissingValue;
		  }
		 
          bCellOK = false;
	    }
    	if ((!oCtrl.isEmptyCell(sHour, sMissingValue)) && (oCtrl.isEmptyCell(sSiblingHour, sMissingValue))) { // תא נוכחי מלא ותא שכן ריק
	    	oSiblingCell.addClass("clalitInvalidCellValue"); 
	    	
	    	sSiblingTimePicker.mProperties.Value = sMissingValue;
	    	sSiblingTimePicker.setValueState(ValueState.Error);
			sSiblingTimePicker.setValueStateText(sMissingValue);
			
			if(sColName === "startHour"){
		  		oMyModelData[iCurrentIndex].endHourMsg = sMissingValue;
			}
			else{
		  		oMyModelData[iCurrentIndex].startHourMsg = sMissingValue;
			}
        	bCellOK = false;
	     } 


		  // לאחר העדכון שני התאים ריקים - יש להוריד צביעת תא שכן ולאפס את הערך שלו
		  if (((sSiblingHour === "") || (sSiblingHour === sMissingValue) || (sSiblingHour === null)) && 
			  ((sHour === "") || (sHour === sMissingValue) || (sHour === null))
		  ) 
		  {
			  oSiblingCell.removeClass("clalitInvalidCellValue"); 
			  sSiblingTimePicker.mProperties.Value = "";
			  
			  sSiblingTimePicker.setValueState(ValueState.None);
			  sSiblingTimePicker.setValueStateText("");
			  
			  if(sColName === "startHour"){
		  		oMyModelData[iCurrentIndex].endHourMsg = "";
			  }
			  else{
		  		oMyModelData[iCurrentIndex].startHourMsg = "";
			  }
			  
			  //var oModel = this.getModel("tblModel"); 
			  //var sMyPath = this.getBindingContext("tblModel").getPath(); 
			  //oModel.setProperty(sMyPath + "/" + sSiblingColName, "");
		  }

// -----------------------------------------------------------------------------------------------------------------------------		  
		  // לאחר העדכון שני התאים מכילים ערך חסר ולכן יש להוריד את הצביעה משניהם
		  if (((sSiblingHour === sMissingValue) || (sSiblingHour === "") || (sSiblingHour === null)) && ((sHour === sMissingValue) || (sHour === "") || (sHour === null))) 
		   
		  {
			  oSiblingCell.removeClass("clalitInvalidCellValue"); 
			  sSiblingTimePicker.mProperties.Value = ""; 

			  oCell.removeClass("clalitInvalidCellValue"); 
			  sTimePicker.mProperties.Value = ""; 

			  sSiblingTimePicker.setValueState(ValueState.None);
			  sSiblingTimePicker.setValueStateText("");
			  
			  sTimePicker.setValueState(ValueState.None);
			  sTimePicker.setValueStateText("");
			  
		  	  oMyModelData[iCurrentIndex].endHourMsg = "";
		  	  oMyModelData[iCurrentIndex].startHourMsg = "";

		  }
		// -----------------------------------------------------------------------------------------------------------------------------		  

		  // לאחר העדכון התא השכן ריק והתא הנוכחי מכיל ערך - יש לצבוע תא שכן
		  if (((sSiblingHour === "") || (sSiblingHour === sMissingValue) || (sSiblingHour === null)) && ((sHour !== "") && (sHour !== null))) {
			  oSiblingCell.addClass("clalitInvalidCellValue");  
			  sSiblingTimePicker.mProperties.Value = sMissingValue;
		  }
          
          // check if startHour and endHour are OK
          if (bCellOK) {
          	//במידה ויש ערך ב2 התאים נבדוק ששעת כניסה לא גדולה משעת יציאה - רק במידה ולא סומן מעבר יום
	          if ((sSiblingHour !== sMissingValue) && (sSiblingHour !== "") && (sSiblingHour !== null) && 
	        	  (sHour !== sMissingValue) && (sHour !== "") && (sHour !== null) && oMyModelData[iCurrentIndex].attAbsNum !== GeneralConstants.FOLLOWING_DAY) {
	        	  	if(! oCtrl.isDiffOK(oMyModelData[iCurrentIndex].clockInDisplay, oMyModelData[iCurrentIndex].clockOutDisplay)){
	        	  		sTimePicker.mProperties.Value = sMissingValue;
						sTimePicker.setValueState(ValueState.Error);
						sTimePicker.setValueStateText(MessagePool.ERROR_CHECK_DAY_START_BIGGER_THAN_END);
						if(sColName === "startHour"){
					  		oMyModelData[iCurrentIndex].startHourMsg = MessagePool.ERROR_CHECK_DAY_START_BIGGER_THAN_END;
						}
						else{
					  		oMyModelData[iCurrentIndex].endHourMsg = MessagePool.ERROR_CHECK_DAY_START_BIGGER_THAN_END;
						}
						oCell.addClass("clalitInvalidCellValue");
	        			bCellOK = false;
	        	  	}
	          }
          }
        // -------------------------------------------------------------------------------------------------------------------------
        
			//מאפסים בהתחלה את השגיאה בשדה יחידה ומחשבים מחדש
		 	var oOrgUnitCell = jQuery("#" + e.getSource().oParent.oParent.mAggregations.cells[TableCells.ORG_UNIT].mAggregations.items[0].sId).closest(".clalitNotValid").closest( "td" );
		 	oOrgUnitCell.removeClass("clalitInvalidCellValue");
		 	oMyModelData[iCurrentIndex].orgUnitMsg = "";
				 	
            //במשתמש רב שיבוץ חובה למלא יחידה אירגונית
            if (((sSiblingHour !== sMissingValue) && (sSiblingHour !== "") && (sSiblingHour !== null)) || 
				 ((sHour !== sMissingValue) && (sHour !== "") && (sHour !== null))) {
				 	

				 	
				 	if(oMyModelData[iCurrentIndex].isEmpMultiAssignmentPerRow && (oMyModelData[iCurrentIndex].orgUnit === null || 
				 	oMyModelData[iCurrentIndex].orgUnit.length <= 0 || oMyModelData[iCurrentIndex].orgUnit === GeneralConstants.EMPTY_DROPDOWN_KEY)){
				 		
				 		debugger;
							// var oOrgUnitTag = oView.byId(e.getSource().oParent.oParent.mAggregations.cells[TableCells.ORG_UNIT].mAggregations.items[0].sId);
								 						 		
							// oOrgUnitTag.setValueState(ValueState.Error);
							// oOrgUnitTag.setValueStateText(MessagePool.ERROR_CHECK_DAY_MISSING_ORG_UNIT);
							
							oMyModelData[iCurrentIndex].orgUnitMsg = MessagePool.ERROR_CHECK_DAY_MISSING_ORG_UNIT;	 		
							oOrgUnitCell.addClass("clalitInvalidCellValue");
				 	}
			}
          
          //בודק האם השורה ריקה ללא נוכחות ואז אפשר לבחור היעדרות יום מלא
          var isAbsFullDayEnabled = this.handleAbsFullDayEnabledRow(oMyModelData[iCurrentIndex].dateReport, oMyModelData, true);
          oMyModelData[iCurrentIndex].isAbsFullDayEnabled = isAbsFullDayEnabled;
          oMyModelData[iCurrentIndex].isFullDay = isAbsFullDayEnabled;
	},
	// -------------------------------------------------------------------------------------------------------------------------
	isDiffOK : function(sStart, sEnd) {
		var dTimeStart = new Date("01/01/2007 " + sStart);
		var dTimeEnd = new Date("01/01/2007 " + sEnd);

		var iHourDiff = (dTimeEnd - dTimeStart);

		return (iHourDiff > 0);
	},
	// -------------------------------------------------------------------------------------------------------------------------
	
			openDialog: function (sType, sErrMessage) {
			// var oCommonUtils = new common.CommonUtils();
			// oCommonUtils.closeBusyDialog();
			
			var sTitle = "";
			
			if (sType === "E") {
				sTitle = "שגיאה";
			}
			
			var dialog = new Dialog({
				title: sTitle,
				type: 'Message',
				//state: 'Error',
				icon : "./" + window.clalitEssAttendanceAppVer + "/images/error_outline.svg",
				content: new Text({
					text: "sErrMessage"
				}),
				beginButton: new Button({
					text: 'הבנתי',
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			}).addStyleClass("myDialog").addStyleClass("clalitDialogIcon");

			dialog.open();
		},
		
		
	// -------------------------------------------------------------------------------------------------------------------------
	openConfirmDialog : function(sDlgText, sDlgTitle) {
		
		var oConfirmDialog = new Dialog({
					modal: true,
					width: "340px",
					height: "180px"
				});
	 
		oConfirmDialog.onAfterRendering = function() {
			   if (sap.ui.commons.Dialog.prototype.onAfterRendering) {  
				   sap.ui.commons.Dialog.prototype.onAfterRendering.apply(this, arguments);  
			   }  
			
		};

		oConfirmDialog.setTitle(sDlgTitle); 
		
		var oText = new sap.ui.commons.TextView(
				{text: sDlgText}
		).addStyleClass("clalitDlgTextSize");

		oConfirmDialog.addContent(oText);
		
		oConfirmDialog.addButton(
				new sap.ui.commons.Button({
				 width : "70px",
			     height: "30px",
				 text: MessagePool.DIALOG_SAVE_DATA_BTN_CONFIRM, // אישור
			     press:function() {
			    	 oConfirmDialog.close();
		    	 }
				}).addStyleClass("myDialog").addStyleClass("clalitDialogIcon")
		);

		oConfirmDialog.open();
		
	},
	// -------------------------------------------------------------------------------------------------------------------------
	
	refreshHoursTable : function() {
		
		var oView = this.getView();
			
		var oTable = oView.byId("mainTable");
		oTable.setSelectedIndex(-1);
		
		var oMonthDDBK = oView.byId("monthSelectList");
		var sPeriod = oMonthDDBK.getSelectedKey();
		
		// שליפת נתוני משתמש מכסות ודיווחי שעות
		var oService = new EssAttendanceService(this.getView());
		oService.getEmployeeDataAndAttendance(sPeriod);			   
		//oCtrl.enableDisableButtons();
		
		oView.byId("mainTable").$().find(".sapUiScrollBar > div:eq(0)").scrollTop(0);
 		
 	   // בחירת שורה בטבלת השעות
	   var oModelRowSelection = new sap.ui.model.json.JSONModel();
	   oModelRowSelection.setData({modelData : null});
	   oView.setModel(oModelRowSelection, "oModelRowSelection");

	},
	
	updateRows : function() {
		var oCtrl = this;
		var oView = this.getView();
		
		var sMissingValue = MessagePool.ERROR_MSG_MISSING_VALUE;
		
		var oTable = oView.byId("mainTable");
		
        var iVisibleRowCount = oTable.getVisibleRowCount();  
        var iFirstVisibleRow = oTable.getFirstVisibleRow();
    	
        var oActualRow, oCurrentObj;
        var oStartHourCell, oEndHourCell;
        var oStartHourPicker, oEndHourPicker;
        var sType, oCell;
        
		var oModelEmpData = oView.getModel("oModelEmpData");
		var isEmpMulti = oModelEmpData.getData().isEmpMultiPositionOrAssignment === true ? 1 : 0;
		
		
        for (var i=0; i<iVisibleRowCount; i++) {
        	oActualRow = oTable.getContextByIndex(iFirstVisibleRow + i);
        	
        	if (oActualRow) {
	        	//oCurrentObj = oActualRow.getObject();

	  			oStartHourCell = jQuery("#" + oTable.getRows()[i].getCells()[TableCells.START_HOUR + isEmpMulti].mAggregations.items[0].sId).closest(".clalitNotValid").closest( "td" );
				oEndHourCell = jQuery("#" + oTable.getRows()[i].getCells()[TableCells.END_HOUR + isEmpMulti].mAggregations.items[0].sId).closest(".clalitNotValid").closest( "td" );
			
				oStartHourPicker = oView.byId(oTable.getRows()[i].getCells()[TableCells.START_HOUR + isEmpMulti].mAggregations.items[0].sId);
				oEndHourPicker = oView.byId(oTable.getRows()[i].getCells()[TableCells.END_HOUR + isEmpMulti].mAggregations.items[0].sId);
	  
	            oCtrl.handleRow(oActualRow,
	            				oStartHourCell, 
	            				oEndHourCell, 
	            				oStartHourPicker,
	            				oEndHourPicker,
	            				sMissingValue
	            				
				);


				

        	}
        } // end for loop
	   
	}, // end updateRows

	
	// -------------------------------------------------------------------------------------------------------------------------
		markCheckBeforeSaveErrorsRows : function() {
		var oCtrl = this;
		var oView = this.getView();
		
		var sMissingValue = MessagePool.ERROR_MSG_MISSING_VALUE;
		
		var oTable = oView.byId("mainTable");
		
        var iVisibleRowCount = oTable.getVisibleRowCount();  
        var iFirstVisibleRow = oTable.getFirstVisibleRow();
    	
        var oActualRow, oCurrentObj;
        var oStartHourCell, oEndHourCell;
        var oStartHourPicker, oEndHourPicker;
        var sType, oCell;
        
		var oModelEmpData = oView.getModel("oModelEmpData");
		var isEmpMulti = oModelEmpData.getData().isEmpMultiPositionOrAssignment === true ? 1 : 0;

		var oModelCheckErrors = sap.ui.getCore().getModel("oModelCheckErrors");
		
		if(oModelCheckErrors !== undefined){
			var oModelCheckErrorsTable = oModelCheckErrors.getData().lines;
			var isHasCheckErrors = oModelCheckErrors.getData().lines.length > 0 ? true : false;
	
	debugger;
			if(isHasCheckErrors){
				
				for(var i=0; i<oModelCheckErrorsTable.length; i++){
							
					for (var j=0; j<iVisibleRowCount; j++) {
	        			oActualRow = oTable.getContextByIndex(iFirstVisibleRow + j);
	        			oCurrentObj = oActualRow.getObject();
	        			if (oActualRow) {
				  			oStartHourCell = jQuery("#" + oTable.getRows()[j].getCells()[TableCells.START_HOUR + isEmpMulti].mAggregations.items[0].sId).closest(".clalitNotValid").closest( "td" );
							oEndHourCell = jQuery("#" + oTable.getRows()[j].getCells()[TableCells.END_HOUR + isEmpMulti].mAggregations.items[0].sId).closest(".clalitNotValid").closest( "td" );
						
							oStartHourPicker = oView.byId(oTable.getRows()[j].getCells()[TableCells.START_HOUR + isEmpMulti].mAggregations.items[0].sId);
							oEndHourPicker = oView.byId(oTable.getRows()[j].getCells()[TableCells.END_HOUR + isEmpMulti].mAggregations.items[0].sId);
								
							if(oModelCheckErrorsTable[i].dateReport ===  oCurrentObj.dateReport){
								 
				    			if(oModelCheckErrorsTable[i].clockIn.length === 0 && oModelCheckErrorsTable[i].clockOut.length > 0){
				    				oStartHourCell.addClass("clalitInvalidCellValue");
				    				
					    			oStartHourPicker.mProperties.Value = oModelCheckErrorsTable[i].errorText;
					    			oStartHourPicker.setValueState(ValueState.Error);
									oStartHourPicker.setValueStateText(oModelCheckErrorsTable[i].errorText);
									
									oCurrentObj.startHourMsg = oModelCheckErrorsTable[i].errorText;
									
									break;
				    			}
				    			else if(oModelCheckErrorsTable[i].clockIn.length > 0 && oModelCheckErrorsTable[i].clockOut.length === 0){
				    				oEndHourCell.addClass("clalitInvalidCellValue");
				    				
				    				oEndHourPicker.mProperties.Value = oModelCheckErrorsTable[i].errorText;
					    			oEndHourPicker.setValueState(ValueState.Error);
									oEndHourPicker.setValueStateText(oModelCheckErrorsTable[i].errorText);
									
									oCurrentObj.endHourMsg = oModelCheckErrorsTable[i].errorText;
									break;
				    			}
				    			else{
				    				
				    				oStartHourCell.addClass("clalitInvalidCellValue");
				    				oEndHourCell.addClass("clalitInvalidCellValue"); 
				    				
				    				oStartHourPicker.mProperties.Value = oModelCheckErrorsTable[i].errorText;
					    			oStartHourPicker.setValueState(ValueState.Error);
									oStartHourPicker.setValueStateText(oModelCheckErrorsTable[i].errorText);
									oCurrentObj.startHourMsg = oModelCheckErrorsTable[i].errorText;
									
				    				
				    				oEndHourPicker.mProperties.Value = oModelCheckErrorsTable[i].errorText;
					    			oEndHourPicker.setValueState(ValueState.Error);
									oEndHourPicker.setValueStateText(oModelCheckErrorsTable[i].errorText);
									oCurrentObj.endHourMsg = oModelCheckErrorsTable[i].errorText;
									
									break;
				    			}
				    			
	
							}
		    	
		        
						}
					}
	
					
	
	        	}
	        } // end for loop
		}
		

	   
	}, // end markCheckBeforeSaveErrorsRows

	
	// -------------------------------------------------------------------------------------------------------------------------


	handleRow : function(oActualRow, oStartHourCell, oEndHourCell, oStartHourPicker, oEndHourPicker, sMissingValue) {
		var oCtrl = this;
		var oView = this.getView();
		
    	var oCurrentObj = oActualRow.getObject();
    	
        var sStartHour = oCurrentObj.clockInDisplay;
        var sEndHour = oCurrentObj.clockOutDisplay;
        
        var oModel = oView.getModel("oModelEmpAttendanceTable");

		// בהתחלה מאפסים את העיצוב מ2 התאים כניסה ויציאה ואז רצים על כל הבדיקות של שגיאות
		oStartHourCell.removeClass("clalitInvalidCellValue");
		oEndHourCell.removeClass("clalitInvalidCellValue");
		
		oStartHourPicker.mProperties.Value = "";
		oEndHourPicker.mProperties.Value = "";
		
		oStartHourPicker.setValueState(ValueState.None);
		oEndHourPicker.setValueState(ValueState.None);
		
		oStartHourPicker.setValueStateText("");
		oEndHourPicker.setValueStateText("");
		
		// oMyModelData[iCurrentIndex].endHourMsg = "";
		// oMyModelData[iCurrentIndex].startHourMsg = "";
        
		if ((oCtrl.isEmptyCell(sStartHour, sMissingValue)) && (!oCtrl.isEmptyCell(sEndHour, sMissingValue))) {
        	var sPath = oActualRow.getPath() + "/clockInDisplay";
        	oModel.setProperty(sPath, sMissingValue);

	    	oStartHourCell.addClass("clalitInvalidCellValue"); 
	    	
	    	oStartHourPicker.mProperties.Value = sMissingValue;
	    	oStartHourPicker.setValueState(ValueState.Error);
			oStartHourPicker.setValueStateText(sMissingValue);
			
			sPath = oActualRow.getPath() + "/startHourMsg";
			oModel.setProperty(sPath, sMissingValue);
        }
        
		if ((!oCtrl.isEmptyCell(sStartHour, sMissingValue)) && (oCtrl.isEmptyCell(sEndHour, sMissingValue))) {
        	sPath = oActualRow.getPath() + "/clockOutDisplay";
        	oModel.setProperty(sPath, sMissingValue);
        	
	    	oEndHourCell.addClass("clalitInvalidCellValue"); 
	    	
	    	oEndHourPicker.mProperties.Value = sMissingValue;
	    	oEndHourPicker.setValueState(ValueState.Error);
			oEndHourPicker.setValueStateText(sMissingValue);

			sPath = oActualRow.getPath() + "/endHourMsg";
			oModel.setProperty(sPath, sMissingValue);       
		}

	}, // end handleRow	


	// -------------------------------------------------------------------------------------------------------------------------
		// טיפול בגלילה ותאים עם עיצוב של שגיאות ולידציה
		handleRows : function(bScroll) {
			var oView = this.getView();
			var oTable = oView.byId("mainTable");
			var that = this;
			var oModelEmpData = oView.getModel("oModelEmpData");
			
			var isEmpMulti = oModelEmpData.getData().isEmpMultiPositionOrAssignment === true ? 1 : 0;
			
			jQuery.sap.delayedCall(100, null, function() {
				
				that.unMergeColumns();
				that.mergeColumns(false);
				
				oTable.getRows().forEach(function(row) {
			       	if (row.getBindingContext("oModelEmpAttendanceTable")) {
			            var oCurrentObj = row.getBindingContext("oModelEmpAttendanceTable").getObject();
			            
			            var oStartHour = row.getCells()[TableCells.START_HOUR + isEmpMulti].mAggregations.items[0];
			            var oEndHour = row.getCells()[TableCells.END_HOUR + isEmpMulti].mAggregations.items[0];
			            var oOrgUnit = row.getCells()[TableCells.ORG_UNIT].mAggregations.items[0];
			             
			            
			            var oStartHourCell = jQuery("#" +oStartHour.sId).closest(".clalitNotValid").closest( "td" );
			            var oEndHourCell = jQuery("#" +oEndHour.sId).closest(".clalitNotValid").closest( "td" );
			            var oOrgUnitCell = jQuery("#" +oOrgUnit.sId).closest(".clalitNotValid").closest( "td" );
			            
			            //שעת כניסה
			            if ((oCurrentObj.startHourMsg) && (oCurrentObj.startHourMsg !== ""))  {
			            	oStartHourCell.addClass("clalitInvalidCellValue");
			            	
			            	oStartHour.setValueState(ValueState.Error);
			            	oStartHour.setValueStateText(oCurrentObj.startHourMsg);
						} else {
							oStartHourCell.removeClass("clalitInvalidCellValue");
							
							oStartHour.setValueState(ValueState.None);
			            	oStartHour.setValueStateText("");
						}
						//שעת יציאה
			            if ((oCurrentObj.endHourMsg) && (oCurrentObj.endHourMsg !== ""))  {
			            	oEndHourCell.addClass("clalitInvalidCellValue");
			            	
			            	oEndHour.setValueState(ValueState.Error);
			            	oEndHour.setValueStateText(oCurrentObj.endHourMsg);
						} else {
							oEndHourCell.removeClass("clalitInvalidCellValue");
							
							oEndHour.setValueState(ValueState.None);
			            	oEndHour.setValueStateText("");
						}
						//יחידה
			            if ((oCurrentObj.orgUnitMsg) && (oCurrentObj.orgUnitMsg !== ""))  {
			            	oOrgUnitCell.addClass("clalitInvalidCellValue");
			            	
			            	// oEndHour.setValueState(ValueState.Error);
			            	// oEndHour.setValueStateText(oCurrentObj.endHourMsg);
						} else {
							oOrgUnitCell.removeClass("clalitInvalidCellValue");
							
							// oEndHour.setValueState(ValueState.None);
			    //         	oEndHour.setValueStateText("");
						}
			       	}
				});

				// if (bScroll) {
				// 	oTable.setSelectedIndex(oTable.getFirstVisibleRow());
				// } else {
				// 	oTable.setFirstVisibleRow(oTable.getSelectedIndex());
				// }
				
				
				/*
				if (bScroll) {
					oTable.setSelectedIndex(oTable.getFirstVisibleRow());
				} else if (iSelectedIndex) {
					console.log("abc");
					oTable.setFirstVisibleRow(iSelectedIndex);
				}
				*/
				
	
			});
			
//			console.log("SelectedIndex-->"+oTable.getSelectedIndex().toString());
//			console.log("FirstVisibleRow-->"+oTable.getFirstVisibleRow().toString());
		},
		
		onCheckAbsFullDay : function(e){
			
			
			
		},

		

	// -------------------------------------------------------------------------------------------------------------------------
		// טיפול בתיבת סימון יום היעדרות מלא האם מאופשר או לא - מאופשר רק אם אין שום הזנה של נוכחות בשום שורה באותו תאריך + לא מדובר בדיווח עתידי
		handleAbsFullDayEnabledRow : function(dateReport, attendanceTable, isAfterChangeHour) {
			
			var oView = this.getView();
			//var aMonth = oView.getModel("oModelEmpAttendanceTable").getData().lines;
			var oModelUserHeaderData = oView.getModel("oModelUserHeaderData");
			//אם דיווח עתידי או חודש סגור השדה יום מלא סגור לעריכה
			if(! oModelUserHeaderData.getData().isTblEditabled){
				return false;
			}
			
			
			// שורות שהוזנו עבור יום
			var aDay = attendanceTable.filter(function(value) {
				
				if(isAfterChangeHour){
					return (value.dateReport === dateReport);
				}
				else{
					return (value.Ldate === dateReport);
				}
				
			});
			
			for(var i=0; i<aDay.length; i++){
				
				//אחרי יציאה מתא של כניסה יציאה
				if(isAfterChangeHour){
					//לאפשר רק אם אין נוכחות בשום שורה באותו תאריך
					if((aDay[i].clockInDisplay !== null && aDay[i].clockInDisplay !== undefined && aDay[i].clockInDisplay.length > 0) || (aDay[i].clockOutDisplay !== null && aDay[i].clockOutDisplay !== undefined && aDay[i].clockOutDisplay.length > 0)){
						return false;
					}
					//לאפשר רק אחרי שנבחר היעדרות
					if(aDay[i].attAbsNum === null || aDay[i].attAbsNum.length === 0 || aDay[i].attAbsNum === GeneralConstants.EMPTY_DROPDOWN_KEY || aDay[i].attAbsNum === GeneralConstants.ON_DUTY || aDay[i].attAbsNum === GeneralConstants.FOLLOWING_DAY){
						return false;
					}
					
				}
				//אחרי קריאה של טבלת הנוכחות מהפונקציה 
				else{
					//לאפשר רק אם אין נוכחות בשום שורה באותו תאריך
					if((aDay[i].Begtm !== null && aDay[i].Begtm !== undefined && aDay[i].Begtm.length > 0) || (aDay[i].Endtm !== null && aDay[i].Endtm !== undefined && aDay[i].Endtm.length > 0) || 
					(aDay[i].StartAbs !== null && aDay[i].StartAbs !== undefined && aDay[i].StartAbs.length > 0) || (aDay[i].EndAbs !== null && aDay[i].EndAbs !== undefined && aDay[i].EndAbs.length > 0)){
						return false;
					}
					
					//לאפשר רק אחרי שנבחר היעדרות
					if(aDay[i].attAbsNum === null || aDay[i].AttAbsNum.length === 0 || aDay[i].AttAbsNum === GeneralConstants.EMPTY_DROPDOWN_KEY || aDay[i].AttAbsNum === GeneralConstants.ON_DUTY || aDay[i].AttAbsNum === GeneralConstants.FOLLOWING_DAY){
						return false;
					}

				}
			}
			
			return true;
		}

	});
	
});