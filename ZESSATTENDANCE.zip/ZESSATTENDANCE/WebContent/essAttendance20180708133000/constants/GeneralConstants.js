"use strict";

jQuery.sap.declare("clalit.org.il.ZEssAttendance.constants.GeneralConstants");

clalit.org.il.ZEssAttendance.constants.GeneralConstants =  new function() {
	
		// for Local running
		this.SERVER_URL = "http://sapgwdev.clalit.org.il:8021";
		//for Remote runnig
		//this.SERVER_URL = "";
		
		this.J2EE_SERVER_URL = "";
	
	    this.SERVICE_URL = this.SERVER_URL + "/sap/opu/odata/sap/ZHR_ESS_SELF_REPORTING_SRV_01";
	//    this.TCODE_URL = this.J2EE_SERVER_URL + "/irj/servlet/prt/portal/prtroot/com.sap.portal.appintegrator.sap.Transaction?System=SAP_ERP&GuiType=WebGui&TCode=";
	    this.ERROR_PREFIX =  "--- ";
	    
	    this.DELAY_FOR_FOCUS = 1000; // 1sec
	    
	    this.ACTION_TYPE_CHEACK = "C"; 
	    this.ACTION_TYPE_CREATE = "S"; 
   
	    //בתפקיד
	    this.ON_DUTY = "P111";
	    
	    //מעבר יום
	    this.FOLLOWING_DAY = "P201"; 
	    
	    this.EMPTY_DROPDOWN_KEY = "!!!!";
	
    
};