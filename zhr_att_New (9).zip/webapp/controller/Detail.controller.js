sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"../model/formatter",
	'sap/m/MessageToast',
	"sap/m/library",
	'sap/m/MessageStrip',
	"sap/ui/hani/att/model/MainService"
], function(BaseController, JSONModel, formatter, MessageToast, mobileLibrary,MessageStrip,MainService) {
	"use strict";

	// shortcut for sap.m.URLHelper
	var URLHelper = mobileLibrary.URLHelper;

	function _calculateOrderTotal (fPreviousTotal, oCurrentContext) {
		var fItemTotal = oCurrentContext.getObject().Quantity * oCurrentContext.getObject().UnitPrice;
		return fPreviousTotal + fItemTotal;
	}
	return BaseController.extend("sap.ui.hani.att.controller.Detail", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit : function () {
	
			this._aValidKeys = ["shipping", "processor"];
			var oViewModel = new JSONModel({
				busy : false,
				delay : 0,
				lineItemListTitle : this.getResourceBundle().getText("detailLineItemTableHeading"),
				totalOrderAmount: 0,
				selectedTab: ""
			});

			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);
 
			this.setModel(oViewModel, "detailView");

			this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));
			
			//this.getRouter().getTargets().display("shipping");
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

	 
		onSendEmailPress : function () {
			var oViewModel = this.getModel("detailView");

			URLHelper.triggerEmail(
				null,
				oViewModel.getProperty("/shareSendEmailSubject"),
				oViewModel.getProperty("/shareSendEmailMessage")
			);
		},


		/**
		 * Updates the item count within the line item table's header
		 * @param {object} oEvent an event containing the total number of items in the list
		 * @private
		 */
		onListUpdateFinished : function (oEvent) {
			var sTitle,
				fOrderTotal = 0,
				iTotalItems = oEvent.getParameter("total"),
				oViewModel = this.getModel("detailView"),
				oItemsBinding = oEvent.getSource().getBinding("items"),
				aItemsContext;

			// only update the counter if the length is final
			if (oItemsBinding.isLengthFinal()) {
				if (iTotalItems) {
					sTitle = this.getResourceBundle().getText("detailLineItemTableHeadingCount", [iTotalItems]);
				} else {
					//Display 'Line Items' instead of 'Line items (0)'
					sTitle = this.getResourceBundle().getText("detailLineItemTableHeading");
				}
				oViewModel.setProperty("/lineItemListTitle", sTitle);

				aItemsContext = oItemsBinding.getContexts();
				fOrderTotal = aItemsContext.reduce(_calculateOrderTotal, 0);
				oViewModel.setProperty("/totalOrderAmount", fOrderTotal);
			}

		},

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		/**
		 * Binds the view to the object path and expands the aggregated line items.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched : function (oEvent) {
			var oArguments = oEvent.getParameter("arguments");
			sap.ui.core.BusyIndicator.show();
			this._sObjectId = oArguments.objectId;
			// Don't show two columns when in full screen mode
			if (this.getModel("appView").getProperty("/layout") !== "MidColumnFullScreen") {
				this.getModel("appView").setProperty("/layout", "TwoColumnsBeginExpanded");
			}
			
		  // this.getView().setModel (this.getOwnerComponent().getModel("absTypesModel") , "absTypesModelSetail");
			
			var selectedRecord = this.getSelectedRecord() ;    
			if (selectedRecord.getData()) {
				
				

				this.getView().byId ('attAbsType').setSelectedKey(this.getSelectedRecord().getData().AttType) ;
				this.getEmpDetailSet(selectedRecord.getData().Pernr) ; 
				 /*
				const oCtrl = this;
				const oService = new MainService(this.getView(),false);
				
				let getEmpInf = oService.getEmpDetailsSet(selectedRecord.getData().Pernr); 
				getEmpInf.then(function(oODataResult) {
				if ((oODataResult) && (oODataResult.oData)) {
					sap.ui.core.BusyIndicator.hide();
					if (oODataResult.oResponse.statusCode == "200" ||
					   (oODataResult.oResponse.statusCode === "201") ||
					   (oODataResult.oResponse.statusCode === "202") ||
					   (oODataResult.oResponse.statusCode == "0"))
					{ 				
						let oModel = new JSONModel(oODataResult.oData); 
						this.getView().setModel(oModel , "empDetailsSet") ; 
					} else {
						MessageToast.show('Status Code ${oODataResult.oResponse.statusCode}');
					}
				} else {
					MessageToast.show("No Data");
				}}.bind(oCtrl))
				.catch(function(oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show(oError.message);
				}.bind(oCtrl)) ; 	
				*/
			}			
			 
			let oViewModel = this.getModel("detailView");
            
			let datailParmModel = new JSONModel({addRowButton:true, addedRowBox:false }); 
			this.getView().setModel(datailParmModel , "datailParmModel" ) ; 
			oViewModel.setProperty("/busy", false);
			
	 
			sap.ui.core.BusyIndicator.hide();
			
		},

		/**
		 * Binds the view to the object path. Makes sure that detail view displays
		 * a busy indicator while data for the corresponding element binding is loaded.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound to the view.
		 * @private
		 */
		_bindView : function (sObjectPath) {
			// Set busy indicator during view binding
			var oViewModel = this.getModel("detailView");

			// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
			oViewModel.setProperty("/busy", false);

			this.getView().bindElement({
				path : sObjectPath,
				parameters: {
					expand: "Customer,Order_Details/Product,Employee"
				},
				events: {
					change : this._onBindingChange.bind(this),
					dataRequested : function () {
						oViewModel.setProperty("/busy", true);
					},
					dataReceived: function () {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},

		_onBindingChange : function () {
			var oView = this.getView(),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("detailObjectNotFound");
				// if object could not be found, the selection in the master list
				// does not make sense anymore.
				this.getOwnerComponent().oListSelector.clearMasterListSelection();
				return;
			}

			var sPath = oElementBinding.getPath(),
				oResourceBundle = this.getResourceBundle(),
				oObject = oView.getModel().getObject(sPath),
				sObjectId = oObject.OrderID,
				sObjectName = oObject.OrderID,
				oViewModel = this.getModel("detailView");

			this.getOwnerComponent().oListSelector.selectAListItem(sPath);

			oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
				oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href, oObject.ShipName, oObject.EmployeeID, oObject.CustomerID]));
	
			this.byId('page').getTitleHeading().getParent().addStyleClass('haniHeaderBackground');
	
		},

		_onMetadataLoaded : function () {
			// Store original busy indicator delay for the detail view
			var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
				oViewModel = this.getModel("detailView"),
				oLineItemTable = this.byId("lineItemsList");
			//	iOriginalLineItemTableBusyDelay = oLineItemTable.getBusyIndicatorDelay();

			// Make sure busy indicator is displayed immediately when
			// detail view is displayed for the first time
			oViewModel.setProperty("/delay", 0);
			oViewModel.setProperty("/lineItemTableDelay", 0);

		//	oLineItemTable.attachEventOnce("updateFinished", function() {
				// Restore original busy indicator delay for line item table
		//		oViewModel.setProperty("/lineItemTableDelay", iOriginalLineItemTableBusyDelay);
		//	});

			// Binding the view will set it to not busy - so the view is always busy if it is not bound
			oViewModel.setProperty("/busy", true);
			// Restore original busy indicator delay for the detail view
			oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
			let oView = this.getView() ; 
			oView.byId('msgStrip').removeAllItems() ; 
		},
		
		onTabSelect : function(oEvent){
			/*
			var sSelectedTab = oEvent.getParameter("selectedKey");
			this.getRouter().navTo("object", {
				objectId: this._sObjectId,
				query: {
					tab: sSelectedTab
				}
			}, true); 
			*/
		 
			 
		//	this.getRouter().getTargets().display("processor");
	 
			

		},

		_onHandleTelephonePress : function (oEvent){
			var sNumber = oEvent.getSource().getText();
			URLHelper.triggerTel(sNumber);
		},

		/**
		 * Set the full screen mode to false and navigate to master page
		 */
		onCloseDetailPress: function () {
			this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", false);
			// No item should be selected on master after detail page is closed
			this.getOwnerComponent().oListSelector.clearMasterListSelection();
			this.getRouter().navTo("master");
		},

		/**
		 * Toggle between full and non full screen mode.
		 */
		toggleFullScreen: function () {
			var bFullScreen = this.getModel("appView").getProperty("/actionButtonsInfo/midColumn/fullScreen");
			this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", !bFullScreen);
			if (!bFullScreen) {
				// store current layout and go full screen
				this.getModel("appView").setProperty("/previousLayout", this.getModel("appView").getProperty("/layout"));
				this.getModel("appView").setProperty("/layout", "MidColumnFullScreen");
			} else {
				// reset to previous layout
				this.getModel("appView").setProperty("/layout",  this.getModel("appView").getProperty("/previousLayout"));
			}

		},
		checkDateInOut: function(oInTime, oOuttime) {
			let inTime = oInTime.replace(':','') ; 
			inTime = inTime.substring(0,2) + ":" +  inTime.substring(2,4) ;

			let outTime = oOuttime.replace(':','') ; 
		    outTime = outTime.substring(0,2) + ":" +  outTime.substring(2,4) ;	
			
			if (outTime < inTime ) {
			//	MessageToast.show('זמן יציאה צריך להיות גדול מזמן כניסה');
				var oVC = this.byId("msgStrip");
		
				var oMsgStrip = new MessageStrip( {
					text: "זמן יציאה צריך להיות גדול מזמן כניסה",
					showCloseButton: true,
					showIcon: true,
					type: "Error"
				});

				oVC.addItem(oMsgStrip);
				sap.ui.core.BusyIndicator.hide();
				return false; 
			} else {
				return true ; 
			}			
			
			
		},
		onSavePress: function(oEvent) {
			let dataToUpdate = this.getView().getModel("selectedRecord").getData() ; 
			let oView = this.getView() ; 
			
			oView.byId('msgStrip').removeAllItems() ; 
			
			if (! this.checkDateInOut (dataToUpdate.LtimeIn,dataToUpdate.LtimeOut )){
				return false ; 
			}
			if (! this.checkDateInOut (dataToUpdate.LtimeIn2,dataToUpdate.LtimeOut2 )){
				return false ; 
			}
		 
			if (dataToUpdate.LtimeIn2.length > 0  ||  dataToUpdate.LtimeOut2.length > 0 ) {
				if (! (dataToUpdate.AttType2 )){
					MessageToast.show("חייב לבחור סוג דיווח") ; 
					return; 
				}
			}

			
			let tmp = {
			    "Pdsnr" : parseInt( dataToUpdate.Pdsnr).toString(),
			    "Pernr" : dataToUpdate.Pernr,
			    "Ldate" : "",
			    "Lday" : "",
			    "LclockIn" : "",
			    "LclockOut" : "",
			    "LtimeIn" : dataToUpdate.LtimeIn.indexOf(":") >=0 ? dataToUpdate.LtimeIn.replace(':','')+'00' : dataToUpdate.LtimeIn,
			    "LtimeOut" : dataToUpdate.LtimeOut.indexOf(":") >=0 ? dataToUpdate.LtimeOut.replace(':','')+'00' : dataToUpdate.LtimeOut,
			    "AttType" : dataToUpdate.AttType,
			    "AttType2" : dataToUpdate.AttType2,
			    "Remark" : dataToUpdate.Remark,
			    "Remark2" : dataToUpdate.Remark2,
			    "Status" : "",
			    "TekenCmpl" : "",
			    "LtimeIn2" : dataToUpdate.LtimeIn2.indexOf(":") >=0 ? dataToUpdate.LtimeIn2.replace(':','')+'00' : dataToUpdate.LtimeIn2,
			    "LtimeOut2" : dataToUpdate.LtimeOut2.indexOf(":") >=0 ? dataToUpdate.LtimeOut2.replace(':','')+'00' : dataToUpdate.LtimeOut2
			};
			
			
			if (dataToUpdate.LtimeIn.length > 0 && parseInt ( dataToUpdate.LtimeIn) > 0){
				tmp.OrigfIn ="E" ;
			}
			if (dataToUpdate.LtimeOut.length > 0 && parseInt ( dataToUpdate.LtimeOut) > 0){
				tmp.OrigfOut ="E" ;
			}			
 			if (dataToUpdate.LtimeIn2.length > 0 && parseInt ( dataToUpdate.LtimeIn2) > 0){
				tmp.OrigfIn2 ="E" ;
			}
			if (dataToUpdate.LtimeOut2.length > 0 && parseInt ( dataToUpdate.LtimeOut2) > 0){
				tmp.OrigfOut2 ="E" ;
			}

			const oCtrl = this;
			const oService = new MainService(this.getView(),false);
			
			let updateDayManual = oService.saveEtTypesSet(tmp); 
			updateDayManual.then(function(oODataResult) {
			if ((oODataResult) && (oODataResult.oData)) {
				sap.ui.core.BusyIndicator.hide();
				if (oODataResult.oResponse.statusCode == "200" ||
				   (oODataResult.oResponse.statusCode === "201") ||
				   (oODataResult.oResponse.statusCode === "202") ||
				   (oODataResult.oResponse.statusCode == "0"))
				{ 				
					MessageToast.show('הנתונים עודכנו בהצלחה');
				} else {
					MessageToast.show('Status Code ${oODataResult.oResponse.statusCode}');
				}
			} else {
				MessageToast.show("No Data");
			}}.bind(oCtrl))
			.catch(function(oError) {
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(oError.message);
			}.bind(oCtrl)) ; 	

		},
		onMessagesButtonPress: function(oEvent) {
			var oMessagesButton = oEvent.getSource();
			/*
			if (!this._messagePopover) {
				this._messagePopover = new MessagePopover({
					items: {
						path: "message>/",
						template: new MessagePopoverItem({
							description: "{message>description}",
							type: "{message>type}",
							title: "{message>message}"
						})
					}
				});
				oMessagesButton.addDependent(this._messagePopover);
			}*/
			MessageToast.show ('הנתונים נשמרו') ;
		//	this._messagePopover.toggle(oMessagesButton);
		}, 
		onPressAddRow : function () {
			this.getView().getModel("datailParmModel").setProperty("/addedRowBox", true );
		 	this.getView().getModel("datailParmModel").setProperty("/addRowButton", false );
			//this.getView().byId("addRowButton").setVisible (false) ; 
		}, 
		
		handleChange : function () {
			let oItem = this.getSelectedRecord();
	    	let diff =  this.calculateTimeDifference (oItem.LtimeIn.replace(':' , '' )  , oItem.LtimeOut.replace(':' , '' )  ) ; 
	    	oItem.diffMan1 = diff ;      
	    	
	    	this.setSelectedRecord(oItem) ; 
		}

	});
});