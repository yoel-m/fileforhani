jQuery.sap.declare("model.PRService");
sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/odata/v2/ODataModel"
 
], function(Object, JSONModel, Filter, FilterOperator, ODataModel, GeneralConstants, MessagePool) {
	"use strict";

	return Object.extend("icl.group.com.dashboard.model.service.PRService", {

		metadata: {
			properties: {
				oView: {
					oView: {
						type: "sap.ui.view"
					},
					bMock: {
						type: "boolean",
						defaultValue: false
					},
					sUrl: {
						type: "string"
					}

				}
			}
		},
		// -----------------------------------------------------------------------------------------------------------------
		constructor: function(view, isComponent) {
			this.oView = view;
			this.bMock = false;
			this.isComponent = isComponent; 
			//this.sUrl = GeneralConstants.SERVICE_URL;
			if (!isComponent) {
				this.sUrl = view.getController().getOwnerComponent().getModel().sServiceUrl ; 
			}else{
				this.sUrl = view.getModel().sServiceUrl ; 
			}
			
			//	"http://sapgwdev.clalit.org.il:8021/sap/opu/odata/sap/ZHR_ESS_MENG_REPORTING_SRV";

		},
		
		// ------------------------------------------------------------
		//               Get HeaderSet
		//-------------------------------------------------------------
		getHeaderSet: function (oFilters) {

			var oModel, oCtrl;
			oModel = new JSONModel();
			if (!this.isComponent ){
				oCtrl = this.oView.getController();
			}else{
				oCtrl = this ; 
			}
			
			if (this.bMock) {

				this.sUrl = "./localService/mockdata/CopyOflinesSet.json";

				oModel.loadData(
					this.sUrl,
					null,
					true,
					"GET",
					false,
					true
				);
				
				oModel.attachRequestCompleted(function() {
					oCtrl.getHeaderSetCallback(oModel);
				});
				
			} else { 

				var oModelHeaderSet = new sap.ui.model.odata.v2.ODataModel(this.sUrl);
				oModelHeaderSet.setDefaultCountMode(sap.ui.model.odata.CountMode.None);

				oModelHeaderSet.attachRequestCompleted({
						oView: this.oView,
						oModel: oModel
					},

					function(o, oParams) {
						
						var oResponse = o.getParameter("response");
						if (
							(oResponse.statusCode === "200") ||
							(oResponse.statusCode === "202") ||
							(oResponse.statusCode === "0")
						) {
							var oModelAllData = JSON.parse(o.getParameters("responseText").response.responseText).d.results;
							oModel.setData( oModelAllData);
							oCtrl.getHeaderSetCallback(oParams);
						} else {
							var sError = (oResponse.statusCode).toString() + " --> " + oResponse.message;
							console.log(sError);
							var ERROR_HEADERSET_INVALID = "שגיאה בניסון לשלוף נתוני מקור";
						
							console.log (ERROR_HEADERSET_INVALID);
						//	oCtrl.openDialog("E", ERROR_HEADERSET_INVALID );  // MessagePool.ERROR_HEADERSET_INVALID
						}
					}
				);

				oModelHeaderSet.attachRequestFailed(
					function(o, ofilter) {
						console.log("getHeaderSet");
					}
				);

				oModelHeaderSet.read(
					"/HeaderSet" , {
						filters: oFilters
					}
				);
			}	
		
		},

		getUsersSet: function (oFilters) {

			var oModel, oCtrl;
			oModel = new JSONModel();
			if (!this.isComponent ){
				oCtrl = this.oView.getController();
			}else{
				oCtrl = this ; 
			}
			
			if (this.bMock) {

				this.sUrl = "./localService/mockdata/CopyOflinesSet.json";

				oModel.loadData(
					this.sUrl,
					null,
					true,
					"GET",
					false,
					true
				);
				
				oModel.attachRequestCompleted(function() {
					oCtrl.getUsersSetCallback(oModel);
				});
				
			} else { 

				var oModelUsersSet = new sap.ui.model.odata.v2.ODataModel(this.sUrl);
				oModelUsersSet.setDefaultCountMode(sap.ui.model.odata.CountMode.None);

				oModelUsersSet.attachRequestCompleted({
						oView: this.oView,
						oModel: oModel
					},

					function(o, oParams) {
						
						var oResponse = o.getParameter("response");
						if (
							(oResponse.statusCode === "200") ||
							(oResponse.statusCode === "202") ||
							(oResponse.statusCode === "0")
						) {
							var oModelAllData = JSON.parse(o.getParameters("responseText").response.responseText).d.results;
							oModel.setData( oModelAllData);
							oCtrl.getUsersSetCallback(oParams);
						} else {
							var sError = (oResponse.statusCode).toString() + " --> " + oResponse.message;
							console.log(sError);
							var ERROR_ITEM_SET_DATA_INVALID = "שגיאה בניסון לשלוף נתוני מקור";
						
							console.log (ERROR_HEADERSET_INVALID);
						//	oCtrl.openDialog("E", ERROR_HEADERSET_INVALID );  // MessagePool.ERROR_HEADERSET_INVALID
						}
					}
				);

				oModelUsersSet.attachRequestFailed(
					function(o, ofilter) {
						console.log("getUsersSet");
					}
				);

				oModelUsersSet.read(
					"/UsersSet" , {
						filters: oFilters
					}
				);
			}	
		
		},
		

		// ------------------------------------------------------------
		//               Get items (detail Saction - table)
		//-------------------------------------------------------------
		getItemsSet: function (system , PoNum) {

			var oModel, oCtrl;
			oModel = new JSONModel();
			if (!this.isComponent ){
				oCtrl = this.oView.getController();
			}else{
				oCtrl = this ; 
			}
			
			if (this.bMock) {

				this.sUrl = "./localService/mockdata/CopyOflinesSet.json";

				oModel.loadData(
					this.sUrl,
					null,
					true,
					"GET",
					false,
					true
				);
				
				oModel.attachRequestCompleted(function() {
					oCtrl.getItemsSetCallback(oModel);
				});
				
			} else { 

				var oModelItemsSetData = new sap.ui.model.odata.v2.ODataModel(this.sUrl);
				oModelItemsSetData.setDefaultCountMode(sap.ui.model.odata.CountMode.None);

				oModelItemsSetData.attachRequestCompleted({
						oView: this.oView,
						oModel: oModel
					},

					function(o, oParams) {
						
						var oResponse = o.getParameter("response");
						if (
							(oResponse.statusCode === "200") ||
							(oResponse.statusCode === "202") ||
							(oResponse.statusCode === "0")
						) {
							var oModelAllData = JSON.parse(o.getParameters("responseText").response.responseText).d.results;
							oModel.setData( oModelAllData);
							oCtrl.getItemsSetCallback(oParams);
						} else {
							var sError = (oResponse.statusCode).toString() + " --> " + oResponse.message;
							console.log(sError);
							var ERROR_ITEM_SET_DATA_INVALID = "שגיאה בניסון לשלוף נתוני מקור";
						
							console.log (ERROR_ITEM_SET_DATA_INVALID);
						//	oCtrl.openDialog("E", ERROR_ORG_TEVEN_DATA_INVALID );  // MessagePool.ERROR_ORG_TEVEN_DATA_INVALID
						}
					}
				);

				oModelItemsSetData.attachRequestFailed(
					function(o, ofilter) {
						console.log("getItemsSet");
					}
				);

				oModelItemsSetData.read(
					"/HeaderSet(System='" + system + "',PoNum='" + PoNum +"')/ItemsSet" 
				);
			}	
		
		},

		
		//----------------------------------------------------------
		//              Get specific item 
		//-----------------------------------------------------------



		getChosenItemSet: function (system , PoNum ,PrItem) {

			var oModel, oCtrl;
			oModel = new JSONModel();
			if (!this.isComponent ){
				oCtrl = this.oView.getController();
			}else{
				oCtrl = this ; 
			}
			
			if (this.bMock) {

				this.sUrl = "./localService/mockdata/CopyOflinesSet.json";

				oModel.loadData(
					this.sUrl,
					null,
					true,
					"GET",
					false,
					true
				);
				
				oModel.attachRequestCompleted(function() {
					oCtrl.getChosenItemSetCallback(oModel);
				});
				
			} else { 

				var oModelItemsSetData = new sap.ui.model.odata.v2.ODataModel(this.sUrl);
				oModelItemsSetData.setDefaultCountMode(sap.ui.model.odata.CountMode.None);

				oModelItemsSetData.attachRequestCompleted({
						oView: this.oView,
						oModel: oModel
					},

					function(o, oParams) {
						
						var oResponse = o.getParameter("response");
						if (
							(oResponse.statusCode === "200") ||
							(oResponse.statusCode === "202") ||
							(oResponse.statusCode === "0")
						) {
							var oModelAllData = JSON.parse(o.getParameters("responseText").response.responseText).d.results[0];
							
							var sValue =  oModelAllData.Lfdat  ; 
							/*
							if (!sValue) {
								return "";
							}else {
								var d= sValue + '' ; 
								d= d.replace('/Date(' , '' ) ;
								d= d.replace(')/' , '' ) ; 
								var dDate =  new Date (parseFloat(d)) ; 
								
								var day  = dDate.getDate() ; 
								var year = dDate.getFullYear();
								var month = dDate.getMonth() +1  ; 
								
								if (month < 10 ) {
									month = '0' + month ; 
								}
								
								sValue =  day + "/" + month + "/" + year ;
					
							}			*/		
							oModelAllData.Lfdat = sValue ; 
							oModel.setData( oModelAllData);
							oCtrl.getChosenItemSetCallback(oParams);
						} else {
							var sError = (oResponse.statusCode).toString() + " --> " + oResponse.message;
							console.log(sError);
							var ERROR_ITEM_CHOSEN_SET_DATA_INVALID = "שגיאה בניסון לשלוף נתוני מקור";
						
							console.log (ERROR_ITEM_CHOSEN_SET_DATA_INVALID);
						//	oCtrl.openDialog("E", ERROR_ORG_TEVEN_DATA_INVALID );  // MessagePool.ERROR_ORG_TEVEN_DATA_INVALID
						}
					}
				);

				oModelItemsSetData.attachRequestFailed(
					function(o, ofilter) {
						console.log("getChosenItemSet");
					}
				);
				oModelItemsSetData.read(
					"/ItemsSet(System='" + system + "',PoNum='" + PoNum +"',PoItem='"+ PrItem +"')/ItemSet" 
				);
			}	
		
		},

		getServiceLineSet: function (system , poNum ,poItem) {

			var oModel, oCtrl;
			oModel = new JSONModel();
			if (!this.isComponent ){
				oCtrl = this.oView.getController();
			}else{
				oCtrl = this ; 
			}
			
			if (this.bMock) {

				this.sUrl = "./localService/mockdata/CopyOflinesSet.json";

				oModel.loadData(
					this.sUrl,
					null,
					true,
					"GET",
					false,
					true
				);
				
				oModel.attachRequestCompleted(function() {
					oCtrl.getServiceLineSetCallback(oModel);
				});
				
			} else { 

				var oModelServiceLineSetData = new sap.ui.model.odata.v2.ODataModel(this.sUrl);
				oModelServiceLineSetData.setDefaultCountMode(sap.ui.model.odata.CountMode.None);

				oModelServiceLineSetData.attachRequestCompleted({
						oView: this.oView,
						oModel: oModel
					},

					function(o, oParams) {
						
						var oResponse = o.getParameter("response");
						if (
							(oResponse.statusCode === "200") ||
							(oResponse.statusCode === "202") ||
							(oResponse.statusCode === "0")
						) {
							var oModelAllData = JSON.parse(o.getParameters("responseText").response.responseText).d.results;
							oModel.setData( oModelAllData);
							oCtrl.getServiceLineSetCallback(oParams);
						} else {
							var sError = (oResponse.statusCode).toString() + " --> " + oResponse.message;
							console.log(sError);
							var ERROR_ITEM_SET_DATA_INVALID = "שגיאה בניסון לשלוף נתוני מקור";
						
							console.log (ERROR_ITEM_SET_DATA_INVALID);
						//	oCtrl.openDialog("E", ERROR_ORG_TEVEN_DATA_INVALID );  // MessagePool.ERROR_ORG_TEVEN_DATA_INVALID
						}
					}
				);

				oModelServiceLineSetData.attachRequestFailed(
					function(o, ofilter) {
						console.log("getServiceLineSet");
					}
				);

				oModelServiceLineSetData.read(
					"/ItemSet(System='" + system + "',PoNum='" + poNum +"',PoItem='"+ poItem +"')/ServicesSet" 
				);
			}	
		
		},

		getApprStatusSet: function ( ) {

			var oModel, oCtrl;
			oModel = new JSONModel();
			if (!this.isComponent ){
				oCtrl = this.oView.getController();
			}else{
				oCtrl = this ; 
			}
			
			if (this.bMock) {

				this.sUrl = "./localService/mockdata/CopyOflinesSet.json";

				oModel.loadData(
					this.sUrl,
					null,
					true,
					"GET",
					false,
					true
				);
				
				oModel.attachRequestCompleted(function() {
					oCtrl.getApprStatusSetCallback(oModel);
				});
				
			} else { 

				var oModelApprStatusSet = new sap.ui.model.odata.v2.ODataModel(this.sUrl);
				oModelApprStatusSet.setDefaultCountMode(sap.ui.model.odata.CountMode.None);

				oModelApprStatusSet.attachRequestCompleted({
						oView: this.oView,
						oModel: oModel
					},

					function(o, oParams) {
						
						var oResponse = o.getParameter("response");
						if (
							(oResponse.statusCode === "200") ||
							(oResponse.statusCode === "202") ||
							(oResponse.statusCode === "0")
						) {
							var oModelAllData = JSON.parse(o.getParameters("responseText").response.responseText).d.results;
							oModel.setData( oModelAllData);
							oCtrl.getApprStatusSetCallback(oParams);
						} else {
							var sError = (oResponse.statusCode).toString() + " --> " + oResponse.message;
							console.log(sError);
							var ERROR_ITEM_SET_DATA_INVALID = "שגיאה בניסון לשלוף נתוני מקור";
						
							console.log (ERROR_APPRSTATUSSET_INVALID);
						//	oCtrl.openDialog("E", ERROR_APPRSTATUSSET_INVALID );   
						}
					}
				);

				oModelApprStatusSet.attachRequestFailed(
					function(o, ofilter) {
						console.log("getApprStatusSet");
					}
				);

				oModelApprStatusSet.read(
					"/ApprStatusSet"  
				);
			}	
		
		},
		

		getProcStatusSet: function ( ) {

			var oModel, oCtrl;
			oModel = new JSONModel();
			if (!this.isComponent ){
				oCtrl = this.oView.getController();
			}else{
				oCtrl = this ; 
			}
			
			if (this.bMock) {

				this.sUrl = "./localService/mockdata/CopyOflinesSet.json";

				oModel.loadData(
					this.sUrl,
					null,
					true,
					"GET",
					false,
					true
				);
				
				oModel.attachRequestCompleted(function() {
					oCtrl.getProcStatusSetCallback(oModel);
				});
				
			} else { 

				var oModelProcStatusSet = new sap.ui.model.odata.v2.ODataModel(this.sUrl);
				oModelProcStatusSet.setDefaultCountMode(sap.ui.model.odata.CountMode.None);

				oModelProcStatusSet.attachRequestCompleted({
						oView: this.oView,
						oModel: oModel
					},

					function(o, oParams) {
						
						var oResponse = o.getParameter("response");
						if (
							(oResponse.statusCode === "200") ||
							(oResponse.statusCode === "202") ||
							(oResponse.statusCode === "0")
						) {
							var oModelAllData = JSON.parse(o.getParameters("responseText").response.responseText).d.results;
							oModel.setData( oModelAllData);
							oCtrl.getProcStatusSetCallback(oParams);
						} else {
							var sError = (oResponse.statusCode).toString() + " --> " + oResponse.message;
							console.log(sError);
							var ERROR_ITEM_SET_DATA_INVALID = "שגיאה בניסון לשלוף נתוני מקור";
						
							console.log (ERROR_PROCSTATUSSET_INVALID);
						//	oCtrl.openDialog("E", ERROR_PROCSTATUSSET_INVALID );  // MessagePool.ERROR_PROCSTATUSSET_INVALID
						}
					}
				);

				oModelProcStatusSet.attachRequestFailed(
					function(o, ofilter) {
						console.log("getProcStatusSet");
					}
				);

				oModelProcStatusSet.read(
					"/ProcStatusSet"  
				);
			}	
		
		},
		
		getSystemListSet: function ( ) {

			var oModel, oCtrl;
			oModel = new JSONModel();
			if (!this.isComponent ){
				oCtrl = this.oView.getController();
			}else{
				oCtrl = this ; 
			}
			
			if (this.bMock) {

				this.sUrl = "./localService/mockdata/CopyOflinesSet.json";

				oModel.loadData(
					this.sUrl,
					null,
					true,
					"GET",
					false,
					true
				);
				
				oModel.attachRequestCompleted(function() {
					oCtrl.getSystemListSetCallback(oModel);
				});
				
			} else { 

				var oModelSystemListSet = new sap.ui.model.odata.v2.ODataModel(this.sUrl);
				oModelSystemListSet.setDefaultCountMode(sap.ui.model.odata.CountMode.None);

				oModelSystemListSet.attachRequestCompleted({
						oView: this.oView,
						oModel: oModel
					},

					function(o, oParams) {
						
						var oResponse = o.getParameter("response");
						if (
							(oResponse.statusCode === "200") ||
							(oResponse.statusCode === "202") ||
							(oResponse.statusCode === "0")
						) {
							var oModelAllData = JSON.parse(o.getParameters("responseText").response.responseText).d.results;
							oModel.setData( oModelAllData);
							oCtrl.getSystemListSetCallback(oParams);
						} else {
							var sError = (oResponse.statusCode).toString() + " --> " + oResponse.message;
							console.log(sError);
							var ERROR_ITEM_SET_DATA_INVALID = "שגיאה בניסון לשלוף נתוני מקור";
						
							console.log (ERROR_SYSTEMSET_INVALID);
						//	oCtrl.openDialog("E", ERROR_SYSTEMSET_INVALID );  // MessagePool.ERROR_SYSTEMSET_INVALID
						}
					}
				);

				oModelSystemListSet.attachRequestFailed(
					function(o, ofilter) {
						console.log("getSystemListSet");
					}
				);

				oModelSystemListSet.read(
					"/SystemListSet"  
				);
			}	
		
		}		
		
		
	});
	
	

});