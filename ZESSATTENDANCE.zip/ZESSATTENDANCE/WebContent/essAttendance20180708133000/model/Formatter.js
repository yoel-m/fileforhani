sap.ui.define([
            "sap/ui/base/Object"
], function(Object){
            "use strict";
            debugger;
            return Object.extend("clalit.org.il.ZEssAttendance.essAttendance20180717161000.model.Formatter", {
                        
				statusText: function (sStatus) {
					debugger;
					var that = this;
					
				}


            });

});
