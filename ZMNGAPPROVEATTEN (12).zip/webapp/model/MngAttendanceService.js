jQuery.sap.declare("model.MngAttendanceService");
sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/odata/v2/ODataModel"
 
], function(Object, JSONModel, Filter, FilterOperator, ODataModel, GeneralConstants, MessagePool) {
	"use strict";

	return Object.extend("clalit.org.il.ZEssAttendance.model.service.MngAttendanceService", {

		metadata: {
			properties: {
				oView: {
					oView: {
						type: "sap.ui.view"
					},
					bMock: {
						type: "boolean",
						defaultValue: false
					},
					sUrl: {
						type: "string"
					}

				}
			}
		},
		// -----------------------------------------------------------------------------------------------------------------
		constructor: function(view, isComponent) {
			this.oView = view;
			this.bMock = false;
			this.isComponent = isComponent; 
			//this.sUrl = GeneralConstants.SERVICE_URL;
			if (!isComponent) {
				this.sUrl = view.getController().getOwnerComponent().getModel().sServiceUrl ; 
			}else{
				this.sUrl = view.getModel().sServiceUrl ; 
			}
			
			//	"http://sapgwdev.clalit.org.il:8021/sap/opu/odata/sap/ZHR_ESS_MENG_REPORTING_SRV";

		},

		// -----------------------------------------------------------------------------------------------------------------		
		getMngDep: function (selectedDate) {

			var oModel, oCtrl;
			oModel = new JSONModel();
			if (!this.isComponent ){
				oCtrl = this.oView.getController();
			}else{
				oCtrl = this.oView
			}
			
			if (this.bMock) {

				this.sUrl = "./localService/mockdata/CopyOflinesSet.json";

				oModel.loadData(
					this.sUrl,
					null,
					true,
					"GET",
					false,
					true
				);

				oModel.attachRequestCompleted(function() {
					oCtrl.getSgiraDateCallback(oModel);
				});
				
			} else {

				var oModelMngDepData = new sap.ui.model.odata.v2.ODataModel(this.sUrl);
				oModelMngDepData.setDefaultCountMode(sap.ui.model.odata.CountMode.None);

				oModelMngDepData.attachRequestCompleted({
						oView: this.oView,
						oModel: oModel
					},

					function(o, oParams) {
						
						var oResponse = o.getParameter("response");
						if (
							(oResponse.statusCode === "200") ||
							(oResponse.statusCode === "202") ||
							(oResponse.statusCode === "0")
						) {
							var oModelAllData = JSON.parse(o.getParameters("responseText").response.responseText).d.results;
							oModel.setData( oModelAllData);
							oCtrl.getMngDepCallback(oParams);
						} else {
							var sError = (oResponse.statusCode).toString() + " --> " + oResponse.message;
							console.log(sError);
							var ERROR_ORG_TEVEN_DATA_INVALID = "שגיאה בניסון לשלוף נתוני מקור";
						
							console.log (ERROR_ORG_TEVEN_DATA_INVALID);
						//	oCtrl.openDialog("E", ERROR_ORG_TEVEN_DATA_INVALID );  // MessagePool.ERROR_ORG_TEVEN_DATA_INVALID
						}
					}
				);

				oModelMngDepData.attachRequestFailed(
					function(o, ofilter) {
						//console.log("getSgiraDateFailed");
					}
				);
				var aFilters = [];

				var oFilter1 = new Filter("Month", FilterOperator.EQ, selectedDate );
				//var oFilter2 = new Filter("EmpMainPernr", FilterOperator.EQ, sObjectId );
				aFilters.push(oFilter1);
				//aFilters.push(oFilter2);
 

				oModelMngDepData.read(
					"/dep_mng_listSet", {
						filters: aFilters
						/*
						urlParameters: {
//								'$expand': 'header_linesnav'
							'$expand': 'MngEmployeeListnav'
						}				*/		
					}
				);
				
				/*
				oModelOrgTevenData.read(
					"/orgn_tevenSet?$filter=Ldate eq datetime'2018-07-01T00:00:00'"
				);*/
			}	
		
		},
		// -----------------------------------------------------------------------------------------------------------------
		
		getDepEmplistRefresh : function (selectedDate, ManagerPernr,selectedItem ) {

			var oModel, oCtrl;
			oModel = new JSONModel();
			if (!this.isComponent ){
				oCtrl = this.oView.getController();
			}else{
				oCtrl = this.oView;
			}
			
			if (this.bMock) {

				this.sUrl = "./localService/mockdata/CopyOflinesSet.json";

				oModel.loadData(
					this.sUrl,
					null,
					true,
					"GET",
					false,
					true
				);

				oModel.attachRequestCompleted(function() {
					oCtrl.getSgiraDateCallback(oModel);
				});
				
			} else {

				var oModelEmployeeFromListData = new sap.ui.model.odata.v2.ODataModel(this.sUrl);
				oModelEmployeeFromListData.setDefaultCountMode(sap.ui.model.odata.CountMode.None);

				oModelEmployeeFromListData.attachRequestCompleted({
						oView: this.oView,
						oModel: oModel,
						oSelectedItem : selectedItem
					},

					function(o, oParams) {
						
						var oResponse = o.getParameter("response");
						if (
							(oResponse.statusCode === "200") ||
							(oResponse.statusCode === "202") ||
							(oResponse.statusCode === "0")
						) {
							var oModelAllData = JSON.parse(o.getParameters("responseText").response.responseText).d.results;
							oModel.setData( oModelAllData);
							oCtrl.getDepEmplistRefreshCallback(oParams);
						} else {
							var sError = (oResponse.statusCode).toString() + " --> " + oResponse.message;
							console.log(sError);
							var ERROR_ORG_TEVEN_DATA_INVALID = "שגיאה בניסון לשלוף נתוני מקור";
						
							console.log (ERROR_ORG_TEVEN_DATA_INVALID);
						//	oCtrl.openDialog("E", ERROR_ORG_TEVEN_DATA_INVALID );  // MessagePool.ERROR_ORG_TEVEN_DATA_INVALID
						}
					}
				);

				oModelEmployeeFromListData.attachRequestFailed(
					function(o, ofilter) {
						//console.log("getSgiraDateFailed");
					}
				);
				var aFilters = [];

				var oFilter1 = new Filter("Month", FilterOperator.EQ, selectedDate );
			    var oFilter2 = new Filter("ManagerPernr", FilterOperator.EQ, ManagerPernr );
			    
				aFilters.push(oFilter1);
				aFilters.push(oFilter2);
			

				oModelEmployeeFromListData.read(
					"/Emp_listSet", {
						filters: aFilters
					}
				);
			}
		},
		// -----------------------------------------------------------------------------------------------------------------
		
		getDepEmplist : function (selectedDate, ManagerPernr ) {

			var oModel, oCtrl;
			oModel = new JSONModel();
			if (!this.isComponent ){
				oCtrl = this.oView.getController();
			}else{
				oCtrl = this.oView;
			}
			
			if (this.bMock) {

				this.sUrl = "./localService/mockdata/CopyOflinesSet.json";

				oModel.loadData(
					this.sUrl,
					null,
					true,
					"GET",
					false,
					true
				);

				oModel.attachRequestCompleted(function() {
					oCtrl.getSgiraDateCallback(oModel);
				});
				
			} else {

				var oModelEmployeeFromListData = new sap.ui.model.odata.v2.ODataModel(this.sUrl);
				oModelEmployeeFromListData.setDefaultCountMode(sap.ui.model.odata.CountMode.None);

				oModelEmployeeFromListData.attachRequestCompleted({
						oView: this.oView,
						oModel: oModel
					},

					function(o, oParams) {
						
						var oResponse = o.getParameter("response");
						if (
							(oResponse.statusCode === "200") ||
							(oResponse.statusCode === "202") ||
							(oResponse.statusCode === "0")
						) {
							var oModelAllData = JSON.parse(o.getParameters("responseText").response.responseText).d.results;
							oModel.setData( oModelAllData);
							oCtrl.getDepEmplistCallback(oParams);
						} else {
							var sError = (oResponse.statusCode).toString() + " --> " + oResponse.message;
							console.log(sError);
							var ERROR_ORG_TEVEN_DATA_INVALID = "שגיאה בניסון לשלוף נתוני מקור";
						
							console.log (ERROR_ORG_TEVEN_DATA_INVALID);
						//	oCtrl.openDialog("E", ERROR_ORG_TEVEN_DATA_INVALID );  // MessagePool.ERROR_ORG_TEVEN_DATA_INVALID
						}
					}
				);

				oModelEmployeeFromListData.attachRequestFailed(
					function(o, ofilter) {
						//console.log("getSgiraDateFailed");
					}
				);
				var aFilters = [];

				var oFilter1 = new Filter("Month", FilterOperator.EQ, selectedDate );
			    var oFilter2 = new Filter("ManagerPernr", FilterOperator.EQ, ManagerPernr );
			    
				aFilters.push(oFilter1);
				aFilters.push(oFilter2);
			

				oModelEmployeeFromListData.read(
					"/Emp_listSet", {
						filters: aFilters
					}
				);
			}	
		
		}   ,
		// -----------------------------------------------------------------------------------------------------------------		
		getEmployeeFromList : function (selectedDate, ManagerPernr,  EmpMainPernr ) {

			var oModel, oCtrl;
			oModel = new JSONModel();
			if (!this.isComponent ){
				oCtrl = this.oView.getController();
			}else{
				oCtrl = this.oView;
			}
			
			if (this.bMock) {

				this.sUrl = "./localService/mockdata/CopyOflinesSet.json";

				oModel.loadData(
					this.sUrl,
					null,
					true,
					"GET",
					false,
					true
				);

				oModel.attachRequestCompleted(function() {
					oCtrl.getSgiraDateCallback(oModel);
				});
				
			} else {

				var oModelEmployeeFromListData = new sap.ui.model.odata.v2.ODataModel(this.sUrl);
				oModelEmployeeFromListData.setDefaultCountMode(sap.ui.model.odata.CountMode.None);

				oModelEmployeeFromListData.attachRequestCompleted({
						oView: this.oView,
						oModel: oModel
					},

					function(o, oParams) {
						
						var oResponse = o.getParameter("response");
						if (
							(oResponse.statusCode === "200") ||
							(oResponse.statusCode === "202") ||
							(oResponse.statusCode === "0")
						) {
							var oModelAllData = JSON.parse(o.getParameters("responseText").response.responseText).d.results;
							oModel.setData( oModelAllData);
							oCtrl.getEmployeeFromListCallback(oParams);
						} else {
							var sError = (oResponse.statusCode).toString() + " --> " + oResponse.message;
							console.log(sError);
							var ERROR_ORG_TEVEN_DATA_INVALID = "שגיאה בניסון לשלוף נתוני מקור";
						
							console.log (ERROR_ORG_TEVEN_DATA_INVALID);
						//	oCtrl.openDialog("E", ERROR_ORG_TEVEN_DATA_INVALID );  // MessagePool.ERROR_ORG_TEVEN_DATA_INVALID
						}
					}
				);

				oModelEmployeeFromListData.attachRequestFailed(
					function(o, ofilter) {
						//console.log("getSgiraDateFailed");
					}
				);
				var aFilters = [];

				var oFilter1 = new Filter("Month", FilterOperator.EQ, selectedDate );
			    var oFilter2 = new Filter("EmpMainPernr", FilterOperator.EQ, EmpMainPernr );
			    var oFilter3 = new Filter("ManagerPernr", FilterOperator.EQ, ManagerPernr );
			    
				aFilters.push(oFilter1);
				aFilters.push(oFilter2);
				aFilters.push(oFilter3);
 

				oModelEmployeeFromListData.read(
					"/Emp_listSet", {
						filters: aFilters
						/*
						urlParameters: {
//								'$expand': 'header_linesnav'
							'$expand': 'MngEmployeeListnav'
						}				*/		
					}
				);
				
				/*
				oModelOrgTevenData.read(
					"/orgn_tevenSet?$filter=Ldate eq datetime'2018-07-01T00:00:00'"
				);*/
			}	
		
		}   ,
		
		// -----------------------------------------------------------------------------------------------------------------		
		getEmployeeDataAndAttendance : function (selectedDate, IEmpUname, ManagerPernr) {

			var oModel, oCtrl;
			oModel = new JSONModel();
			if (!this.isComponent ){
				oCtrl = this.oView.getController();
			}else{
				oCtrl = this.oView;
			}
			
			if (this.bMock) {

				this.sUrl = "./localService/mockdata/CopyOflinesSet.json";

				oModel.loadData(
					this.sUrl,
					null,
					true,
					"GET",
					false,
					true
				);

				oModel.attachRequestCompleted(function() {
					oCtrl.getEmployeeAttendanceDataCallback(oModel);
				});
				
			} else {

				var oModelEmployeeAttendanceData = new sap.ui.model.odata.v2.ODataModel(this.sUrl);
				oModelEmployeeAttendanceData.setDefaultCountMode(sap.ui.model.odata.CountMode.None);

				oModelEmployeeAttendanceData.attachRequestCompleted({
						oView: this.oView,
						oModel: oModel
					},

					function(o, oParams) {
						
						var oResponse = o.getParameter("response");
						if (
							(oResponse.statusCode === "200") ||
							(oResponse.statusCode === "202") ||
							(oResponse.statusCode === "0")
						) {
							var oModelAllData = JSON.parse(o.getParameters("responseText").response.responseText).d.results;
							oModel.setData( oModelAllData);
							oCtrl.getEmployeeAttendanceDataCallback(oParams);
						} else {
							var sError = (oResponse.statusCode).toString() + " --> " + oResponse.message;
							console.log(sError);
							var ERROR_ORG_TEVEN_DATA_INVALID = "שגיאה בניסון לשלוף נתוני מקור";
						
							console.log (ERROR_ORG_TEVEN_DATA_INVALID);
						//	oCtrl.openDialog("E", ERROR_ORG_TEVEN_DATA_INVALID );  // MessagePool.ERROR_ORG_TEVEN_DATA_INVALID
						}
					}
				);

				oModelEmployeeAttendanceData.attachRequestFailed(
					function(o, ofilter) {
						//console.log("getSgiraDateFailed");
					}
				);
				var aFilters = [];

				var oFilter1 = new Filter("IMonth", FilterOperator.EQ, selectedDate);
				var oFilter2 = new Filter("IEmpUname", FilterOperator.EQ, IEmpUname);
			    //var oFilter2 = new Filter("Pernr", FilterOperator.EQ, EmpPernr );
			    var oFilter3 = new Filter("IMngPernr", FilterOperator.EQ, ManagerPernr);
			    
				aFilters.push(oFilter1);
				aFilters.push(oFilter2);
				aFilters.push(oFilter3);
				
				oModelEmployeeAttendanceData.read(
					"/HeaderSet", {
						filters: aFilters,
						urlParameters: {
//								'$expand': 'header_linesnav'
							'$expand': 'Emp_linesnav,Header_empnav,Header_Monthlynav,Header_approvnav'
						}
					}
				);

				
				/*
				oModelOrgTevenData.read(
					"/orgn_tevenSet?$filter=Ldate eq datetime'2018-07-01T00:00:00'"
				);*/
			}	
		
		},   
		
	// -----------------------------------------------------------------------------------------------------------------		
		updateMngCommPerLine: function (empUname, dateReport, strComment) {
		//IUname  eq 'EMP3'  and Ldate eq  '20181101' and Comment  eq 'aaa'
			var oModel, oCtrl;
			oModel = new JSONModel();
			if (!this.isComponent ){
				oCtrl = this.oView.getController();
			}else{
				oCtrl = this.oView;
			}
			
			if (this.bMock) {

				this.sUrl = "./localService/mockdata/CopyOflinesSet.json";

				oModel.loadData(
					this.sUrl,
					null,
					true,
					"GET",
					false,
					true
				);

				oModel.attachRequestCompleted(function() {
					oCtrl.updateMngCommPerLineCallback(oModel);
				});
				
			} else {

				var oModelUpdateMngCommPerLineData = new sap.ui.model.odata.v2.ODataModel(this.sUrl);
				oModelUpdateMngCommPerLineData.setDefaultCountMode(sap.ui.model.odata.CountMode.None);

				oModelUpdateMngCommPerLineData.attachRequestCompleted({
						oView: this.oView,
						oModel: oModel
					},

					function(o, oParams) {
						
						var oResponse = o.getParameter("response");
						if (
							(oResponse.statusCode === "200") ||
							(oResponse.statusCode === "202") ||
							(oResponse.statusCode === "0")
						) {
							var oModelAllData = JSON.parse(o.getParameters("responseText").response.responseText).d.results;
							oModel.setData({ "updateMngCommPerLineModel" : oModelAllData});
							oCtrl.updateMngCommPerLineCallback(oParams);
						} else {
							var sError = (oResponse.statusCode).toString() + " --> " + oResponse.message;
							console.log(sError);
						}
					}
				);

				oModelUpdateMngCommPerLineData.attachRequestFailed(
					function(o, ofilter) {
					}
				);
				var aFilters = [];

				var oFilter1 = new Filter("IUname", FilterOperator.EQ, empUname );
				var oFilter2 = new Filter("Ldate", FilterOperator.EQ, dateReport );
				var oFilter3 = new Filter("Comment", FilterOperator.EQ, strComment );
				
				aFilters.push(oFilter1);
				aFilters.push(oFilter2);
				aFilters.push(oFilter3);

				oModelUpdateMngCommPerLineData.read(
					"/Mng_CommSet", {
						filters: aFilters
					}
				);
				
			}	
		
		},         

		// -----------------------------------------------------------------------------------------------------------------		
		getMngHeader: function (selectedDate) {

			var oModel, oCtrl;
			oModel = new JSONModel();
			if (!this.isComponent ){
				oCtrl = this.oView.getController();
			}else{
				oCtrl = this.oView;
			}
			
			if (this.bMock) {

				this.sUrl = "./localService/mockdata/CopyOflinesSet.json";

				oModel.loadData(
					this.sUrl,
					null,
					true,
					"GET",
					false,
					true
				);

				oModel.attachRequestCompleted(function() {
					oCtrl.getMngHeaderCallback(oModel);
				});
				
			} else {

				var oModelMngHeaderData = new sap.ui.model.odata.v2.ODataModel(this.sUrl);
				oModelMngHeaderData.setDefaultCountMode(sap.ui.model.odata.CountMode.None);

				oModelMngHeaderData.attachRequestCompleted({
						oView: this.oView,
						oModel: oModel
					},

					function(o, oParams) {
						
						var oResponse = o.getParameter("response");
						if (
							(oResponse.statusCode === "200") ||
							(oResponse.statusCode === "202") ||
							(oResponse.statusCode === "0")
						) {
							var oModelAllData = JSON.parse(o.getParameters("responseText").response.responseText).d.results;
							oModel.setData( oModelAllData);
							oCtrl.getMngHeaderCallback(oParams);
						} else {
							var sError = (oResponse.statusCode).toString() + " --> " + oResponse.message;
							console.log(sError);
							var ERROR_ORG_TEVEN_DATA_INVALID = "שגיאה בניסון לשלוף נתוני מקור";
						
							console.log (ERROR_ORG_TEVEN_DATA_INVALID);
						//	oCtrl.openDialog("E", ERROR_ORG_TEVEN_DATA_INVALID );  // MessagePool.ERROR_ORG_TEVEN_DATA_INVALID
						}
					}
				);

				oModelMngHeaderData.attachRequestFailed(
					function(o, ofilter) {
						//console.log("getSgiraDateFailed");
					}
				);
				var aFilters = [];

				var oFilter1 = new Filter("Month", FilterOperator.EQ, selectedDate );
				//var oFilter2 = new Filter("EmpMainPernr", FilterOperator.EQ, sObjectId );
				aFilters.push(oFilter1);
				//aFilters.push(oFilter2);
 

				oModelMngHeaderData.read(
					"/dep_mng_listSet", {
						filters: aFilters
						/*
						urlParameters: {
//								'$expand': 'header_linesnav'
							'$expand': 'MngEmployeeListnav'
						}				*/		
					}
				);
				
				/*
				oModelOrgTevenData.read(
					"/orgn_tevenSet?$filter=Ldate eq datetime'2018-07-01T00:00:00'"
				);*/
			}	
		
		}   ,   
		// -----------------------------------------------------------------------------------------------------------------		
		getSgiraDate: function (selectedDate) {

			var oModel, oCtrl;
			oModel = new JSONModel();
			if (!this.isComponent ){
				oCtrl = this.oView.getController();
			}else{
				oCtrl = this.oView
			}
			
			if (this.bMock) {

				this.sUrl = "./localService/mockdata/CopyOflinesSet.json";

				oModel.loadData(
					this.sUrl,
					null,
					true,
					"GET",
					false,
					true
				);

				oModel.attachRequestCompleted(function() {
					oCtrl.getSgiraDateCallback(oModel);
				});
				
			} else {

				var oModelSgiraDatesData = new sap.ui.model.odata.v2.ODataModel(this.sUrl);
				oModelSgiraDatesData.setDefaultCountMode(sap.ui.model.odata.CountMode.None);

				oModelSgiraDatesData.attachRequestCompleted({
						oView: this.oView,
						oModel: oModel
					},

					function(o, oParams) {
						
						var oResponse = o.getParameter("response");
						if (
							(oResponse.statusCode === "200") ||
							(oResponse.statusCode === "202") ||
							(oResponse.statusCode === "0")
						) {
							var oModelAllData = JSON.parse(o.getParameters("responseText").response.responseText).d.results;
							oModel.setData({ "sgiraDatesModel" : oModelAllData});
							oCtrl.getSgiraDateCallback(oParams);
						} else {
							var sError = (oResponse.statusCode).toString() + " --> " + oResponse.message;
							console.log(sError);
							var ERROR_ORG_TEVEN_DATA_INVALID = "שגיאה בניסון לשלוף נתוני מקור";
						
							console.log (ERROR_ORG_TEVEN_DATA_INVALID);
						//	oCtrl.openDialog("E", ERROR_ORG_TEVEN_DATA_INVALID );  // MessagePool.ERROR_ORG_TEVEN_DATA_INVALID
						}
					}
				);

				oModelSgiraDatesData.attachRequestFailed(
					function(o, ofilter) {
						//console.log("getSgiraDateFailed");
					}
				);
				var aFilters = [];

				var oFilter1 = new Filter("Month", FilterOperator.EQ, selectedDate );
				//var oFilter2 = new Filter("EmpMainPernr", FilterOperator.EQ, sObjectId );
				aFilters.push(oFilter1);
				//aFilters.push(oFilter2);
 

				oModelSgiraDatesData.read(
					"/Sgira_datesSet", {
						filters: aFilters
						/*
						urlParameters: {
//								'$expand': 'header_linesnav'
							'$expand': 'MngEmployeeListnav'
						}				*/		
					}
				);
				
				/*
				oModelOrgTevenData.read(
					"/orgn_tevenSet?$filter=Ldate eq datetime'2018-07-01T00:00:00'"
				);*/
			}	
		
		},
		
		// -----------------------------------------------------------------------------------------------------------------		
		approveReportingHours: function (oData) {
			var oModel = new JSONModel();
			 
			var url = "";
				
			var oCtrl =  this.oView.getController();

			if (this.bMock) {
				url = "./localService/mockdata/CopyOflinesSet.json";

				var sResponse = 
				    $.ajax({
				        type: "GET",
				        url: url,
				        async: false
				    }).responseText;
				    

				var oResponse = JSON.parse(sResponse);
				oModel.attachRequestCompleted(
						{ oView : this.oView , oModel : oModel},
						
						function(o, oParams) {
							oCtrl.approveReportingHoursCallback(oParams, oResponse);
						}
				);
					
			    oModel.loadData(
			    		url,
			    		null,
						true,
						"POST"
				);
			} else {
				
					try{
					var oModelApproveReportingHoursData = new ODataModel(this.sUrl);
					oModelApproveReportingHoursData.setDefaultCountMode(sap.ui.model.odata.CountMode.None);
					
					oModelApproveReportingHoursData.attachRequestCompleted(
						{ oView : this.oView , oModel : oModel},
							
						function(o, oParams) {
							oResponse = o.getParameter("response");
							
							if ( 
							   (oResponse.statusCode === "200") ||  
							   (oResponse.statusCode === "201") ||
							   (oResponse.statusCode === "202") ||
							   (oResponse.statusCode === "0")
							   )
							{
								
							    var result = JSON.parse(oResponse.responseText).d;
								oCtrl.approveReportingHoursCallback(result);
								
							} else {
								  var sError = (oResponse.statusCode).toString() + " --> " + oResponse.message; 
							  	  console.log(sError);
								  //oCtrl.openDialog("E", MessagePool.ERROR_WHILE_UPDATING_DATA); 
								
									// var oModelDialog = new JSONModel();
									// oModelDialog.setData(
									// 	{
									// 		"dialogTitle" : MessagePool.ERROR_WHILE_UPDATING_DATA,             
									// 		"dialogMessage" : result.oModel.getData().EMessage
									// 	}
									// );
									
									// sap.ui.getCore().setModel(null, "oModelDialog");
									// sap.ui.getCore().setModel(oModelDialog, "oModelDialog");
					
						
									// if (! this._confirmDialog) {
									// this._confirmDialog = sap.ui.xmlfragment("clalit.org.il.ZEssAttendance." + window.clalitEssAttendanceAppVer + ".fragment.DialogConfirm", this);				
									// }
								
									// this._confirmDialog.addStyleClass("sapUiSizeCompact").addStyleClass("myDialog").addStyleClass("myDialog");
									// this._confirmDialog.open();
	
	
							}
							
						}
					);
					oModelApproveReportingHoursData.create("/Mng_Confirm_attSet", oData);
				}
				
				catch(e){
    			// 			oData.sAppName = "ZESSATTENDANCE";
       //                     oData.sVersion = window.clalitEssAttendanceAppVer;
       //                     oData.sUser = "MAYASH10";
       //                     oData.sSeverity = "ERROR";
       //                     oData.sText = e.message;      
                            
							// this.addLog(oCtrl, oData);
				}
			}
		
		},
		
		// -----------------------------------------------------------------------------------------------------------------		
		cancelApproveHoursReporting: function (period, empUname, strComment) {
		//IMonth eq '201811'  and IEmpUname eq  'EMP3' and IComment eq  'WHY'
			var oModel, oCtrl;
			oModel = new JSONModel();
			if (!this.isComponent ){
				oCtrl = this.oView.getController();
			}else{
				oCtrl = this.oView;
			}
			
			if (this.bMock) {

				this.sUrl = "./localService/mockdata/CopyOflinesSet.json";

				oModel.loadData(
					this.sUrl,
					null,
					true,
					"GET",
					false,
					true
				);

				oModel.attachRequestCompleted(function() {
					oCtrl.cancelApproveHoursReportingCallback(oModel);
				});
				
			} else {

				var oModelCancelApproveHoursReportingData = new sap.ui.model.odata.v2.ODataModel(this.sUrl);
				oModelCancelApproveHoursReportingData.setDefaultCountMode(sap.ui.model.odata.CountMode.None);

				oModelCancelApproveHoursReportingData.attachRequestCompleted({
						oView: this.oView,
						oModelCancelApprove: oModel
					},

					function(o, oParams) {
						
						var oResponse = o.getParameter("response");
						if (
							(oResponse.statusCode === "200") ||
							(oResponse.statusCode === "202") ||
							(oResponse.statusCode === "0")
						) {
							var oModelAllData = JSON.parse(o.getParameters("responseText").response.responseText).d.results;
							oModel.setData(oModelAllData);
							oCtrl.cancelApproveHoursReportingCallback(oParams);
						} else {
							var sError = (oResponse.statusCode).toString() + " --> " + oResponse.message;
							console.log(sError);
						}
					}
				);

				oModelCancelApproveHoursReportingData.attachRequestFailed(
					function(o, ofilter) {
					}
				);
				var aFilters = [];

				var oFilter2 = new Filter("IMonth", FilterOperator.EQ, period );
				var oFilter1 = new Filter("IEmpUname", FilterOperator.EQ, empUname );
				var oFilter3 = new Filter("IComment", FilterOperator.EQ, strComment );
				
				aFilters.push(oFilter1);
				aFilters.push(oFilter2);
				aFilters.push(oFilter3);

				oModelCancelApproveHoursReportingData.read(
					"/Mng_Unconfirm_AttSet", {
						filters: aFilters
					}
				);
				
			}	
		
		},
		
		// -----------------------------------------------------------------------------------------------------------------		
		declineApproveHoursReporting: function (period, empUname, strComment) {
		//IMonth eq '201811'  and IEmpUname eq  'EMP3' and IComment eq  'WHY'
			var oModel, oCtrl;
			oModel = new JSONModel();
			if (!this.isComponent ){
				oCtrl = this.oView.getController();
			}else{
				oCtrl = this.oView;
			}
			
			if (this.bMock) {

				this.sUrl = "./localService/mockdata/CopyOflinesSet.json";

				oModel.loadData(
					this.sUrl,
					null,
					true,
					"GET",
					false,
					true
				);

				oModel.attachRequestCompleted(function() {
					oCtrl.declineHoursReportingCallback(oModel);
				});
				
			} else {

				var oModelDeclineHoursReportingData = new sap.ui.model.odata.v2.ODataModel(this.sUrl);
				oModelDeclineHoursReportingData.setDefaultCountMode(sap.ui.model.odata.CountMode.None);

				oModelDeclineHoursReportingData.attachRequestCompleted({
						oView: this.oView,
						oModelDeclineHoursReporting: oModel
					},

					function(o, oParams) {
						
						var oResponse = o.getParameter("response");
						if (
							(oResponse.statusCode === "200") ||
							(oResponse.statusCode === "202") ||
							(oResponse.statusCode === "0")
						) {
							var oModelAllData = JSON.parse(o.getParameters("responseText").response.responseText).d.results;

							oModel.setData(oModelAllData);
							oCtrl.declineHoursReportingCallback(oParams);
						} else {
							var sError = (oResponse.statusCode).toString() + " --> " + oResponse.message;
							console.log(sError);
						}
					}
				);

				oModelDeclineHoursReportingData.attachRequestFailed(
					function(o, ofilter) {
					}
				);
				var aFilters = [];

				var oFilter2 = new Filter("IMonth", FilterOperator.EQ, period );
				var oFilter1 = new Filter("IEmpUname", FilterOperator.EQ, empUname );
				var oFilter3 = new Filter("IComment", FilterOperator.EQ, strComment );
				
				aFilters.push(oFilter1);
				aFilters.push(oFilter2);
				aFilters.push(oFilter3);

				oModelDeclineHoursReportingData.read(
					"/Mng_return_attSet", {
						filters: aFilters
					}
				);
				
			}
		}

		
		
			



	});
	
	

});