"use strict";

jQuery.sap.declare("util.Formatter");

util.Formatter = {
	
	// -----------------------------------------------------------------------------------------------------------------
	//01/04/2018 ---> 20180401	
	formatDateToYYYYMMDD : function (sPeriod) {
		return sPeriod.substring(6,10) + sPeriod.substring(3,5) + sPeriod.substring(0,2);
	},
	
	// -----------------------------------------------------------------------------------------------------------------
	//04/2018 ---> 201804	
	formatDateToYYYYMM : function (sPeriod) {
		return sPeriod.substring(0,4)+sPeriod.substring(5);
	},
	
	// -----------------------------------------------------------------------------------------------------------------
	//201804 ---> 04/2018	
	formatYYYYMMtoDate : function (sPeriod) {
		return sPeriod.substring(5) + "/" + sPeriod.substring(0,4);
	},
	
	// -----------------------------------------------------------------------------------------------------------------
	
	todayAsYYYYMMDD : function () {
	
	    var dToday = new Date();
	    var iCurrentYear = dToday.getFullYear();
	    var iCurrentMonth = dToday.getMonth() + 1;
	    var iCurrentDay = dToday.getDate();

	    var sToday = 
	    		((iCurrentDay < 10) ? "0" + iCurrentDay.toString() : iCurrentDay.toString()) +
	    	   "/" + 
	    	   ((iCurrentMonth < 10) ? "0" + iCurrentMonth.toString() : iCurrentMonth.toString()) +
	    	   "/" + 
	    	   iCurrentYear.toString();
	    
	    return util.Formatter.formatDateToYYYYMMDD(sToday);
	},
	
	// -----------------------------------------------------------------------------------------------------------------
	
	todayAsYYYYMM : function () {
	    var dToday = new Date();
	    var iCurrentYear = dToday.getFullYear();
	    var iCurrentMonth = dToday.getMonth() + 1;

	    var sToday = 
	    		iCurrentYear.toString() +
	    	   "/" + 
	    	   ((iCurrentMonth < 10) ? "0" + iCurrentMonth.toString() : iCurrentMonth.toString()) ;
	    
	    return util.Formatter.formatDateToYYYYMM(sToday);
	},
	
	// -----------------------------------------------------------------------------------------------------------------
	
	getDefaultPeriod : function() {
		var NUMBER_OF_DAYS_BEFORE_REPLACING_MONTH = 10;
		
		var sMonth;
		
	    var dCurrentDate = new Date();
	    var iCurrentYear = dCurrentDate.getFullYear();
	    var iCurrentMonth = dCurrentDate.getMonth() + 1;
	    var iCurrentDay = dCurrentDate.getDate();
	    
	    if (iCurrentDay<=NUMBER_OF_DAYS_BEFORE_REPLACING_MONTH) {
	    	iCurrentMonth = iCurrentMonth - 1;
	    }
		
	    if (iCurrentMonth < 10) {
	    	sMonth = "0" + iCurrentMonth.toString();
	    } else {
	    	sMonth = iCurrentMonth.toString();
	    }

	    return iCurrentYear.toString() + sMonth;
	},

	// -----------------------------------------------------------------------------------------------------------------
	
	hoursAsHHMM : function(iTotalHours) {
		var iValue = iTotalHours / 3600000; 
		
		var iHours = parseInt(Number(iValue));
		var iMinutes = Math.round((Number(iValue)-iHours) * 60);
		
		var sHours = iHours.toString();
//		if (sHours.length<2) {
//			sHours = "0" + sHours;
//		}
		
		var sMinutes = iMinutes.toString();
		if (sMinutes.length<2) {
			sMinutes = "0" + sMinutes;
		}
		
		var sFormatted = sHours+':'+sMinutes;
		//if (sFormatted === "00:00") {
		if (sFormatted === "0:00") {
			sFormatted = "";
		}
		
		if ((iHours<0) || (iMinutes<0)) {
			sFormatted = "";
		}
		
		return sFormatted;
	},
	
	// -----------------------------------------------------------------------------------------------------------------	  


	  formatSapDate : function(v) {
	        
	        if (v != null ) {
	              v = v.substr(6, 10);
	              var dDate = new Date(v * 1000);
	
	              var iDay = dDate.getDate();
	              var iMonth = dDate.getMonth() + 1;
	              var iYear = dDate.getFullYear();
	
	              var sDay = "";
	              var sMonth = "";
	
	              if (iDay < 10) {
	                    sDay = "0" + iDay.toString();
	              } else {
	                    sDay = iDay.toString();
	              }
	
	              if (iMonth < 10) {
	                    sMonth = "0" + iMonth.toString();
	              } else {
	                    sMonth = iMonth.toString();
	              }
	
	              return sDay + "/" + sMonth + "/" + iYear.toString(); 
	        } else {
	              return "";
	        }
	  },
	  
	// --------------------------------------------------------------------------------------------------------
	
	formatDateToDDslashMMslashYYYY : function (dDate) {
		if (dDate==null) {
			return "";
		} else {
			var iDay = dDate.getDate();
			var iMonth = dDate.getMonth() + 1;
			var iYear = dDate.getFullYear();
			
			var sDay = "";
			var sMonth = "";
	
			if (iDay < 10) {
				sDay = "0" + iDay.toString();
			} else {
				sDay = iDay.toString();
			}
	
			if (iMonth < 10) {
				sMonth = "0" + iMonth.toString();
			} else {
				sMonth = iMonth.toString();
			}
	
			return sDay + "/" + sMonth + "/" + iYear.toString();
		}
	},
	
		// --------------------------------------------------------------------------------------------------------

	// 01/06/2018 --> 2018-06-01T00:00:00
	formatDateToSapDateTime : function (dDate) {
		if (dDate==null) {
			return "";
		} else {
			var iDay = dDate.getDate();
			var iMonth = dDate.getMonth() + 1;
			var iYear = dDate.getFullYear();
			
			var sDay = "";
			var sMonth = "";
	
			if (iDay < 10) {
				sDay = "0" + iDay.toString();
			} else {
				sDay = iDay.toString();
			}
	
			if (iMonth < 10) {
				sMonth = "0" + iMonth.toString();
			} else {
				sMonth = iMonth.toString();
			}
	
			return iYear.toString() + "-" + sMonth + "-" + sDay  + "T00:00:00";
		}
	},
	  
	  
	// -----------------------------------------------------------------------------------------------------------------	  	  
	
	// 080100 --> 08:01
	
	  formatSapToTime : function(val) {
	  	
		  if (val != null && val.length > 0) {
		  	val = val.substr(0,4);
		  	var h = val.substr(0,2);
		  	var m = val.substr(2,4);
		  	
		    return h + ":" + m;
		  }
		  return null;  
	  },
	// -----------------------------------------------------------------------------------------------------------------	  	  
	
	//   09:55 --> 095500
	
	  formatTimeToSap : function(val) {
	  	
		  if (val != null && val.length > 0) {
		  	var h = val.substr(0,2);
		  	var m = val.substr(3,4);
		  	
		    return h + m + "00";
		  }
		  return "";  
	  }



};