"use strict";

jQuery.sap.declare("sap.ui.demo.cart.constants.MessagePool");

sap.ui.demo.cart.constants.MessagePool =  new function() {
	
	this.ERROR_USERDATA_LOCKED = "משתמש נעול";
	this.ERROR_USERDATA_INVALID = "שגיאה בנסיון לשלוף פרטי משתמש";
	this.ERROR_WHILE_UPDATING_DATA = "ארעה שגיאה בתהליך עידכון הנתונים";
	
	this.DIALOG_CONFIRM_CHANGE_MONTH_TITLE = "אישור לפני מעבר לחודש דיווח אחר";
	this.DIALOG_CONFIRM_CHANGE_MONTH_MESSAGE = "במעבר לחודש אחר נתונים שלא נשמרו יימחקו, האם לעבור בכל זאת?";
	// אישור מנהל
	this.DIALOG_CONFIRM_HOURS_TITLE_START = "אישור שעות";
	this.DIALOG_CONFIRM_HOURS_TITLE_END = "אישור שעות - שמירת נתונים";
	//ביטול אישור מנהל
	this.DIALOG_CANCEL_CONFIRM_HOURS_TITLE_START = "ביטול אישור דיווח נוכחות ע''י מנהל";
	this.DIALOG_CANCEL_CONFIRM_HOURS_TITLE_END = "ביטול אישור דיווח נוכחות ע''י מנהל - שמירת נתונים";
	this.DIALOG_CANCEL_CONFIRM_HOURS_MESSAGE_PART1 = "ביטול אישור דיווח נוכחות של העובד:";
	this.DIALOG_CANCEL_CONFIRM_HOURS_MESSAGE_PART2 = "התבטל ע''י מנהל:";
	// דחיית דיווח
	this.DIALOG_DECLINE_HOURS_TITLE_START = "דחיית דיווח נוכחות ע''י מנהל";
	this.DIALOG_DECLINE_HOURS_TITLE_END = "דחיית דיווח נוכחות ע''י מנהל - שמירת נתונים";
	this.DIALOG_DECLINE_HOURS_MESSAGE_PART1 = "דיווח נוכחות של העובד:";
	this.DIALOG_DECLINE_HOURS_MESSAGE_PART2 = "נדחתה ע''י מנהל:";
	
	this.DIALOG_EXPIRED_TIME_TITLE =  "תוקף הדף פג";             
	this.DIALOG_EXPIRED_TIME_MESSAGE =  "השינויים שלא נשמרו יאבדו, לחץ אישור לרענון";
	
	
	this.COLUMN_TYPE_ATTENDANCE = "נוכחות" ;



	
    
};