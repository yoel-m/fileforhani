sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/ui/model/json/JSONModel",
	"sap/ui/hani/att/model/MainService",
	"sap/m/MessageToast"
], function (Controller, History, JSONModel, MainService, MessageToast) {
	"use strict";

	return Controller.extend("sap.ui.hani.att.controller.BaseController", {
		/**
		 * Convenience method for accessing the router in every controller of the application.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter : function () {
			return this.getOwnerComponent().getRouter();
		},

		/**
		 * Convenience method for getting the view model by name in every controller of the application.
		 * @public
		 * @param {string} sName the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel : function (sName) {
			return this.getView().getModel(sName);
		},

		/**
		 * Convenience method for setting the view model in every controller of the application.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel : function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

		/**
		 * Convenience method for getting the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle : function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		/**
		 * Event handler for navigating back.
		 * It there is a history entry we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the master route.
		 * @public
		 */
		onNavBack : function() {
			var sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("master", {}, true);
			}
		},
		setSelectedRecord : function(selectedRecord) {
			var selectedRecordModel = new JSONModel (selectedRecord) ;
			this.getOwnerComponent().setModel(selectedRecordModel , "selectedRecord");
		},
		getSelectedRecord : function() {
			return  this.getOwnerComponent().getModel("selectedRecord");
		},
		setSelectedMonthItems : function(selectedMonthModel) {
			this.getOwnerComponent().setModel(selectedMonthModel , "selectedMonthModel");
		},
		getSelectedMonthItems : function() {
			return  this.getOwnerComponent().getModel("selectedMonthModel");
		},
		setAbsTypesModel : function(AbsTypes) {
			let oModel = new JSONModel(AbsTypes); 
			this.getOwnerComponent().setModel(oModel , "absTypesModel");
		},
		getAbsTypeVal: function(AbsVal) {
			let oModelData = this.getOwnerComponent().getModel("absTypesModel").getData() ; 
			let arrlength = oModelData.length ; 
			let absText = "" ; 
			for (var i=0; i<arrlength; i++) {
				if (oModelData[i].AttType == AbsVal) {
					absText = oModelData[i].Text ; 
					break ; 
				}
			}
			return absText ;
		},

		 calculateTimeDifference : function(time1, time2) {
		 	
		  // formatting 
		  time1 = time1.substr(0,2) + ':' +  time1.substr(2,2) ; 
		  time2 = time2.substr(0,2) + ':' +  time2.substr(2,2) ; 
		  // Parse the time strings into hours and minutes
		  const [hours1, minutes1] = time1.split(':').map(parseFloat);
		  const [hours2, minutes2] = time2.split(':').map(parseFloat);
		
		  // Calculate the total minutes of each time
		  const totalMinutes1 = hours1 * 60 + minutes1;
		  const totalMinutes2 = hours2 * 60 + minutes2;
		
		  // Calculate the difference in minutes
		  const differenceInMinutes = totalMinutes2 - totalMinutes1;
		
		  // Return the difference in minute decimal
		  return parseFloat(differenceInMinutes / 60 ).toFixed(2);
		}, 		
		
		getEmpDetailSet: function(Pernr) {
			const oCtrl = this;
			const oService = new MainService(this.getView(),false);
			
			let getEmpInf = oService.getEmpDetailsSet(Pernr); 
			getEmpInf.then(function(oODataResult) {
			if ((oODataResult) && (oODataResult.oData)) {
				sap.ui.core.BusyIndicator.hide();
				if (oODataResult.oResponse.statusCode == "200" ||
				   (oODataResult.oResponse.statusCode === "201") ||
				   (oODataResult.oResponse.statusCode === "202") ||
				   (oODataResult.oResponse.statusCode == "0"))
				{ 				
					let oModel = new JSONModel(oODataResult.oData); 
					this.getOwnerComponent().setModel(oModel , "empDetailsSet");
				//	this.getView().setModel(oModel , "empDetailsSet") ; 
				} else {
					MessageToast.show('Status Code ${oODataResult.oResponse.statusCode}');
				}
			} else {
				MessageToast.show("No Data");
			}}.bind(oCtrl))
			.catch(function(oError) {
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(oError.message);
			}.bind(oCtrl)) ; 			
		}
		
	});
});