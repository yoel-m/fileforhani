sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("icl.group.comZ_PURCHASE_REQ.controller.View1", {

	});
});