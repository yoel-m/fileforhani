sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
	], function (Object, JSONModel, ODataModel,Filter, FilterOperator) {
	"use strict";
	return Object.extend("sap.ui.demo.masterdetail.model.MainService", {

		// -----------------------------------------------------------------------------------------------------------------
		
		 // TODO: Add metadata (if any)
		metadata: {
			properties: {
				oView: {
					oView: {
						type: "sap.ui.view"
					},
					bMock: {
						type: "boolean",
						defaultValue: false
					},
					sUrl: {
						type: "string"
					}

				}
			}
		},

		// -----------------------------------------------------------------------------------------------------------------

		 // TODO: init properties (if any) 
		 constructor: function(view,isComponent) {
			 //this.oView = view;
	         //this.bMock = false;
	         this.bMock = true;
	         //this.sUrl = GeneralConstants.SERVICE_URL;
	         if (!isComponent) {
				this.sUrl = view.getController().getOwnerComponent().getModel().sServiceUrl ; 
			}else{
				this.sUrl = view.getModel().sServiceUrl ; 
			}
		 },

		 // -----------------------------------------------------------------------------------------------------------------
		 
		 setODataTimerOn: function (nTimeout) {
			 return new Promise((resolve, reject) => {
			     setTimeout(() => { reject({timeout: true}); }, nTimeout);
			 });
		},
		 
		// -----------------------------------------------------------------------------------------------------------------

		getEntitySet: function(entity, filters) {
		    const sUrl = this.sUrl;
		    return new Promise(function(resolve, reject) {
		        const oModel = new ODataModel(sUrl);
		        var aFilters = [];
		
		        // Check if filters array is not empty
		        if (filters && filters.length > 0) {
		            // Loop through the filters array and create a new Filter for each set of parameters
		            filters.forEach(filter => {
		                // Create a new filter object
		                var oFilter = new Filter(filter.parm, filter.op, filter.val);
		                aFilters.push(oFilter);
		            });
		        }
		        sap.ui.core.BusyIndicator.show(0);
		        oModel.read("/" + entity, {
		            filters: aFilters,
		            success: (oData, oResponse) => {
		                resolve({ oData, oResponse });
		            },
		            error: (oError) => {
		                reject(oError);
		            }
		        });
		    });
		},

		
		/*
		getEntitySet: function(param) {
			const sUrl =  this.sUrl ; //  "/sap/opu/odata/sap/ZBO_ODATA_BKPF_SRV/";  ;
            return new Promise(function(resolve, reject) {
               const oModel = new ODataModel(sUrl);
               sap.ui.core.BusyIndicator.show(0);
               oModel.read("/"+ param, {
            	   success: (oData, oResponse)  => resolve({oData  , oResponse}),
                   error:   (oError) => reject(oError)
               });
            });           
		},
		*/

		getRelatedEntitySet: function(fromEntity, parm, toEntity) {
			const sUrl =  this.sUrl ; //  "/sap/opu/odata/sap/ZBO_ODATA_BKPF_SRV/";  ;
            return new Promise(function(resolve, reject) {
               const oModel = new ODataModel(sUrl);
               sap.ui.core.BusyIndicator.show(0);
               oModel.read("/"+fromEntity+ "('" + parm +"')/"+ toEntity, {
            	   success: (oData, oResponse)  => resolve({oData  , oResponse}),
                   error:   (oError) => reject(oError)
               });
            });           
		},			
		getEmpDataSet: function(fMonth, pernr) {
			const sUrl =  this.sUrl ;   
            return new Promise(function(resolve, reject) {
           
               const oModel = new ODataModel(sUrl);

				var aFilters = [];
				var oFilter1 = new Filter("IvMonth", FilterOperator.EQ, fMonth );
				aFilters.push(oFilter1);

				var oFilter2 = new Filter("IvPernr", FilterOperator.EQ, pernr );
				aFilters.push(oFilter2);
               
               sap.ui.core.BusyIndicator.show(0);
               oModel.read("/GetEmpDataSet", {
             	   filters: (aFilters),
            	   success: (oData, oResponse)  => resolve({oData  , oResponse}),
                   error:   (oError) => reject(oError)
               });
            });           
		},

		getEtTypesSet: function(parm) {
			const sUrl =  this.sUrl ; //  "/sap/opu/odata/sap/ZBO_ODATA_BKPF_SRV/";  ;
            return new Promise(function(resolve, reject) {
               const oModel = new ODataModel(sUrl);
				var aFilters = [];


				var oFilter1 = new Filter("IvPernr", FilterOperator.EQ, parm );
				aFilters.push(oFilter1);               
               
               sap.ui.core.BusyIndicator.show(0);
               oModel.read("/EtTypesSet", {
               	   filters: (aFilters),
            	   success: (oData, oResponse)  => resolve({oData  , oResponse}),
                   error:   (oError) => reject(oError)
               });
            });           
		},			
		/*
		getEtTypesSet: function() {
			const sUrl =  this.sUrl ; //  "/sap/opu/odata/sap/ZBO_ODATA_BKPF_SRV/";  ;
            return new Promise(function(resolve, reject) {
               const oModel = new ODataModel(sUrl);
               sap.ui.core.BusyIndicator.show(0);
               oModel.read("/EtTypesSet", {
            	   success: (oData, oResponse)  => resolve({oData  , oResponse}),
                   error:   (oError) => reject(oError)
               });
            });           
		},	
		*/

		saveEtTypesSet: function(oData) {
			const sUrl =  this.sUrl ; //  "/sap/opu/odata/sap/ZBO_ODATA_BKPF_SRV/";  ;		
            return new Promise(function(resolve, reject) {
               const oModel = new ODataModel(sUrl);
			   sap.ui.core.BusyIndicator.show(0);
			   oModel.create("/SetEmpDataSet",oData ,  {
					success: (oData, oResponse)  => resolve({oData, oResponse}),
					error:   (oError) => reject(oError)
			   });
			});           
		}, 	 

		
		
		
		readChecklistEntity: function(path) {
		  var that = this;
					
		  return new Promise(
			function(resolve, reject) {
				    that.getModel().read(path, {
					  success: function(oData) {
					    resolve(oData);
					  },
	                  error: function(oResult) {
					    reject(oResult);
	                  }
	                });
		        });
		},	
		
/*
		getUserDetails: function() {
			const sUrl =  this.sUrl ; //  "/sap/opu/odata/sap/ZBO_ODATA_BKPF_SRV/";  ;
            return new Promise(function(resolve, reject) {
           
               const oModel = new ODataModel(sUrl);
               
               sap.ui.core.BusyIndicator.show(0);
               oModel.read("/GetEmpDataSet", {
            	   success: (oData, oResponse)  => resolve({oData, oResponse}),
                   error:   (oError) => reject(oError)
               });
            });           
		},
	*/
		
		
		// -----------------------------------------------------------------------------------------------------------------
	 
	});
});