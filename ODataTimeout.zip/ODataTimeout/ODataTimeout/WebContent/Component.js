sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"sap/ui/model/json/JSONModel",
	], function(UIComponent, Device, JSONModel) {
	"use strict";

	return UIComponent.extend("clalit.org.il.ODataTimeout.Component", {

		metadata: {
			manifest:
			{
				"_version": "1.1.0",
				"sap.app": {
					"_version": "1.1.0",
					"id": "Materials",
					"type": "application",
					"i18n": "i18n/i18n.properties",
					"applicationVersion": {
						"version": "1.0.0"
					},
					"title": "{{appTitle}}",
					"description": "{{appDescription}}",
					"sourceTemplate": {
						"id": "ui5template.basicSAPUI5ApplicationProject",
						"version": "1.32.0"
					}
				},

				"sap.ui": {
					"_version": "1.1.0",
					"technology": "UI5",
					"icons": {
						"icon": "",
						"favIcon": "",
						"phone": "",
						"phone@2": "",
						"tablet": "",
						"tablet@2": ""
					},
					"deviceTypes": {
						"desktop": true,
						"tablet": true,
						"phone": true
					},
					"supportedThemes": [
						"sap_hcb",
						"sap_bluecrystal"
					]
				},

				"sap.ui5": {
					"_version": "1.1.0",
					"rootView": {
						"viewName":"clalit.org.il.ODataTimeout.view.Main",
						"type": "XML"
					},
					"dependencies": {
						"minUI5Version": "1.30.0",
						"libs": {
							"sap.ui.core": {},
							"sap.m": {},
							"sap.ui.layout": {}
						}
					},
					"contentDensities": {
						"compact": true,
						"cozy": true
					},

					// -------------------------------------------------------------------------------
					// -------------------------------------------------------------------------------
					"resources": {
						"css": [{
							//"uri": "/css/app.css"
						}]
					}
				}

			}
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			UIComponent.prototype.init.apply(this, arguments);
		},
	});

});