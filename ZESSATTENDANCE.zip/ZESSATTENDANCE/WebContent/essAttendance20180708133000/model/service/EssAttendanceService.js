sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/odata/v2/ODataModel",
	"clalit/org/il/ZEssAttendance/constants/GeneralConstants",
	"clalit/org/il/ZEssAttendance/constants/MessagePool"
], function(Object, JSONModel, Filter, FilterOperator, ODataModel, GeneralConstants, MessagePool) {
	"use strict";

	return Object.extend("clalit.org.il.ZEssAttendance.model.service.EssAttendanceService", {

		metadata: {
			properties: {
				oView: {
					oView: {
						type: "sap.ui.view"
					},
					bMock: {
						type: "boolean",
						defaultValue: false
					},
					sUrl: {
						type: "string"
					}

				}
			}
		},
		// -----------------------------------------------------------------------------------------------------------------
		constructor: function(view) {
			this.oView = view;
			this.bMock = false;
			this.sUrl = GeneralConstants.SERVICE_URL;
			//this.sUrl = "http://sapgwdev.clalit.org.il:8021/sap/opu/odata/sap/ZHR_ESS_SELF_REPORTING_SRV";

		},
		// -----------------------------------------------------------------------------------------------------------------
		getEmployeeDataAndAttendance: function(selectedMonth) {
				var oModel, oCtrl;
				oModel = new JSONModel();
				oCtrl = this.oView.getController();
				if (this.bMock) {

					this.sUrl = "./localService/mockdata/CopyOflinesSet.json";

					oModel.loadData(
						this.sUrl,
						null,
						true,
						"GET",
						false,
						true
					);

					oModel.attachRequestCompleted(function() {
						//sap.ui.getCore().setModel(oModel, "kuku");

						oCtrl.getUserDataCallback(oModel);
					});
				} else {

					var oModelUserData = new sap.ui.model.odata.v2.ODataModel(this.sUrl);
					oModelUserData.setDefaultCountMode(sap.ui.model.odata.CountMode.None);

					oModelUserData.attachRequestCompleted({
							oView: this.oView,
							oModel: oModel
						},

						function(o, oParams) {
							
							var oResponse = o.getParameter("response");
							if (
								(oResponse.statusCode === "200") ||
								(oResponse.statusCode === "202") ||
								(oResponse.statusCode === "0")
							) {

								var oModelAllData = JSON.parse(o.getParameters("result").response.responseText).d.results[0];
								oModel.setData(oModelAllData);
								oCtrl.getUserDataCallback(oParams);
							} else {
								var sError = (oResponse.statusCode).toString() + " --> " + oResponse.message;
								console.log(sError);
								oCtrl.openDialog("E", MessagePool.ERROR_USERDATA_INVALID);
							}
						}
					);

					oModelUserData.attachRequestFailed(
						function(o, ofilter) {
							//console.log("attachRequestFailed");
						}
					);
					var aFilters = [];

					var oFilter1 = new Filter("IMonth", FilterOperator.EQ, selectedMonth);
					aFilters.push(oFilter1);

					// var oFilter2 = new Filter("IUname", FilterOperator.EQ, 'MICHALZI');
					// aFilters.push(oFilter2);

					oModelUserData.read(
						"/headerSet", {
							filters: aFilters,
							urlParameters: {
//								'$expand': 'header_linesnav'
								'$expand': 'headerempnav,headerquatanav,Tm_monthlynav,Tm_statusnav,Et_approvalnav,header_linesnav/t554subtynav'
							}
						}
					);

				}

			},
			
		// -----------------------------------------------------------------------------------------------------------------			
			
		saveAttendanceReportData : function(oData) {
			var oModel = new JSONModel();
			 
			var url = "";
				
			var oCtrl =  this.oView.getController();

			if (this.bMock) {
				url = "./localService/mockdata/CopyOflinesSet.json";

				var sResponse = 
				    $.ajax({
				        type: "GET",
				        url: url,
				        async: false
				    }).responseText;
				    

				var oResponse = JSON.parse(sResponse);
				oModel.attachRequestCompleted(
						{ oView : this.oView , oModel : oModel},
						
						function(o, oParams) {
							oCtrl.saveAttendanceDataCallback(oParams, oResponse);
						}
				);
					
			    oModel.loadData(
			    		url,
			    		null,
						true,
						"POST"
				);
			} else {
				var oModelAttendanceData = new ODataModel(this.sUrl);
				oModelAttendanceData.setDefaultCountMode(sap.ui.model.odata.CountMode.None);
				
				oModelAttendanceData.attachRequestCompleted(
					{ oView : this.oView , oModel : oModel},
						
					function(o, oParams) {
						var oResponse = o.getParameter("response");
						
						if ( 
						   (oResponse.statusCode === "200") ||  
						   (oResponse.statusCode === "201") ||
						   (oResponse.statusCode === "202") ||
						   (oResponse.statusCode == "0")
						   )
						{
			debugger;
						    var result = JSON.parse(oResponse.responseText).d;
							oCtrl.saveAttendanceDataCallback(result);
							
						} else {
							var sError = (oResponse.statusCode).toString() + " --> " + oResponse.message; 
							console.log(sError);
							oCtrl.openDialog("E", MessagePool.ERROR_WHILE_UPDATING_DATA); 
						}
						
					}
				);
				oModelAttendanceData.create("/headerSet", oData);
			}
		 },
		// -----------------------------------------------------------------------------------------------------------------


		getPrintFileAttendance: function(selectedMonth) {
				var oModel, oCtrl;
				oModel = new JSONModel();
				oCtrl = this.oView.getController();
				if (this.bMock) {

					this.sUrl = "./localService/mockdata/CopyOflinesSet.json";

					oModel.loadData(
						this.sUrl,
						null,
						true,
						"GET",
						false,
						true
					);

					oModel.attachRequestCompleted(function() {

						oCtrl.getPrintFileAttendanceCallback(oModel);
					});
				} else {

					var oModelPrintData = new sap.ui.model.odata.v2.ODataModel(this.sUrl);
					oModelPrintData.setDefaultCountMode(sap.ui.model.odata.CountMode.None);

					oModelPrintData.attachRequestCompleted({
							oView: this.oView,
							oModel: oModel
						},

						function(o, oParams) {
							
							var oResponse = o.getParameter("response");
							if (
								(oResponse.statusCode === "200") ||
								(oResponse.statusCode === "202") ||
								(oResponse.statusCode === "0")
							) {

								var oModelAllData = JSON.parse(o.getParameters("result").response.responseText).d.results[0];
								oModel.setData(oModelAllData);
								oCtrl.getPrintFileAttendanceCallback(oParams);
							} else {
								var sError = (oResponse.statusCode).toString() + " --> " + oResponse.message;
								console.log(sError);
//								oCtrl.openDialog("E", MessagePool.ERROR_USERDATA_INVALID);

							}
						}
					);

//sap/opu/odata/sap/ZHR_ESS_SELF_REPORTING_SRV_01/Print_fileSet(IMonth='201703')/$value

					oModelPrintData.attachRequestFailed(
						function(o, ofilter) {
							//console.log("attachRequestFailed");
						}
					);
					var aFilters = [];

					var oFilter1 = new Filter("IMonth", FilterOperator.EQ, selectedMonth);
					aFilters.push(oFilter1);

					// var oFilter2 = new Filter("IUname", FilterOperator.EQ, 'MICHALZI');
					// aFilters.push(oFilter2);

					oModelPrintData.read(
						"/Print_fileSet", {
							filters: aFilters,
							urlParameters: {
								'$value': ''
//								'$expand': 'headerempnav,headerquatanav,Tm_monthlynav,Tm_statusnav,Et_approvalnav,header_linesnav/t554subtynav'
							}
						}
					);

				}

			}
		// -----------------------------------------------------------------------------------------------------------------




	});
	
	

});