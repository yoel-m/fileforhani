sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/UIComponent",
	"sap/ui/core/routing/History",
	"sap/m/library",
	"sap/ui/model/json/JSONModel",
	"../model/MainService",
	"sap/m/MessageToast"	
], function (Controller, UIComponent, History, mobileLibrary, JSONModel, MainService, MessageToast  ) {
	"use strict";

	// shortcut for sap.m.URLHelper
	var URLHelper = mobileLibrary.URLHelper;

	return Controller.extend("sap.ui.demo.worklist.controller.BaseController", {
		/**
		 * Convenience method for accessing the router.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter : function () {
			return UIComponent.getRouterFor(this);
		},
 
		getModel : function (sName) {
			return this.getView().getModel(sName);
		},

	 
		setModel : function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

	 
		getResourceBundle : function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},
		
		onNavBack: function () {
			var oHistory, sPreviousHash;

			oHistory = History.getInstance();
			sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				this.getRouter().navTo("worklist", {}, true /*no history*/);
			}
		},
		
		setSelectedEmployeesItems : function(selectedEMPModel) {
			this.getOwnerComponent().setModel(selectedEMPModel , "selectedEmployeesModel");
		},
		getSelectedEmployeesItems : function() {
			return  this.getOwnerComponent().getModel("selectedEmployeesModel");
		},		
		
		setSelectedMonthItems : function(selectedMonthModel) {
			this.getOwnerComponent().setModel(selectedMonthModel , "selectedMonthModel");
		},
		getSelectedMonthItems : function() {
			return  this.getOwnerComponent().getModel("selectedMonthModel");
		},	

		setSelectedListItems : function(selectedListItems) {
			this.getOwnerComponent().setModel(selectedListItems , "selectedListItemsModel");
		},
		getSelectedListItems : function() {
			return  this.getOwnerComponent().getModel("selectedListItemsModel");
		},	

		setSelectedDayItem : function(selectedDayModel) {
			this.getOwnerComponent().setModel(selectedDayModel , "selectedDayModel");
		},
		getSelectedDayItem : function() {
			return  this.getOwnerComponent().getModel("selectedDayModel");
		},	
		
		
		getAbsTypeVal: function(AbsVal) {
			let oModelData = this.getOwnerComponent().getModel("absTypesModel").getData() ; 
			let arrlength = oModelData.length ; 
			let absText = "" ; 
			for (var i=0; i<arrlength; i++) {
				if (oModelData[i].AttType == AbsVal) {
					absText = oModelData[i].Text ; 
					break ; 
				}
			}
			return absText ;
		},		

		 calculateTimeDifference : function(time1, time2) {
		 	
		  // formatting 
		  time1 = time1.substr(0,2) + ':' +  time1.substr(2,2) ; 
		  time2 = time2.substr(0,2) + ':' +  time2.substr(2,2) ; 
		  // Parse the time strings into hours and minutes
		  const [hours1, minutes1] = time1.split(':').map(parseFloat);
		  const [hours2, minutes2] = time2.split(':').map(parseFloat);
		
		  // Calculate the total minutes of each time
		  const totalMinutes1 = hours1 * 60 + minutes1;
		  const totalMinutes2 = hours2 * 60 + minutes2;
		
		  // Calculate the difference in minutes
		  const differenceInMinutes = totalMinutes2 - totalMinutes1;
		
		  // Return the difference in minute decimal
		  return parseFloat(differenceInMinutes / 60 ).toFixed(2);
		}, 	

		getEmpDetailSet: function(Pernr) {
			const oCtrl = this;
			const oService = new MainService(this.getView(),false);
			
			let getEmpInf = oService.getEmpDetailsSet(Pernr); 
			getEmpInf.then(function(oODataResult) {
			if ((oODataResult) && (oODataResult.oData)) {
				sap.ui.core.BusyIndicator.hide();
				if (oODataResult.oResponse.statusCode == "200" ||
				   (oODataResult.oResponse.statusCode === "201") ||
				   (oODataResult.oResponse.statusCode === "202") ||
				   (oODataResult.oResponse.statusCode == "0"))
				{ 				
					let oModel = new JSONModel(oODataResult.oData); 
					this.getOwnerComponent().setModel(oModel , "empDetailsSet");
				//	this.getView().setModel(oModel , "empDetailsSet") ; 
				} else {
					MessageToast.show('Status Code ${oODataResult.oResponse.statusCode}');
				}
			} else {
				MessageToast.show("No Data");
			}}.bind(oCtrl))
			.catch(function(oError) {
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(oError.message);
			}.bind(oCtrl)) ; 			
		},		
		onShareEmailPress : function () {
			var oViewModel = (this.getModel("objectView") || this.getModel("worklistView"));
			URLHelper.triggerEmail(
				null,
				oViewModel.getProperty("/shareSendEmailSubject"),
				oViewModel.getProperty("/shareSendEmailMessage")
			);
		}	
		
	});

});