/* global QUnit */

QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function() {
	"use strict";

	sap.ui.require([
		"icl/group/com/orderbrowser/test/integration/AllJourneys"
	], function() {
		QUnit.start();
	});
});