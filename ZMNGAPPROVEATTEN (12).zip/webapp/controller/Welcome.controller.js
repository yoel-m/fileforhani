sap.ui.define([
	'sap/ui/demo/cart/controller/BaseController',
	'sap/ui/demo/cart/model/cart',
	'sap/ui/model/json/JSONModel',
	'sap/ui/model/Filter',
	'sap/ui/demo/cart/model/formatter',
	'sap/ui/demo/cart/model/MngAttendanceService',
	'sap/ui/model/FilterOperator',
	'sap/ui/demo/cart/constants/GeneralConstants'
], function (BaseController, cart, JSONModel, Filter, formatter, MngAttendanceService, FilterOperator, GeneralConstants) {
	"use strict";

	return BaseController.extend("sap.ui.demo.cart.controller.Welcome", {

		_iCarouselTimeout: 0, // a pointer to the current timeout
		_iCarouselLoopTime: 8000, // loop to next picture after 8 seconds

		formatter: formatter,

		_mFilters: {
			Promoted: [new Filter("Type", "EQ", "Promoted")],
			Viewed: [new Filter("Type", "EQ", "Viewed")],
			Favorite: [new Filter("Type", "EQ", "Favorite")]
		},

		onInit: function () {
			
			var oView = this.getView();
			oView.setModel(sap.ui.getCore().getModel('modelDates'), "modelDates");
			oView.setModel(sap.ui.getCore().getModel('oSelectedMonthModel'), "oSelectedMonthModel");

			this.setSgiraDates();
			this.setMngHeaderDetails();
			
			var oViewModel = new JSONModel({
				welcomeCarouselShipping: 'sap/ui/demo/cart/img/ShopCarouselShipping.jpg',
				welcomeCarouselInviteFriend: 'sap/ui/demo/cart/img/ShopCarouselInviteFriend.jpg',
				welcomeCarouselTablet: 'sap/ui/demo/cart/img/ShopCarouselTablet.jpg',
				welcomeCarouselCreditCard: 'sap/ui/demo/cart/img/ShopCarouselCreditCard.jpg',
				Promoted: [],
				Viewed: [],
				Favorite: [],
				Currency: "EUR"
			});
			this.getView().setModel(oViewModel, "view");
		//	this.getRouter().attachRouteMatched(this._onRouteMatched, this);
		//	this.getRouter().getTarget("welcome").attachDisplay(this._onRouteMatched, this);

			// select random carousel page at start
			/*
			var oWelcomeCarousel = this.byId("welcomeCarousel");
			var iRandomIndex = Math.floor(Math.abs(Math.random()) * oWelcomeCarousel.getPages().length);
			oWelcomeCarousel.setActivePage(oWelcomeCarousel.getPages()[iRandomIndex]);
			*/
		},
		
		setMngHeaderDetails: function(){
			var oView = this.getView();
			var monthSelectedValue = sap.ui.getCore().getModel('oSelectedMonthModel').getData().monthSelectedKey ;                          
			var oService = new MngAttendanceService(oView,false);
			
		    oService.getMngHeader(monthSelectedValue);		
		},
		
		setSgiraDates: function(){
			var oView = this.getView();
			var monthSelectedValue = sap.ui.getCore().getModel('oSelectedMonthModel').getData().monthSelectedKey ;                          
			var oService = new MngAttendanceService(oView,false);
		    oService.getSgiraDate(monthSelectedValue) ;
		    
		    
		    
		    oView.setModel(sap.ui.getCore().getModel('sgiraDatesModel'), "sgiraDatesModel");
		},

		onOpenHelp: function() {
			window.open(GeneralConstants.HELP_URL);
		},
		
		getMngHeaderCallback : function(o) {
			var oView = o.oView;
			var oModel = o.oModel;
		 	
		 	var oMngHeaderDetails = new JSONModel(
				{ "NameMng" :  oModel.getData()[0].NameMng}
			);
			oView.setModel(oMngHeaderDetails, "mngHeaderDetails");		
			
		},
		
		getSgiraDateCallback : function(o) {
			var oView = o.oView;
			var oModel = o.oModel;
		//	var oCtrl = oView.getController();
			
			var oModelData = o.oModel.getData().sgiraDatesModel ;
			oModel.setData(oModelData[0]); 
		//	oView.setModel(oModel, "empDetailModel"); 
			/*
			var sgiraDatesModel = new JSONModel( ) ; 
			sgiraDatesModel.setData(oModelData) ; */
			sap.ui.getCore().setModel(oModel, "sgiraDatesModel");	
	 	oView.setModel(oModel, "sgiraDatesModel");
		},
		
		onReplaceMonthSelected: function(e)  {
			
 
		//	this.getRouter().navTo("home");
		 
			var oModel = this.getModel();
 			var aFilters = [];
 			var month =  this.getView().byId('monthSelectList').getSelectedKey() ; 
			var oFilter1 = new Filter("Month", FilterOperator.EQ, month );
			//var oFilter2 = new Filter("ManagerPernr", FilterOperator.EQ, sId );
			aFilters.push(oFilter1);
		//	aFilters.push(oFilter2);				
			
			var oSelectedMonthModel = sap.ui.getCore().getModel('oSelectedMonthModel');
			oSelectedMonthModel.getData().monthSelectedText =  model.formatter.formatYYYYMMtoDate(month);
			sap.ui.getCore().setModel(oSelectedMonthModel, 'oSelectedMonthModel');
			
			this.setSgiraDates() ; 
			
			oModel.read("/dep_mng_listSet",   {
				filters: aFilters,
			 	success: function (oData) {
			 		var viewHomeModel = sap.ui.getCore().getModel("homeViewModel");		 
			 	  //  var data = viewHomeModel.getData();
			 		var homeView  = sap.ui.getCore().byId(viewHomeModel.getData().homeView) ; 
			 		homeView.getModel('MngDepModel').setData(oData.results);
			 		
			 		
			 		 

				 
				}.bind(this)
			}); 
			
			this.setSgiraDates() ; 
			this.getRouter().navTo("home");
		},
		
		/**
		 * lifecycle hook that will initialize the welcome carousel
		 */
		onAfterRendering: function () {
			this.onCarouselPageChanged();
		},

		_onRouteMatched: function (oEvent) {
			// we do not need to call this function if the url hash refers to product or cart product
			/*
			if (oEvent.getParameter("name") !== "product" && oEvent.getParameter("name") !== "cartProduct") {
				var aPromotedData = this.getView().getModel("view").getProperty("/Promoted");
				if (!aPromotedData.length) {
					var oModel = this.getModel();
					Object.keys(this._mFilters).forEach(function (sFilterKey) {
						oModel.read("/FeaturedProducts", {
							urlParameters: {
								"$expand": "Product"
							},
							filters: this._mFilters[sFilterKey],
							success: function (oData) {
								this.getModel("view").setProperty("/" + sFilterKey, oData.results);
								if (sFilterKey === "Promoted") {
									this._selectPromotedItems();
								}
							}.bind(this)
						});
					}.bind(this));
				}
			}*/
		},

		/**
		 * clear previous animation and initialize the loop animation of the welcome carousel
		 */
		onCarouselPageChanged: function () {
			clearTimeout(this._iCarouselTimeout);
			this._iCarouselTimeout = setTimeout(function () {
				var oWelcomeCarousel = this.byId("welcomeCarousel");
				if (oWelcomeCarousel) {
					oWelcomeCarousel.next();
					this.onCarouselPageChanged();
				}
			}.bind(this), this._iCarouselLoopTime);
		},

		/**
		 * Event handler to determine which link the user has clicked
		 * @param {sap.ui.base.Event} oEvent the press event of the link
		 */
		onSelectProduct: function (oEvent) {
			var oContext = oEvent.getSource().getBindingContext("view");
			var sCategoryId = oContext.getProperty("Product/Category");
			var sProductId = oContext.getProperty("Product/ProductId");
			this.getRouter().navTo("product", {
				id: sCategoryId,
				productId: sProductId
			});
		},
		/**
		 * Navigates to the category page on phones
		 */
		onShowCategories: function () {
			this.getRouter().navTo("categories");
		},
		/**
		 * Event handler to determine which button was clicked
		 * @param {sap.ui.base.Event} oEvent the button press event
		 */
		onAddButtonPress: function (oEvent) {
			var oResourceBundle = this.getModel("i18n").getResourceBundle();
			var oProduct = oEvent.getSource().getBindingContext("view").getObject();
			var oCartModel = this.getModel("cartProducts");
			cart.addToCart(oResourceBundle, oProduct, oCartModel);
		},

		/**
		 * Select two random elements from the promoted products array
		 * @private
		 */
		_selectPromotedItems: function () {
			var aPromotedItems = this.getView().getModel("view").getProperty("/Promoted");
			var iRandom1, iRandom2 = Math.floor(Math.random() * aPromotedItems.length);
			do {
				iRandom1 = Math.floor(Math.random() * aPromotedItems.length);
			} while (iRandom1 === iRandom2);
			this.getModel("view").setProperty("/Promoted", [aPromotedItems[iRandom1], aPromotedItems[iRandom2]]);
		}
	});
});