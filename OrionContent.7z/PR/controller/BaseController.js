sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"../model/PRService",
	"sap/ui/core/routing/History",
	"sap/ui/model/json/JSONModel"
], function (Controller,PRService, History,JSONModel) {
	"use strict";

	return Controller.extend("icl.group.com.PurchaseRequsiotions.controller.BaseController", {
		/**
		 * Convenience method for accessing the router in every controller of the application.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter : function () {
			return this.getOwnerComponent().getRouter();
		},
		
		closeDialog: function (evt) {
		   var oDialog =  evt.getSource().getParent() ; 
		   oDialog.close() ; 
		   oDialog.destroy() ; 
		},
		/*
		searchRequisitionerCreatedBy: function () {
			var userSearchModel =  new JSONModel({
				sReqFirstName:"",
				sReqLastName:"", 
				sReqUserName:"",
				sCreatedByFirstName:"",
				sCreatedByLastName:"", 
				sCreatedByUserName:"" 				
			});	
			this.getView().setModel (userSearchModel,"userReqCreateModel") ;
		},	
		*/
		refreshUserSearchFilds: function () {
			var userSearchModel =  new JSONModel({
				sFirstName:"",
				sLastName:"", 
				sUserName:""
			});	
			this.getView().setModel (userSearchModel,"userSearchModel") ;

		},
		
		fillSearcHelp : function () {
			var oService = new PRService(this.getView(), false );
			oService.getSystemListSet( );		
			oService.getProcStatusSet( );  
			oService.getApprStatusSet( ) ;
		},
		getHeaderSet : function(oFilters) {
			var oService = new PRService(this.getView(), false );
			oService.getHeaderSet(oFilters);
		//	this.getView().getModel("appView").setProperty("/busy", false);   
		},
		getUserSet : function(oFilters) {
			var oService = new PRService(this.getView(), false );
			oService.getUsersSet(oFilters);
		//	this.getView().getModel("appView").setProperty("/busy", false);   
		},
		getApprStatusSetCallback: function (o) {
			var oView = o.oView;
			var oModel = o.oModel;
			oView.setModel (oModel, "apprStatusSetListModel"  ) ; 
		},	
		getUsersSetCallback: function (o) {
			var oView = o.oView;
			var oModel = o.oModel;
			oView.setModel (oModel, "usetSetModel"  ) ; 
			var ctlList = oView.byId("userList") ; 
			ctlList.setBusy(false) ; 
		},	
		getProcStatusSetCallback: function (o) {
			var oView = o.oView;
			var oModel = o.oModel;
			oView.setModel (oModel, "procStatusListModel"  ) ; 
		},			
		getSystemListSetCallback: function (o) {

			var oView = o.oView;
			var oModel = o.oModel;
 
			oView.setModel (oModel, "systemListModel"  ) ; 

			
		},		
		getHeaderSetCallback: function (o) {

			var oView = o.oView;
			var oModel = o.oModel;
			//var ctl = oView.getController() ; 
			
		    //var oViewModel = ctl.getModel("masterView");
			oView.setModel (oModel, "HeaderSet"  ) ; 
			oView.getModel("appView").setProperty("/busy", false);
			
		},

		/**
		 * Convenience method for getting the view model by name in every controller of the application.
		 * @public
		 * @param {string} sName the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel : function (sName) {
			return this.getView().getModel(sName);
		},

		/**
		 * Convenience method for setting the view model in every controller of the application.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel : function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

		/**
		 * Convenience method for getting the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle : function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		formatDate : function (sValue) {
			if (!sValue) {
				return "";
			}else {
				var d= sValue + '' ; 
				d= d.replace('/Date(' , '' ) ;
				d= d.replace(')/' , '' ) ; 
				var dDate =  new Date (parseFloat(d)) ; 
				
				var day  = dDate.getDate() ; 
				var year = dDate.getFullYear();
				var month = dDate.getMonth() +1  ; 
				
				if (month < 10 ) {
					month = '0' + month ; 
				}
				
				return day + "/" + month + "/" + year ;
	
			}
		},	
		/**
		 * Event handler for navigating back.
		 * It there is a history entry we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the master route.
		 * @public
		 */
		onNavBack : function() {
			var sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("master", {}, true);
			}
		}

	});
});