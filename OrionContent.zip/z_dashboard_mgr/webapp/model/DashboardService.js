jQuery.sap.declare("model.DashboardService");
sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/odata/v2/ODataModel"
 
], function(Object, JSONModel, Filter, FilterOperator, ODataModel, GeneralConstants, MessagePool) {
	"use strict";

	return Object.extend("icl.group.com.dashboard.mgr.model.service.DashboardService", {

		metadata: {
			properties: {
				oView: {
					oView: {
						type: "sap.ui.view"
					},
					bMock: {
						type: "boolean",
						defaultValue: false
					},
					sUrl: {
						type: "string"
					}

				}
			}
		},
		// -----------------------------------------------------------------------------------------------------------------
		constructor: function(view, isComponent) {
			this.oView = view;
			this.bMock = false;
			this.isComponent = isComponent; 
			//this.sUrl = GeneralConstants.SERVICE_URL;
			if (!isComponent) {
				this.sUrl = view.getController().getOwnerComponent().getModel().sServiceUrl ; 
			}else{
				this.sUrl = view.getModel().sServiceUrl ; 
			}
			
			//	"http://sapgwdev.clalit.org.il:8021/sap/opu/odata/sap/ZHR_ESS_MENG_REPORTING_SRV";

		},

		//--------------------------------------------

		getPrDetailsSetLevel: function (level , isFirstTime, isCtl) {

			var oModel, oCtrl;
			oModel = new JSONModel();
			if (!this.isComponent ){
				oCtrl = this.oView.getController();
			}else{
				oCtrl = this ; 
			}
			
			if (this.bMock) {

				this.sUrl = "./localService/mockdata/CopyOflinesSet.json";

				oModel.loadData(
					this.sUrl,
					null,
					true,
					"GET",
					false,
					true
				);
				
				oModel.attachRequestCompleted(function() {
					oCtrl.getPrDetailsSetLevelCallback(oModel);
				});
				
			} else {

				var oModelManagerSetData = new sap.ui.model.odata.v2.ODataModel(this.sUrl);
				/*
				oModelManagerSetData.setHeaders(
					{

						"Cookie": "sap-ssolist=O3M9TlNBUEdXRF9HV0RfMDBfMTAw; MYSAPSSO2=AjQxMDMBABhZAE8ARQBMAC0ATQAgACAAIAAgACAAIAACAAYxADAAMAADABBHAFcARAAgACAAIAAgACAABAAYMgAwADIAMAAwADgAMgAwADAAOQAxADMABQAEAAAACAYAAlgACQACRQD%2fAVYwggFSBgkqhkiG9w0BBwKgggFDMIIBPwIBATELMAkGBSsOAwIaBQAwCwYJKoZIhvcNAQcBMYIBHjCCARoCAQEwcDBkMQswCQYDVQQGEwJERTEcMBoGA1UEChMTU0FQIFRydXN0IENvbW11bml0eTETMBEGA1UECxMKU0FQIFdlYiBBUzEUMBIGA1UECxMLSTAwMjA4MTMxODUxDDAKBgNVBAMTA0dXRAIICiAYAxMTJgEwCQYFKw4DAhoFAKBdMBgGCSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTIwMDgyMDA5MTMzM1owIwYJKoZIhvcNAQkEMRYEFD9%2fiSCJK16kTfbLHXIg2QZP9vTYMAkGByqGSM44BAMELjAsAhQ1WUka56T0kh03jp1GRRGhrTzEQQIULy94ptqsiU8eNI%210rzMGKn03ZKQ%3d; sap-usercontext=sap-language=EN&sap-client=100; SAP_SESSIONID_GWD_100=pbQOrLf_1Lu75l7-Da5sbmuYZJri9RHqgQQAUFardMw%3d",
						
						
						
						"Content-Type": "application/atom+xml",
						"DataServiceVersion": "2.0",
						"X-CSRF-Token":"Fetch"
				 
					}
				);
				*/
				oCtrl = this ; 
				oModelManagerSetData.setDefaultCountMode(sap.ui.model.odata.CountMode.None);

				oModelManagerSetData.attachRequestCompleted({
						oView: this.oView,
						oModel: oModel,
						isFirst:isFirstTime,
						isController:isCtl
					},

					function(o, oParams ) {
						
						var oResponse = o.getParameter("response");
						if (
							(oResponse.statusCode === "200") ||
							(oResponse.statusCode === "202") ||
							(oResponse.statusCode === "0")
						) {
							var oModelAllData = JSON.parse(o.getParameters("responseText").response.responseText).d.results;
						
							var groupedByBuerCode = oCtrl.groupPrItemsToValues(oModelAllData)  ;
							if (oParams.isFirst){
							
								oCtrl.getPrDetailsSetLevel(oModelAllData[0].LevelTotal, false);
							}
	 

							oModelAllData.groupedByBuerCode = groupedByBuerCode.arr ;
							//oModelAllData.groupedByStatusTime = groupedByStatusTime ; 
							oModel.setData( oModelAllData);
							if (oParams.isController) {
								oCtrl.oView.getController().getOwnerComponent().getPrDetailsSetLevelCallback(oParams);
							}else{
								oCtrl.oView.getPrDetailsSetLevelCallback(oParams);
							}
							
						} else {
							var sError = (oResponse.statusCode).toString() + " --> " + oResponse.message;
							console.log(sError);
							var ERROR_ORG_TEVEN_DATA_INVALID = "שגיאה בניסון לשלוף נתוני מקור";
						
							console.log (ERROR_ORG_TEVEN_DATA_INVALID);
						//	oCtrl.openDialog("E", ERROR_ORG_TEVEN_DATA_INVALID );  // MessagePool.ERROR_ORG_TEVEN_DATA_INVALID
						}
					}
				);

				oModelManagerSetData.attachRequestFailed(
					function(o, ofilter) {
						console.log("getPrDetailsSetLevel");
					}
				);

				var aFilters = [];

				var oFilter1 = new Filter("Level", FilterOperator.EQ, level );
				aFilters.push(oFilter1);
				
				oModelManagerSetData.read(
					"/ManagerSet" , {
						filters: aFilters
					}
				);
			}	
		
		},

		// -----------------------------------------------------------------------------------------------------------------		
		getPrDetailsSet: function (selectedDate) {

			var oModel, oCtrl;
			oModel = new JSONModel();
			if (!this.isComponent ){
				oCtrl = this.oView.getController();
			}else{
				oCtrl = this ; 
			}
			
			if (this.bMock) {

				this.sUrl = "./localService/mockdata/CopyOflinesSet.json";

				oModel.loadData(
					this.sUrl,
					null,
					true,
					"GET",
					false,
					true
				);
				
				oModel.attachRequestCompleted(function() {
					oCtrl.getPrDetailsSetCallback(oModel);
				});
				
			} else {

				var oModelPrDetailsSetData = new sap.ui.model.odata.v2.ODataModel(this.sUrl);
				oModelPrDetailsSetData.setDefaultCountMode(sap.ui.model.odata.CountMode.None);

				oModelPrDetailsSetData.attachRequestCompleted({
						oView: this.oView,
						oModel: oModel
					},

					function(o, oParams) {
						
						var oResponse = o.getParameter("response");
						if (
							(oResponse.statusCode === "200") ||
							(oResponse.statusCode === "202") ||
							(oResponse.statusCode === "0")
						) {
							var oModelAllData = JSON.parse(o.getParameters("responseText").response.responseText).d.results;
							
						 
							oModel.setData( oModelAllData);
							oCtrl.oView.getPrDetailsSetCallback(oParams);
						} else {
							var sError = (oResponse.statusCode).toString() + " --> " + oResponse.message;
							console.log(sError);
							var ERROR_ORG_TEVEN_DATA_INVALID = "שגיאה בניסון לשלוף נתוני מקור";
						
							console.log (ERROR_ORG_TEVEN_DATA_INVALID);
						//	oCtrl.openDialog("E", ERROR_ORG_TEVEN_DATA_INVALID );  // MessagePool.ERROR_ORG_TEVEN_DATA_INVALID
						}
					}
				);

				oModelPrDetailsSetData.attachRequestFailed(
					function(o, ofilter) {
						console.log("getPrDetailsSet");
					}
				);

				var aFilters = [];

			//	var oFilter1 = new Filter("AppName", FilterOperator.EQ, 'MANAGER' );
				var oFilter1 = new Filter("Level", FilterOperator.EQ, '1' );
				aFilters.push(oFilter1);
				
				oModelPrDetailsSetData.read(
					"/ManagerSet" , {
						filters: aFilters
					}
				);				
				/*
				oModelPrDetailsSetData.read(
					"/PrDetailsSet" , {
						filters: aFilters
					}
				);
				*/
			}	
		
		},


		mngLevelASet: function (selectedDate) {

			var oModel, oCtrl, oService ;
			oModel = new JSONModel();
			if (!this.isComponent ){
				oCtrl = this.oView.getController();
				oService = this ; 
			}else{
				oCtrl = this ; 
				oService = this ; 
			}
			
			if (this.bMock) {

				this.sUrl = "./localService/mockdata/CopyOflinesSet.json";

				oModel.loadData(
					this.sUrl,
					null,
					true,
					"GET",
					false,
					true
				);

				oModel.attachRequestCompleted(function() {
					oCtrl.mngLevelASetCallback(oModel);
				});
				
			} else {

				var oModelPrDetailsSetData = new sap.ui.model.odata.v2.ODataModel(this.sUrl);
				oModelPrDetailsSetData.setDefaultCountMode(sap.ui.model.odata.CountMode.None);

				oModelPrDetailsSetData.attachRequestCompleted({
						oView: this.oView,
						oModel: oModel
					},

					function(o, oParams) {
						
						var oResponse = o.getParameter("response");
						if (
							(oResponse.statusCode === "200") ||
							(oResponse.statusCode === "202") ||
							(oResponse.statusCode === "0")
						) {
							var oModelAllData = JSON.parse(o.getParameters("responseText").response.responseText).d.results;
							//var groupedByBuerCode = oCtrl.groupPrItemsToValues(oModelAllData)  ;
							var groupedByCompany = 	oService.groupPrItemsToCompany(oModelAllData)  ;
							
						
							var groupedByStatusTimetemp = oService.groupedByStatusTime(oModelAllData)  ;
							var groupedByStatusTime=[] ;

							groupedByStatusTime[0] = {Title:"0 - 7 days"} ;
							groupedByStatusTime[1] = {Title:"7- 14 days"} ;
							groupedByStatusTime[2] = {Title:"14 - 28 days"} ;
							groupedByStatusTime[3] = {Title:"above 28 days"} ;
							
							groupedByStatusTime[0].openPR = groupedByStatusTimetemp.stsN1 ? groupedByStatusTimetemp.stsN1 : 0 ;
							groupedByStatusTime[0].RFQ = groupedByStatusTimetemp.stsA1 ? groupedByStatusTimetemp.stsA1 : 0 ;
							groupedByStatusTime[0].PO = groupedByStatusTimetemp.stsB1  ? groupedByStatusTimetemp.stsB1 : 0 ;
							
							groupedByStatusTime[1].openPR = groupedByStatusTimetemp.stsN2 ? groupedByStatusTimetemp.stsN2 : 0 ;
							groupedByStatusTime[1].RFQ = groupedByStatusTimetemp.stsA2 ? groupedByStatusTimetemp.stsA2 : 0 ;
							groupedByStatusTime[1].PO = groupedByStatusTimetemp.stsB2  ? groupedByStatusTimetemp.stsB2 : 0 ;
							
							groupedByStatusTime[2].openPR = groupedByStatusTimetemp.stsN3 ? groupedByStatusTimetemp.stsN3 : 0 ;
							groupedByStatusTime[2].RFQ = groupedByStatusTimetemp.stsA3 ? groupedByStatusTimetemp.stsA3 : 0 ;
							groupedByStatusTime[2].PO = groupedByStatusTimetemp.stsB3  ? groupedByStatusTimetemp.stsB3 : 0 ;							
							
							groupedByStatusTime[3].openPR = groupedByStatusTimetemp.stsN4 ? groupedByStatusTimetemp.stsN4 : 0 ;
							groupedByStatusTime[3].RFQ = groupedByStatusTimetemp.stsA4 ? groupedByStatusTimetemp.stsA4 : 0 ;
							groupedByStatusTime[3].PO = groupedByStatusTimetemp.stsB4  ? groupedByStatusTimetemp.stsB4 : 0 ;							
							/*
							groupedByStatusTime[0] = {count:0 ,Title:"Open PR 0 - 7 days"} ;
							groupedByStatusTime[1] = {count:0, Title:"Open PR 7- 14 days"} ;
							groupedByStatusTime[2] = {count:0 ,Title:"Open PR 14 - 28 days"} ;
							groupedByStatusTime[3] = {count:0 ,Title:"above 28 days"} ;
													   
							groupedByStatusTime[4] = {count:0 , Title:"PO 0 - 7 days"};
							groupedByStatusTime[5] = {count:0, Title:"PO 7 - 14 days"};
							groupedByStatusTime[6] = {count:0, Title:"PO 14 - 28 days"};
							groupedByStatusTime[7] = {count:0, Title:"PO above 28 days"};
													   
							groupedByStatusTime[8] = {count:0, Title:"RFQ 0 - 7 days"};
							groupedByStatusTime[9] = {count:0, Title:"RFQ 7 - 14 days"};
							groupedByStatusTime[10] = {count:0, Title:"RFQ 14 - 28 days"};
							groupedByStatusTime[11] = {count:0, Title:"RFQ above 28 days"};
						 
							if (groupedByStatusTimetemp.stsN1){ 
								groupedByStatusTime[0].count = groupedByStatusTimetemp.stsN1 ;
							}
							if (groupedByStatusTimetemp.stsN2){
								groupedByStatusTime[1].count = groupedByStatusTimetemp.stsN2  ;    
							}
							if (groupedByStatusTimetemp.stsN3){
								groupedByStatusTime[2].count = groupedByStatusTimetemp.stsN3 ; 
							}
							if (groupedByStatusTimetemp.stsN4){
								groupedByStatusTime[3].count = groupedByStatusTimetemp.stsN4 ;
							}
							if (groupedByStatusTimetemp.stsB1){ 
									groupedByStatusTime[4].count = groupedByStatusTimetemp.stsB1 ;
							}
							if (groupedByStatusTimetemp.stsB2){
								groupedByStatusTime[5].count = groupedByStatusTimetemp.stsB2 ; 
							}
							if (groupedByStatusTimetemp.stsB3){ 
								groupedByStatusTime[6].count = groupedByStatusTimetemp.stsB3 ; 
							}
							if (groupedByStatusTimetemp.stsB4){ 
									groupedByStatusTime[7].count = groupedByStatusTimetemp.stsB4 ;
							}							
							if (groupedByStatusTimetemp.stsA1){  
								groupedByStatusTime[8].count = groupedByStatusTimetemp.stsA1 ;
							}
							if (groupedByStatusTimetemp.stsA2){
								groupedByStatusTime[9].count = groupedByStatusTimetemp.stsA2 ;  
							}
							if (groupedByStatusTimetemp.stsA3){
								groupedByStatusTime[10].count = groupedByStatusTimetemp.stsA3 ;
							}
							if (groupedByStatusTimetemp.stsA4){
								groupedByStatusTime[11].count = groupedByStatusTimetemp.stsA4 ; 
							}							
							*/

							//oModelAllData.groupedByBuerCode = groupedByBuerCode.arr ;
							oModelAllData.groupedByStatusTime = groupedByStatusTime ; 
							oModelAllData.groupedByCompany = groupedByCompany.arr ; 
							oModel.setData( oModelAllData);
							oCtrl.mngLevelASetCallback(oParams);
						} else {
							var sError = (oResponse.statusCode).toString() + " --> " + oResponse.message;
							console.log(sError);
							var ERROR_ORG_TEVEN_DATA_INVALID = "שגיאה בניסון לשלוף נתוני מקור";
						
							console.log (ERROR_ORG_TEVEN_DATA_INVALID);
						//	oCtrl.openDialog("E", ERROR_ORG_TEVEN_DATA_INVALID );  // MessagePool.ERROR_ORG_TEVEN_DATA_INVALID
						}
					}
				);

				oModelPrDetailsSetData.attachRequestFailed(
					function(o, ofilter) {
						console.log("ManagerSet level1");
					}
				);

				var aFilters = [];

				var oFilter1 = new Filter("Level", FilterOperator.EQ, '1' );
				aFilters.push(oFilter1);
				
				oModelPrDetailsSetData.read(
					"/ManagerSet" , {
						filters: aFilters
					}
				);
			}	
		
		},
	/*
		groupedByStatusTime: function (dataArr) {
		
			var groupedvalues = dataArr.reduce(function(res, obj) {
					if (obj.PrDur>=0 && obj.PrDur<7 ){
						if (!res["0-7 Days"]){
							res.arr.push(res["0-7 Days"] = 1);
						}else {
							res["0-7 Days"] += 1 ;
						}
					}
					if (obj.PrDur>=7 && obj.PrDur<14 ){
						if (!res["7-14 Days"]){
							res.arr.push(res["7-14 Days"] = 1);
						}else {
							res["7-14 Days"] += 1 ;
						}
					}	
					if (obj.PrDur>=14 && obj.PrDur<28 ){
						if (!res["14-28 Days"]){
							res.arr.push(res["14-28 Days"] = 1);
						}else {
							res["14-28 Days"] += 1 ;
						}
					}
					if (obj.PrDur>28 ){
						if (!res["Days>28"]){
							res.arr.push(res["Days>28"] = 1);
						}else {
							res["Days>28"] += 1 ;
						}
					}
					
				return res;
			}, {arr:[]}) ;			
		
			return groupedvalues ; 
		},
		*/
		
		groupedByStatusTime: function (dataArr) {
		 
			var groupedvalues = dataArr.reduce(function(res, obj) {
					if (obj.PrDur>=0 && obj.PrDur<7 && obj.ProcStatus=="N" ){
						if (!res["stsN1"]){
							res.arr.push(res["stsN1"] = 1);
						}else {
							res["stsN1"] += 1 ;
						}
					}
					if (obj.PrDur>=7 && obj.PrDur<14 && obj.ProcStatus=="N" ){
						if (!res["stsN2"]){
							res.arr.push(res["stsN2"] = 1);
						}else {
							res["stsN2"] += 1 ;
						}
					}	
					if (obj.PrDur>=14 && obj.PrDur<28 && obj.ProcStatus=="N" ){
						if (!res["stsN3"]){
							res.arr.push(res["stsN3"] = 1);
						}else {
							res["stsN3"] += 1 ;
						}
					}
					if (obj.PrDur>=28   && obj.ProcStatus=="N" ){
						if (!res["stsN4"]){
							res.arr.push(res["stsN4"] = 1);
						}else {
							res["stsN4"] += 1 ;
						}
					}
					
					//------------------------------------------------------
					
					if (obj.PrDur>=0 && obj.PrDur<7 && obj.ProcStatus=="A" ){
						if (!res["stsA1"]){
							res.arr.push(res["stsA1"] = 1);
						}else {
							res["stsA1"] += 1 ;
						}
					}
					if (obj.PrDur>=7 && obj.PrDur<14 && obj.ProcStatus=="A" ){
						if (!res["stsA2"]){
							res.arr.push(res["stsA2"] = 1);
						}else {
							res["stsA2"] += 1 ;
						}
					}	
					if (obj.PrDur>=14 && obj.PrDur<28 && obj.ProcStatus=="A" ){
						if (!res["stsA3"]){
							res.arr.push(res["stsA3"] = 1);
						}else {
							res["stsA3"] += 1 ;
						}
					}
					if (obj.PrDur>=28   && obj.ProcStatus=="A" ){
						if (!res["stsA4"]){
							res.arr.push(res["stsA4"] = 1);
						}else {
							res["stsA4"] += 1 ;
						}
					}						

					//------------------------------------------------------
					
					if (obj.PrDur>=0 && obj.PrDur<7 && obj.ProcStatus=="B" ){
						if (!res["stsB1"]){
							res.arr.push(res["stsB1"] = 1);
						}else {
							res["stsB1"] += 1 ;
						}
					}
					if (obj.PrDur>=7 && obj.PrDur<14 && obj.ProcStatus=="B" ){
						if (!res["stsB2"]){
							res.arr.push(res["stsB2"] = 1);
						}else {
							res["stsB2"] += 1 ;
						}
					}	
					if (obj.PrDur>=14 && obj.PrDur<28 && obj.ProcStatus=="B" ){
						if (!res["stsB3"]){
							res.arr.push(res["stsB3"] = 1);
						}else {
							res["stsB3"] += 1 ;
						}
					}
					if (obj.PrDur>=28   && obj.ProcStatus=="B" ){
						if (!res["stsB4"]){
							res.arr.push(res["stsB4"] = 1);
						}else {
							res["stsB4"] += 1 ;
						}
					}					
					
				return res;
			}, {arr:[]}) ;			
		
			return groupedvalues ; 
		},
		

		groupPrItemsToCompany: function (dataArr) {
			
			var groupedvalues = dataArr.reduce(function(res, obj) {
				var key = obj.CompanyDesc; 
			 
				if (!(key in res)){
					obj.countItems = 1 ; 
					obj.compNmae =  obj.CompanyDesc   ;
					res.arr.push(res[key] = obj);
				}else {
					res[key].countItems += 1;
				}
				return res;
			}, {arr:[]}) ;			
		
			return groupedvalues ; 
		},	
	 
		/*
		groupPrItemsToCompany: function (dataArr) {
			
			var groupedvalues = dataArr.reduce(function(res, obj) {
				var key = obj.CompanyDesc + '_' + obj.PrItem ; 
			 
				if (!(key in res)){
					obj.countItems = 1 ; 
					obj.compNmae =  obj.CompanyDesc + '_' + obj.PrItem  ;
					res.arr.push(res[key] = obj);
				}else {
					res[key].countItems += 1;
				}
				return res;
			}, {arr:[]}) ;			
		
			return groupedvalues ; 
		},	
		*/
		groupPrItemsToValues: function (dataArr) {
			
			var groupedvalues = dataArr.reduce(function(res, obj) {
				if (!(obj.BuyerName in res)){
					obj.countItems = 1 ; 
					obj.sumRevenue = Number(obj.PriceUSD) ; 
					res.arr.push(res[obj.BuyerName] = obj);
				}else {
					res[obj.BuyerName].countItems += 1;
					res[obj.BuyerName].sumRevenue += Number(obj.PriceUSD);
				}
				return res;
			}, {arr:[]}) ;			
		
			return groupedvalues ; 
		}
		
		/*
		groupPrItemsToValues: function (dataArr) {
			
			var groupedvalues = dataArr.reduce(function(res, obj) {
				if (!(obj.ProcStatus in res)){
					//if ()
					 
				}else {
					res[obj.BuyerName].countItems += 1;
					res[obj.BuyerName].sumRevenue += Number(obj.Price);
				}
				return res;
			}, {arr:[]}) ;			
		
			return groupedvalues ; 
		},	*/	
		

		/*
		groupPrItemsToValues: function (dataArr) {
			
			var groupedvalues = dataArr.reduce(function(res, obj) {
				if (!(obj.BuyerName in res)){
					obj.countItems = 1 ; 
					res.arr.push(res[obj.BuyerName] = obj);
				}else {
					res[obj.BuyerName].countItems += 1;
				}
				return res;
			}, {arr:[]}) ;			
		
			return groupedvalues ; 
		}	
		*/
		

	});
	
	

});