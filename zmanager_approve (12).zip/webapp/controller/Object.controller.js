sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"../model/formatter",
	"../model/MainService", 
	"sap/m/MessageToast"	
], function (BaseController, JSONModel, History, formatter, MainService,MessageToast ) {
	"use strict";

	return BaseController.extend("sap.ui.demo.worklist.controller.Object", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit : function () {
 
			let iOriginalBusyDelay,
				oViewModel = new JSONModel({
					busy : true,
					delay : 0
				});

			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();
			this.setModel(oViewModel, "objectView");
			this.getOwnerComponent().getModel().metadataLoaded().then(function () {
					oViewModel.setProperty("/delay", iOriginalBusyDelay);
				}
			);
		},
		
		getEmpDataSet : function (objid) {
			sap.ui.core.BusyIndicator.show();
			let selectedRecord = this.getSelectedEmployeesItems() ;    
			if (selectedRecord.getData()) {
				
			let selectedItem = selectedRecord.getData().filter(function selectedEmp(item) {
			  return item.Pernr == objid ; 
			}); 
			this.getView().byId("empPernr").setText(selectedItem[0].Vorna +  ' ' + selectedItem[0].Nachn )  ; 
			let oDate = this.byId('calendar1').getDateValue()  ; 

	    	let oFormatddMMyyyy = sap.ui.core.format.DateFormat.getInstance({pattern: "dd/MM/yyyy", calendarType: sap.ui.core.CalendarType.Gregorian});
	    	let selectedFormattedVal = oFormatddMMyyyy.format(oDate) ; 			
		
			oDate.setMonth(oDate.getMonth()) ; 
			let fMounthSelected = this.getFormattedMonthDate(oDate) ; 
	 
			let selectedmounthModel = new JSONModel({date:oDate, formatdDate:selectedFormattedVal }); 
		    this.getView().setModel ( selectedmounthModel, "selectedmounthModel");
			
			const sPernrVal = parseInt(this._sObjectId) + '' ; 
		     
			const oCtrl = this;
			const oService = new MainService(this.getView(),false);
			
			
			let getItms = oService.getEmpDataSet(fMounthSelected,sPernrVal); 
			
			getItms.then(function(oODataResult) {
				if ((oODataResult) && (oODataResult.oData)) {
					sap.ui.core.BusyIndicator.hide();
	
					if (oODataResult.oResponse.statusCode == "200" ||
					   (oODataResult.oResponse.statusCode === "201") ||
					   (oODataResult.oResponse.statusCode === "202") ||
					   (oODataResult.oResponse.statusCode == "0")
						
						) { 				

						//let selectedmounthModel =  this.getView().getModel ( "selectedmounthModel").getData().formatdDate ;
					 	let modelData = oODataResult.oData.results ; 
					  
					 	if (modelData.length > 0 ) {
							for (let i=0; i<modelData.length; i++) {
								let absTypeText = this.getAbsTypeVal(modelData[i].AttType) ; 
								modelData[i].AttTypeText = absTypeText ; 
	    						let diff =  this.calculateTimeDifference (modelData[i].LclockIn , modelData[i].LclockOut ) ; 
	    						modelData[i].diff = diff ;  

							}
 							let oModel = new JSONModel(modelData); 
 							this.setSelectedMonthItems(oModel)  ;
					 	}else {
					 			let oModel = new JSONModel({}); 
					 			this.setSelectedMonthItems(oModel)  ;
					 			MessageToast.show("חודש הנבחר עוד לא זמין במערכת");
					 	}
					} else {
						MessageToast.show(`Status Code ${oODataResult.oResponse.statusCode}`);
					}
					
				} else {
					MessageToast.show("No Data");
				}}.bind(oCtrl))
			.catch(function(oError) {
				sap.ui.core.BusyIndicator.hide();
				{
					MessageToast.show(oError.message);
				}
			}.bind(oCtrl)) ;  				
				
			sap.ui.core.BusyIndicator.hide();
			}			
		},
		
 		_onObjectMatched : function (oEvent) {
			let oArguments = oEvent.getParameter("arguments");
			
			this._sObjectId = oArguments.objectId;
			this.getEmpDataSet (oArguments.objectId ) ; 
			

		}, 
		onNavtoDetail : function (oEvent) {

			 let list =  this.getView().byId('list') ; 
			 let selectedItems = list.getSelectedContexts() ; 
		
			 if (selectedItems.length > 0 ) { 
			    const selectedItemsData = new Array() ; 
				for (let i=0; i<selectedItems.length; i++) {
					selectedItemsData.push (selectedItems[i].getObject()) ;
				} 	
				let selectedListhModel = new JSONModel(selectedItemsData); 
				this.setSelectedListItems(selectedListhModel)   ;   
				
				this.getRouter().navTo("detail", {
				   objectId: this._sObjectId
				});
			 }else {
			 	MessageToast.show ('יש לבחור שורות מהטבלה');
			 }
			  
		},
		handleChange : function (oEvent) {
			this.getEmpDataSet(this._sObjectId) ; 
		},

		_bindView : function (sObjectPath) {
			let oViewModel = this.getModel("objectView"),
				oDataModel = this.getModel();

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function () {
						oDataModel.metadataLoaded().then(function () {
							oViewModel.setProperty("/busy", true);
						});
					},
					dataReceived: function () {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},

	    getFormattedMonthDate: function (oDate) { 
	    	let fMounthSelected = oDate.getMonth()+1 +'';
			if (fMounthSelected.length < 2 ) {
				fMounthSelected = '0' + fMounthSelected ; 
			}			
			fMounthSelected = oDate.getFullYear()  + fMounthSelected ; 
			return fMounthSelected ; 
	    },
	    
		_onBindingChange : function () {
			let oView = this.getView(),
				oViewModel = this.getModel("objectView"),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("objectNotFound");
				return;
			}

			let oResourceBundle = this.getResourceBundle(),
				oObject = oView.getBindingContext().getObject(),
				sObjectId = oObject.ObjectID,
				sObjectName = oObject.Name;

			oViewModel.setProperty("/busy", false);

			oViewModel.setProperty("/shareSendEmailSubject",
			oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
			oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		},
		
		onSelectAll: function(evt) {
		  let oList = this.byId("list");
		  let aItems = oList.getItems();
				 
		 if (evt.getSource().getPressed()) {
		
			  for (let i = 0; i < aItems.length; i++) {
			    let oItem = aItems[i];
			    oItem.setSelected(true);
			    this.getView().byId('selectAll').setText('נקה הכול') ;
			  }
		 }else {
			  for (let i = 0; i < aItems.length; i++) {
			    let oItem = aItems[i];
			    oItem.setSelected(false);
			    this.getView().byId('selectAll').setText('בחר הכול') ;
			  }		 	
		 }
		  
		},
		onApprove:  function(evt) {

		  let list =  this.getView().byId('list') ; 
		  let selectedItems = list.getSelectedContexts() ; 
		  const selectedItemsData = new Array() ; 
		  if (selectedItems.length > 0 ) { 
		    
			for (let i=0; i<selectedItems.length; i++) {
				if (parseInt( selectedItems[i].getObject().Status )  == 1) { 
					selectedItemsData.push (selectedItems[i].getObject()) ;
				}
			} 	
			for (var i=0; i<selectedItemsData.length; i++) {
				let dataToUpdate =  selectedItemsData[i] ;   
				let oView = this.getView() ; 
				
				oView.byId('msgStrip').removeAllItems() ; 
				/*
				if (! this.checkDateInOut (dataToUpdate.LtimeIn,dataToUpdate.LtimeOut )){
					return false ; 
				}
				if (! this.checkDateInOut (dataToUpdate.LtimeIn2,dataToUpdate.LtimeOut2 )){
					return false ; 
				}
			    
				if (dataToUpdate.LtimeIn2.length > 0  ||  dataToUpdate.LtimeOut2.length > 0 ) {
					if (! (dataToUpdate.AttType2 )){
						MessageToast.show("חייב לבחור סוג דיווח") ; 
						return; 
					}
				}
				*/
				 
				let	sts = '02'  ; 
 
				
				let tmp = {
				    "Pdsnr" : parseInt( dataToUpdate.Pdsnr).toString(),
				    "Pernr" : dataToUpdate.Pernr,
				    "Ldate" : "",
				    "Lday" : "",
				    "LclockIn" : "",
				    "LclockOut" : "",
				    "LtimeIn" : dataToUpdate.LtimeIn.indexOf(":") >=0 ? dataToUpdate.LtimeIn.replace(':','')+'00' : dataToUpdate.LtimeIn,
				    "LtimeOut" : dataToUpdate.LtimeOut.indexOf(":") >=0 ? dataToUpdate.LtimeOut.replace(':','')+'00' : dataToUpdate.LtimeOut,
				    "AttType" : dataToUpdate.AttType,
				    "AttType2" : dataToUpdate.AttType2,
				    "Remark" : dataToUpdate.Remark,
				    "Remark2" : dataToUpdate.Remark2,
				    "Status" : sts,
				    "TekenCmpl" : "",
				    "LtimeIn2" : dataToUpdate.LtimeIn2.indexOf(":") >=0 ? dataToUpdate.LtimeIn2.replace(':','')+'00' : dataToUpdate.LtimeIn2,
				    "LtimeOut2" : dataToUpdate.LtimeOut2.indexOf(":") >=0 ? dataToUpdate.LtimeOut2.replace(':','')+'00' : dataToUpdate.LtimeOut2
				};
				
				
				if (dataToUpdate.LtimeIn.length > 0 && parseInt ( dataToUpdate.LtimeIn) > 0){
					tmp.OrigfIn ="E" ;
				}
				if (dataToUpdate.LtimeOut.length > 0 && parseInt ( dataToUpdate.LtimeOut) > 0){
					tmp.OrigfOut ="E" ;
				}			
	 			if (dataToUpdate.LtimeIn2.length > 0 && parseInt ( dataToUpdate.LtimeIn2) > 0){
					tmp.OrigfIn2 ="E" ;
				}
				if (dataToUpdate.LtimeOut2.length > 0 && parseInt ( dataToUpdate.LtimeOut2) > 0){
					tmp.OrigfOut2 ="E" ;
				}
	
				const oCtrl = this;
				const oService = new MainService(this.getView(),false);
				
				let updateDayManual = oService.saveEtTypesSet(tmp); 
				
			
				updateDayManual.then(function(oODataResult) {
				if ((oODataResult) && (oODataResult.oData)) {
					sap.ui.core.BusyIndicator.hide();
					if (oODataResult.oResponse.statusCode == "200" ||
					   (oODataResult.oResponse.statusCode === "201") ||
					   (oODataResult.oResponse.statusCode === "202") ||
					   (oODataResult.oResponse.statusCode == "0"))
					{ 				
						MessageToast.show('הנתונים עודכנו בהצלחה');

						let selectedMonthModelData = this.getView().getModel('selectedMonthModel').getData() ;
						for (var i=0; i<selectedMonthModelData.length; i++) {
							if (parseInt( selectedMonthModelData[i].Pdsnr )  == parseInt( oODataResult.oData.Pdsnr)) { 
								this.getView().getModel('selectedMonthModel').getData()[i].Status = '02' ;
								this.getView().getModel('selectedMonthModel').refresh() ; 
								break ; 
							}
						}
						let oList = this.byId("list");
					    let aItems = oList.getItems();
			
					    for (let i = 0; i < aItems.length; i++) {
					    	let oItem = aItems[i];
					    	oItem.setSelected(false);
					    	this.getView().byId('selectAll').setText('בחר הכול') ;
						}	

					} else {
						MessageToast.show('Status Code ${oODataResult.oResponse.statusCode}');
					}
				} else {
					MessageToast.show("No Data");
				}}.bind(oCtrl))
				.catch(function(oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show(oError.message);
				}.bind(oCtrl)) ; 					
				
			}
		  }
		}

	});

});