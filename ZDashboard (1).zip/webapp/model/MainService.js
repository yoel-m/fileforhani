jQuery.sap.declare("model.MainService");
sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/ui/model/odata/v2/ODataModel"
 
], function(Object, JSONModel, Filter, FilterOperator, MessageBox,ODataModel) {
	"use strict";

	return Object.extend("ipa.org.il.zdashboard.model.MainService", {

		metadata: {
			properties: {
				oView: {
					oView: {
						type: "sap.ui.view"
					},
					bMock: {
						type: "boolean",
						defaultValue: false
					},
					sUrl: {
						type: "string"
					}

				}
			}
		},
		// -----------------------------------------------------------------------------------------------------------------
		constructor: function(view, isComponent) {
			this.oView = view;
			this.bMock = false;
			this.isComponent = isComponent; 
			//this.sUrl = GeneralConstants.SERVICE_URL;
			if (!isComponent) {
				this.sUrl = view.getController().getOwnerComponent().getModel().sServiceUrl ; 
			}else{
				this.sUrl = view.getModel().sServiceUrl ; 
			}
			
			//	"http://sapgwdev.hani.org.il:8021/sap/opu/odata/sap/ZHR_ESS_MENG_REPORTING_SRV";

		},


// -----------------------------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------------

	getClientsData: function() {
		//Retrive list of Months
			var oModel, oCtrl;
			oModel = new JSONModel();
			if (!this.isComponent ){
				oCtrl = this.oView.getController();
			}else{
				oCtrl = this.oView;
			}
			
			if (this.bMock) {

				this.sUrl = "./localService/mockdata/CopyOflinesSet.json";

				oModel.loadData(
					this.sUrl,
					null,
					true,
					"GET",
					false,
					true
				);

				oModel.getClientsData(function() {
					oCtrl.getClientsDataCallBack(oModel);
				});
				
			} else {

				var getModelClientsData = new sap.ui.model.odata.v2.ODataModel(this.sUrl);
				getModelClientsData.setDefaultCountMode(sap.ui.model.odata.CountMode.None);

				getModelClientsData.attachRequestCompleted({
						oView: this.oView,
						oModel: oModel
					},

					function(o, oParams) {
						
						var oResponse = o.getParameter("response");
						if (
							(oResponse.statusCode === "200") ||
							(oResponse.statusCode === "202") ||
							(oResponse.statusCode === "0")
						) {
							var oModelAllData = JSON.parse(o.getParameters("responseText").response.responseText).d.results;
						
							/*
							const formattedData = oModelAllData.map(elm => ({ 
							  ...elm,  
							  Dmbtr: parseFloat(str, [radix])(elm.Dmbtr)  
							}))
							*/
							const formattedData = oModelAllData.map(elm => ({ 
							  ...elm, // collect all the properties of each user
							  Dmbtr: parseFloat(elm.Dmbtr) // specifically parse the rank
							}))
														 
							oModel.setData(formattedData);  
						 //	oModel.setData(oModelAllData);
							oCtrl.getClientsDataCallBack(oParams);
						} else {
							var sError = (oResponse.statusCode).toString() + " --> " + oResponse.message;
							console.log(sError);
						}
					}
				);

				getModelClientsData.attachRequestFailed(
					function(o) {
						console.log(o);
					}
				);
				getModelClientsData.read(
					"/EtOdataSet"
				);
			}	
		}
	 
	});	

});