window.addEventListener("load", async () => {
    const loaderWrapper = document.getElementById('loader-wrapper');
    if (loaderWrapper) {
        // Ensure the loader is visible for a while before fading out
        setTimeout(() => {
            loaderWrapper.style.opacity = '0'; // Fade out the loader
            setTimeout(() => {
                loaderWrapper.style.display = 'none'; // Remove from view
            }, 1000); // Fade-out duration (matches CSS transition time)
        }, 2000); // Adjust this duration for loader visibility
    }
    scaleIcons();
    scaleFooter(); // Ensure footer scales correctly
    window.addEventListener("resize", () => {
        scaleIcons();
        scaleFooter();
    });

    // Fetch docking data and process it
    const dockingData = await fetchDockingData();
    const dockingPlaces = processDockingData(dockingData);
    updateIcons(dockingPlaces);   // Update icons with docking places
    
    // Call initializeIconEvents only after oData (dockingPlaces) is available
    initializeIconEvents(dockingPlaces); 
});

function scaleFooter() {
    const backgroundWrapper = document.querySelector('.background-wrapper');
    const footer = document.querySelector('.footer-strip');
    const baselineWidth = 1000; // The baseline width for the background
    const scaleFactor = backgroundWrapper.clientWidth / baselineWidth;

    // Keep the footer fixed in size regardless of scaling
    const fixedScaleFactor = 1 / scaleFactor; // Inverse of the scaling factor
    footer.style.transform = `scale(${fixedScaleFactor}) translateX(-50%)`;
    footer.style.width = `${baselineWidth}px`; // Match the baseline width
    footer.style.height = `60px !important`; // Maintain fixed height
}

function scaleIcons() {
    const backgroundWrapper = document.querySelector('.background-wrapper');
    const icons = document.querySelectorAll('.icon');
    const menueBar = document.getElementById('menueBar'); // Handle menueBar separately
    const footerStrip = document.querySelector('.footer-strip'); // Handle footer-strip separately

    const icon45d = document.querySelectorAll('.icon45d');
    const icon90d = document.querySelectorAll('.icon90d');

    // Get the scale factor based on the width of the background-wrapper
    const scaleFactor = backgroundWrapper.clientWidth / 1000; // Max width as baseline

    const panelIcons = document.querySelectorAll('.panel-icon');
    panelIcons.forEach(icon => {
        icon.style.transform = `scale(${scaleFactor})`;
    });

    const fixedScaleFactor = 1; // Keep these elements fixed
    footerStrip.style.transform = `scale(${fixedScaleFactor})`; // No scaling for footer
    menueBar.style.transform = `scale(${fixedScaleFactor})`; 

    // Apply the scale factor to each regular icon
    icons.forEach(icon => {
        icon.style.transform = `scale(${scaleFactor})`; // Scale only
    });

    // Apply scaling with rotation to 45-degree icons
    icon45d.forEach(icon => {
        icon.style.transform = `scale(${scaleFactor}) rotate(135deg)`;
    });

    // Apply scaling with rotation to 90-degree icons
    icon90d.forEach(icon => {
        icon.style.transform = `scale(${scaleFactor}) rotate(270deg)`;
    });


}

function initializeIconEvents(oData) {
    let selectedIcon = null;

    const slotsWithDirection = {
        M: "R", B: "R", D: "R", I: "R", K: "R", P: "R", N: "R", F: "R", // Right
        A: "L", C: "L", H: "L", J: "L", O: "L" // Left
    };

    const colorMap = {
        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/bl_b1_l.png": "#265CBC",
        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/bl_b1_r.png": "#265CBC",
        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/re_b1_l.png": "#BC3658",
        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/re_b1_r.png": "#BC3658",
        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/gr_b1_l.png": "#267A4C",
        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/gr_b1_r.png": "#267A4C",

        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/bl_b2_l.png": "#265CBC",
        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/bl_b2_r.png": "#265CBC",
        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/re_b2_l.png": "#BC3658",
        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/re_b2_r.png": "#BC3658",
        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/gr_b2_l.png": "#267A4C",
        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/gr_b2_r.png": "#267A4C",

    };

    // Ensure the number of icons matches the length of oData
    const icons = document.querySelectorAll('.icon-container');

    if (icons.length < oData.length) {
        // Add dummy invisible icons
        const iconsContainer = document.querySelector('#icons-container'); // Replace with your container element
        for (let i = icons.length; i < oData.length; i++) {
            const dummyIcon = document.createElement('div');
            dummyIcon.classList.add('icon-container', 'dummy-icon');
            dummyIcon.style.display = 'none'; // Hide the dummy icon
            iconsContainer.appendChild(dummyIcon);
        }
    } else if (icons.length > oData.length) {
        // Remove excess icons
        icons.forEach((icon, index) => {
            if (index >= oData.length) {
                icon.remove();
            }
        });
    }

    // Now, we can safely loop over the icons and oData
    document.querySelectorAll('.icon-container').forEach((icon, index) => {
        const data = oData[index]; // Assuming oData is passed to this function
        if (!data) {
            console.warn(`No data found for icon at index ${index}`);
            return; // Skip this icon if no data exists
        }

        const computedStyle = window.getComputedStyle(icon);
        const originalBg = computedStyle.backgroundImage;

        if (!originalBg || originalBg === 'none') {
            console.warn('Background image is not set for icon:', icon);
            return;
        }

        // Extract the URL from backgroundImage
        const bgUrlMatch = originalBg.match(/url\("?(.*?)"?\)/);
        if (!bgUrlMatch) {
            console.error('Failed to extract URL from backgroundImage:', originalBg);
            return;
        }

        // Strip protocol, domain, and port to match the relative URLs in colorMap
        let bgUrl = bgUrlMatch[1];
        const baseUrl = window.location.origin; // e.g., http://<server>:<port>
        if (bgUrl.startsWith(baseUrl)) {
            bgUrl = bgUrl.replace(baseUrl, ""); // Convert to relative path
        }

      //  console.log('Normalized background URL:', bgUrl);

        // Lookup the corresponding text color
        const originalColor = colorMap[bgUrl] || 'black'; // Default to black if no match
       // console.log('Original color:', originalColor);

        // Generate hover background URL: **_b_** → **_f_**
        const hoverBg = bgUrl.replace(/_b_/, '_f_');
        //console.log('Hover background URL:', hoverBg);

        icon.dataset.originalBg = bgUrl;
        icon.dataset.hoverBg = hoverBg;
        icon.dataset.originalColor = originalColor;

        // Set initial text color
        icon.style.color = originalColor;

        // Add dot dynamically based on subEqunr
        /*
        const subEqunr = data.subEqunr;
        const slot = data.slot;
        const dotColor = subEqunr ? 'green' : 'red'; // Green if subEqunr is not empty
        const dotPosition = slotsWithDirection[slot] || "L"; // Default to 'L' if not found

        let dotClass = dotColor === 'green' ? `dot-green${dotPosition}` : `dot-red${dotPosition}`;
        const dotElement = document.createElement('div');
        dotElement.classList.add(dotClass);
        icon.appendChild(dotElement);
         */
        // Hover behavior
        icon.addEventListener('mouseover', () => {
            if (!icon.classList.contains('icon-selected')) {
                icon.style.backgroundImage = `url("${icon.dataset.hoverBg}")`;
                icon.style.color = "white"; // Keep text white on hover
                icon.classList.add('icon-hover');
            }
        });

        icon.addEventListener('mouseout', () => {
            if (!icon.classList.contains('icon-selected')) {
                icon.style.backgroundImage = `url("${icon.dataset.originalBg}")`;
                icon.style.color = icon.dataset.originalColor; // Restore original text color
                icon.classList.remove('icon-hover');
            }
        });

        // Double-click behavior
        icon.addEventListener('dblclick', () => {
            if (selectedIcon && selectedIcon !== icon) {
                selectedIcon.style.backgroundImage = `url("${selectedIcon.dataset.originalBg}")`;
                selectedIcon.style.color = selectedIcon.dataset.originalColor;
                selectedIcon.classList.remove('icon-selected');
            }

            selectedIcon = icon;
            selectedIcon.style.backgroundImage = `url("${icon.dataset.hoverBg}")`;
            selectedIcon.style.color = "white";
            selectedIcon.classList.add('icon-selected');
        });
    });
}
function scaleFooter() {
    const backgroundWrapper = document.querySelector('.background-wrapper');
    const footer = document.querySelector('.footer-strip');
    const baselineWidth = 1000; // The baseline width for the background
    const scaleFactor = backgroundWrapper.clientWidth / baselineWidth;

    // Keep the footer fixed in size regardless of scaling
    const fixedScaleFactor = 1 / scaleFactor; // Inverse of the scaling factor
    footer.style.transform = `scale(${fixedScaleFactor}) translateX(-50%)`;
    footer.style.width = `${baselineWidth}px`; // Match the baseline width
    footer.style.height = `60px !important;`; // Maintain fixed height
}


function scaleIcons() {
    const backgroundWrapper = document.querySelector('.background-wrapper');
    const icons = document.querySelectorAll('.icon');
    const menueBar = document.getElementById('menueBar'); // Handle menueBar separately
    const footerStrip = document.querySelector('.footer-strip'); // Handle footer-strip separately

    const icon45d = document.querySelectorAll('.icon45d');
    const icon90d = document.querySelectorAll('.icon90d');

    // Get the scale factor based on the width of the background-wrapper
    const scaleFactor = backgroundWrapper.clientWidth / 1000; // Max width as baseline

  


    const panelIcons = document.querySelectorAll('.panel-icon');
    panelIcons.forEach(icon => {
        icon.style.transform = `scale(${scaleFactor})`;
    });

    const fixedScaleFactor = 1; // Keep these elements fixed
    footerStrip.style.transform = `scale(${fixedScaleFactor})`; // No scaling for footer
    menueBar.style.transform = `scale(${fixedScaleFactor})`; 

    // Apply the scale factor to each regular icon
    icons.forEach(icon => {
        icon.style.transform = `scale(${scaleFactor})`; // Scale only
    });

    // Apply scaling with rotation to 45-degree icons
    icon45d.forEach(icon => {
        icon.style.transform = `scale(${scaleFactor}) rotate(135deg)`;
    });

    // Apply scaling with rotation to 90-degree icons
    icon90d.forEach(icon => {
        icon.style.transform = `scale(${scaleFactor}) rotate(270deg)`;
    });
}
function initializeIconEvents(oData) {
    let selectedIcon = null;

    const slotsWithDirection = {
        M: "R", B: "R", D: "R", I: "R", K: "R", P: "R", N: "R", F: "R", // Right
        A: "L", C: "L", H: "L", J: "L", O: "L" // Left
    };

    const colorMap = {
        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/bl_b1_l.png": "#265CBC",
        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/bl_b1_r.png": "#265CBC",
        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/re_b1_l.png": "#87A9C1",
        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/re_b1_r.png": "#87A9C1",
        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/gr_b1_l.png": "#267A4C",
        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/gr_b1_r.png": "#267A4C",
        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/ye_b1_l.png": "#E59D17",
        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/ye_b1_r.png": "#E59D17",


        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/bl_b2_l.png": "#265CBC",
        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/bl_b2_r.png": "#265CBC",
        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/re_b2_l.png": "#87A9C1",
        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/re_b2_r.png": "#87A9C1",
        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/gr_b2_l.png": "#267A4C",
        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/gr_b2_r.png": "#267A4C",
        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/ye_b2_l.png": "#E59D17",
        "/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/ye_b2_r.png": "#E59D17"   

    };

    const icons = document.querySelectorAll('.icon-container');
     if (icons.length < oData.length) {
        // Add dummy invisible icons
        const iconsContainer = document.querySelector('#icons-container'); // Replace with your container element
        
		for (let i = icons.length; i < oData.length; i++) {
            const dummyIcon = document.createElement('div');
            dummyIcon.classList.add('icon-container', 'dummy-icon');
            dummyIcon.style.display = 'none'; // Hide the dummy icon
            iconsContainer.appendChild(dummyIcon);
        }
    } 
	/*
	else if (icons.length > oData.length) {
        // Remove excess icons
        icons.forEach((icon, index) => {
            if (index >= oData.length) {
                icon.remove();
            }
        });
    }*/


    // Now, we can safely loop over the icons and oData
    document.querySelectorAll('.icon-container').forEach((icon, index) => {
    	 
        const data = oData[index];  
        /*
        if (!data) {
            console.warn(`No data found for icon at index ${index}`);
            return; // Skip this icon if no data exists
        }*/

        const computedStyle = window.getComputedStyle(icon);
        const originalBg = computedStyle.backgroundImage;

        if (!originalBg || originalBg === 'none') {
            console.warn('Background image is not set for icon:', icon);
            return;
        }

        // Extract the URL from backgroundImage
        const bgUrlMatch = originalBg.match(/url\("?(.*?)"?\)/);
        if (!bgUrlMatch) {
            console.error('Failed to extract URL from backgroundImage:', originalBg);
            return;
        }

        // Strip protocol, domain, and port to match the relative URLs in colorMap
        let bgUrl = bgUrlMatch[1];
        const baseUrl = window.location.origin; // e.g., http://<server>:<port>
        if (bgUrl.startsWith(baseUrl)) {
            bgUrl = bgUrl.replace(baseUrl, ""); // Convert to relative path
        }

      // console.log ('Normalized background URL:', bgUrl);

        // Lookup the corresponding text color
        const originalColor = colorMap[bgUrl] || 'black'; // Default to black if no match
       // console.log('Original color:', originalColor);

        // Generate hover background URL: **_b_** → **_f_**
        const hoverBg = bgUrl.replace(/_b_/, '_f_');
       // console.log('Hover background URL:', hoverBg);

        icon.dataset.originalBg = bgUrl;
        icon.dataset.hoverBg = hoverBg;
        icon.dataset.originalColor = originalColor;

        // Set initial text color
        icon.style.color = originalColor;

        // Add dot dynamically based on subEqunr
        /*
        const subEqunr = data.subEqunr;
        const slot = data.slot;
        const dotColor = subEqunr ? 'green' : 'red'; // Green if subEqunr is not empty
        const dotPosition = slotsWithDirection[slot] || "L"; // Default to 'L' if not found

        let dotClass = dotColor === 'green' ? `dot-green${dotPosition}` : `dot-red${dotPosition}`;
        const dotElement = document.createElement('div');
        dotElement.classList.add(dotClass);
        icon.appendChild(dotElement);*/

        // Hover behavior
        icon.addEventListener('mouseover', () => {
            if (!icon.classList.contains('icon-selected')) {
                icon.style.backgroundImage = `url("${icon.dataset.hoverBg}")`;
                icon.style.color = "white"; // Keep text white on hover
                icon.classList.add('icon-hover');
            }
        });

        icon.addEventListener('mouseout', () => {
            if (!icon.classList.contains('icon-selected')) {
                icon.style.backgroundImage = `url("${icon.dataset.originalBg}")`;
                icon.style.color = icon.dataset.originalColor; // Restore original text color
                icon.classList.remove('icon-hover');
            }
        });

        // Double-click behavior
        icon.addEventListener('dblclick', () => {
            if (selectedIcon && selectedIcon !== icon) {
                selectedIcon.style.backgroundImage = `url("${selectedIcon.dataset.originalBg}")`;
                selectedIcon.style.color = selectedIcon.dataset.originalColor;
                selectedIcon.classList.remove('icon-selected');
            }

            selectedIcon = icon;
            selectedIcon.style.backgroundImage = `url("${icon.dataset.hoverBg}")`;
            selectedIcon.style.color = "white";
            selectedIcon.classList.add('icon-selected');
        });
    });
}
document.addEventListener("DOMContentLoaded", () => {
    const footer = document.querySelector('.footer-strip');
    const menueBarIcon = document.getElementById("menueBar");
    const iconImg = menueBarIcon.querySelector("img");
    const sideBarContainer = document.getElementById("sideBarContainer");
    const drawer = document.getElementById('floatingDrawer');

    const hideIcon = (iconText) => {
        const iconInShavit = document.getElementById(`icon-${iconText}`);
        if (iconInShavit) {
            iconInShavit.style.display = 'none';
        }
    };

    const handleIconClick = (iconText, message) => {
        const popupTitle = document.getElementById('popup-title').textContent;
        showFancyMessage(`${message} ${popupTitle}`);
        hideIcon(popupTitle);
    };

    const addIconEventListeners = () => {
        const windIcon = document.querySelector('img[alt="Wind"]');
        const vectorIcon = document.querySelector('img[alt="Vector2"]');
        const islandIcon = document.querySelector('img[alt="Island"]');

        if (windIcon) {
            windIcon.addEventListener('click', () => handleIconClick('Wind', 'כלי שייט יצא להפלגה'));
        }

        if (vectorIcon) {
            vectorIcon.addEventListener('click', () => handleIconClick('Vector2', 'כלי שייט יצא לתיקון'));
        }

        if (islandIcon) {
            islandIcon.addEventListener('click', () => handleIconClick('Island', 'כלי שייט יצא ליבשה'));
        }
    };

    const loadDrawerContent = () => {
        fetch('ship.html')
            .then(response => response.text())
            .then(html => {
                drawer.innerHTML = html;
                addIconEventListeners();
            })
            .catch(err => {
                console.warn('Error loading ship.html:', err);
            });
    };

    loadDrawerContent();

    const enforceFixedSize = () => {
        footer.style.height = "60px";
        footer.style.width = "100%";
        menueBarIcon.style.width = "50px";
        menueBarIcon.style.height = "50px";
        iconImg.style.width = "50px";
        iconImg.style.height = "50px";
    };

    const loadSideBar = async () => {
        try {
            const dockingData = await fetchDockingData();

            const panel3Data = dockingData.filter(item => item.Tplnr.startsWith("M-2-Z") && item.Equnr !== "");
            const panel1Data = dockingData.filter(item => item.Tplnr.startsWith("M-3-Z") && item.Equnr !== "");
            const panel2Data = dockingData.filter(item => item.Tplnr.startsWith("M-2-Y") && item.Equnr !== "");

            fetch('sideBar.html')
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`Failed to load sidebar: ${response.statusText}`);
                    }
                    return response.text();
                })
                .then(html => {
                    sideBarContainer.innerHTML = html;
                    const sideBar = document.getElementById("sideBar");
                    const closeSideBar = document.getElementById("closeSideBar");
                    const menueBar = document.getElementById("menueBar");

                    menueBar.addEventListener("click", () => {
                        sideBar.style.right = "0";
                    });

                    closeSideBar.addEventListener("click", () => {
                        sideBar.style.right = "-321px";
                    });

                    const createIconHTML = (tplnr, eqart, typbz, equnr, Zzyehud) => {
                        const baseUrl = `${window.location.origin}/sap/bc/ui5_ui5/sap/zshavitDok/img/sh`;
                        let iconUrl = '';
                        let cellClass = '';
                            
                        if (Zzyehud === "1") {
                            if (eqart === "B001" || eqart === "B003" ) {
                                iconUrl = `${baseUrl}/gr_b1_l.png`;
                                cellClass = 'virtual-cell gr';
                            } else if (eqart === "B002") {
                                iconUrl = `${baseUrl}/gr_b2_l.png`;
                                cellClass = 'virtual-cell gr2';
                            }
                        } else if (Zzyehud === "2") {
                            if (eqart === "B001") {
                                iconUrl = `${baseUrl}/bl_b1_l.png`;
                                cellClass = 'virtual-cell bl';
                            } else if (eqart === "B002") {
                                iconUrl = `${baseUrl}/bl_b2_l.png`;
                                cellClass = 'virtual-cell bl2';
                            }
                        } else if (Zzyehud === "3") {
                            if (eqart === "B001") {
                                iconUrl = `${baseUrl}/ye_b1_l.png`;
                                cellClass = 'virtual-cell ye';
                            } else if (eqart === "B002") {
                                iconUrl = `${baseUrl}/ye_b2_l.png`;
                                cellClass = 'virtual-cell ye2';
                            }
                        } else if (Zzyehud === "4") {
                            if (eqart === "B001") {
                                iconUrl = `${baseUrl}/re_b1_l.png`;
                                cellClass = 'virtual-cell re';
                            } else if (eqart === "B002") {
                                iconUrl = `${baseUrl}/re_b2_l.png`;
                                cellClass = 'virtual-cell re2';
                            }
                        }

                           
                        /*
                        if (eqart === "B001") {
                            iconUrl = `${baseUrl}/bl_b_l.png`;
                            cellClass = 'virtual-cell bl';
                        } else if (eqart === "B002") {
                            iconUrl = `${baseUrl}/re_b_l.png`;
                            cellClass = 'virtual-cell re';
                        } else if (eqart === "B003") {
                            iconUrl = `${baseUrl}/gr_b_l.png`;
                            cellClass = 'virtual-cell gr';
                        }
                        */

                        return `<div class="${cellClass}" data-eqnr="${equnr}">
                            <span class="icon-text">${typbz}</span>
                        </div>`;
                    };

                    const panel1 = document.getElementById("panel1");
                    panel1.innerHTML = panel1Data.map(item => createIconHTML(item.Tplnr, item.Eqart, item.Typbz, item.Equnr, item.Zzyehud )).join("");

                    const panel2 = document.getElementById("panel2");
                    panel2.innerHTML = panel2Data.map(item => createIconHTML(item.Tplnr, item.Eqart, item.Typbz, item.Equnr , item.Zzyehud)).join("");

                    const panel3 = document.getElementById("panel3");
                    panel3.innerHTML = panel3Data.map(item => createIconHTML(item.Tplnr, item.Eqart, item.Typbz, item.Equnr, item.Zzyehud )).join("");

                    document.querySelectorAll('.icon-text').forEach(icon => {
                        icon.addEventListener('click', () => sideBarIconClick(icon));
                    });
                })
                .catch(err => console.error(`Error loading sidebar: ${err}`));

  

        } catch (error) {
            console.error("Error loading sidebar or fetching data:", error);
        }
    };

    enforceFixedSize();
    window.addEventListener("resize", enforceFixedSize);
    loadSideBar();
});

function sideBarIconClick(icon) {
    const eqnr = icon.closest('.virtual-cell').dataset.eqnr;
    const typbz = icon.textContent || icon.querySelector('.icon-text').textContent;

    if (!eqnr || !typbz) {
        console.error('Equnr or Typbz not found for this icon');
        return;
    }

    // Store eqnr and typbz in localStorage
    localStorage.setItem('iconId', eqnr);
    localStorage.setItem('iconText', typbz);

    // Fetch popupSide.html and insert it into the drawer
    fetch('popupSide.html')
        .then(response => response.text())
        .then(html => {
            const drawer = document.getElementById('floatingDrawerSide');
            drawer.innerHTML = html; // Load popupSide.html into the drawer

            // Update title dynamically
            /*
            const popupTitle = drawer.querySelector('.popup-title');
            const boatName = drawer.querySelector('#boat-name1');
            if (popupTitle && boatName) {
                popupTitle.textContent = `בחר אפשרות - ${typbz}`;
                boatName.textContent = typbz; // Add the boat name from typbz or use ZztxtEn
            }*/

            // Fetch boat data from OData service
            fetch(`/sap/opu/odata/sap/zpm_odata_anchorage_srv/GetBoatSet(Equnr='${eqnr}')?$format=json`)
                .then(response => response.json())
                .then(data => {
                    const boat = data.d;

                    // Populate the personal info section

                    document.getElementById('boat-name1').textContent = boat.ZztxtEn +  ' '  + boat.Typbz
                    document.getElementById('person-name1').textContent = boat.Name1 ;
                    document.getElementById('phone-number1').textContent = boat.Telf1 ;
                    
                    document.getElementById('email-address1').href = `mailto:${boat.ZztxtEn.replace(/ /g, '_')}@gmail.com`;
                    document.getElementById('email-address1').textContent = `${boat.ZztxtEn.replace(/ /g, '_')}@gmail.com`;

                    // Populate insurance info section
                    document.getElementById('Gwlen1').textContent = boat.GwlenChar  || "לא נמצא";
                    document.getElementById('kosher1').textContent = boat.ZzkosherChar  || "לא נמצא";

                    // Set the dates if available, otherwise default to empty
                    const returnTime = document.getElementById('return-time1');
                    const returnTimeForecast = document.getElementById('return-time-forecast1');
                    
                    if (boat.ZzhazaraChar) {
                        const formattedDate = boat.ZzhazaraChar.split('.').reverse().join('-');
                        returnTimeForecast.value = formattedDate;
                    } else {
                        returnTimeForecast.value = "";
                    }

                    // Set default date to today's date for departure
                    returnTime.value = new Date().toISOString().split('T')[0];

                })
                .catch(err => console.error('Error fetching boat data:', err));

            // Add event listener for dropdown_doker (DO NOT trigger popup close here)
            const dropdownDoker = document.getElementById('dropdown_doker');
            if (dropdownDoker) {
                dropdownDoker.addEventListener('change', (event) => {
                    event.stopPropagation(); // Prevent click propagation
                    const selectedValue = dropdownDoker.value;
                    chooseLocation(selectedValue);
                });
            }

            // Add close button functionality
            const closeButton = document.getElementById('closePopupButton');
            closeButton.addEventListener('click', closePopupSide);

            // Open the custom drawer
            openPopupSideDrawer(icon);
        })
        .catch(err => console.error('Error loading popupSide.html:', err));
}
 
async function chooseLocation(dok) {
    try {
        // Fetch docking data
        const dockingData = await fetchDockingData();

        // Filter by Tplnr format "*-*-<dok>-***" and ensure Equnr exists
        const filteredData = dockingData.filter(item => {
            const tplnrRegex = new RegExp(`^.*-.*-${dok}-.*$`);
            return tplnrRegex.test(item.Tplnr) && !item.Equnr;
        });

        // Check if the filtered list is empty
        if (filteredData.length === 0) {
            alert("אין מקומות פנויים");
            return;
        }

        // Populate dropdown_location with filtered data
        const dropdownLocation = document.getElementById('dropdown_location');
        if (dropdownLocation) {
            dropdownLocation.innerHTML = ''; // Clear previous options

            filteredData.forEach(item => {
                const optionElement = document.createElement('option');
                optionElement.value = item.Tplnr; // Use full Tplnr as value
                optionElement.textContent = item.Tplnr.slice(-3); // Last 3 characters as display text
                dropdownLocation.appendChild(optionElement);
            });
        }
    } catch (error) {
        console.error('Error in chooseLocation:', error);
    }
}


function closePopupSide(event) {
    event.stopPropagation();  // Prevent the event from bubbling up and closing the popup
    const drawer = document.getElementById('floatingDrawerSide');
    drawer.classList.remove('open');
    drawer.style.display = 'none';
    drawer.innerHTML = ''; // Reset content
    window.location.reload(true);
    enterFullscreen();
}

function openPopupSideDrawer(icon) {
    const drawer = document.getElementById('floatingDrawerSide');
    const iconRect = icon.getBoundingClientRect();
    const windowWidth = window.innerWidth;
    const windowHeight = window.innerHeight;

     
    const drawerWidth = drawer.offsetWidth;
    const drawerHeight = drawer.offsetHeight;
 
    let drawerLeft = iconRect.right -500;
    let drawerTop = iconRect.top;
 
    if (drawerLeft + drawerWidth > windowWidth) {
        drawerLeft = windowWidth - drawerWidth - 10;  
    }

    if (drawerTop + drawerHeight > windowHeight) {
        drawerTop = windowHeight - drawerHeight - 10;  
    }

     
    drawer.style.top = `${drawerTop}px`;
    drawer.style.left = `${drawerLeft}px`;
 
    drawer.classList.add('open');
    drawer.style.display = 'block';
}
/*
function openCustomDrawer(icon) {
    const drawer = document.getElementById('floatingDrawer');
    const iconRect = icon.getBoundingClientRect();
    const windowWidth = window.innerWidth;
    const windowHeight = window.innerHeight;

    // Get the width and height of the drawer
    const drawerWidth = drawer.offsetWidth;
    const drawerHeight = drawer.offsetHeight;

    // Calculate the position of the drawer
    let drawerLeft = iconRect.right - 500;
    let drawerTop = iconRect.top;

    // Adjust the position if the drawer would be off-screen
    if (drawerLeft + drawerWidth > windowWidth) {
        drawerLeft = windowWidth - drawerWidth - 10; // Move it to the left side
    }

    if (drawerTop + drawerHeight > windowHeight) {
        drawerTop = windowHeight - drawerHeight - 10; // Move it upwards
    }

    // Apply the calculated position
    drawer.style.top = `${drawerTop}px`;
    drawer.style.left = `${drawerLeft}px`;

    // Show the drawer
    drawer.classList.add('open');
    drawer.style.display = 'block';
}*/
/*
function closeDrawer() {
    const drawer = document.getElementById('floatingDrawer');
    drawer.classList.remove('open');
    drawer.style.display = 'none';
    drawer.innerHTML = '';  // Reset drawer content
}*/

/*
function openDrawerByEqnr(eqnr) {
    // Find the parent container of the icon with the matching equnr
    const iconContainer = document.querySelector(`[data-eqnr="${eqnr}"]`);

    if (!iconContainer) {
        console.error('Icon container not found for Equnr:', eqnr);
        return;
    }

    // Call the original openDrawer function, passing the iconContainer
    openDrawer(iconContainer);
}*/

/*
 
function sideBarIconClick (icon) {
    const iconDetails = {
        iconSrc: icon.src,
        altText: icon.alt,
        eqnr: icon.closest('.virtual-cell').dataset.eqnr
    };

    const detailsString = `
        Icon Source: ${iconDetails.iconSrc}
        Alt Text: ${iconDetails.altText}
        Equnr: ${iconDetails.eqnr}
    `;

    alert(detailsString);
}		 	*/					 


// Function to generate the icon HTML
/*
function createIconHTML(place) {
    const baseUrl = `${window.location.origin}/sap/bc/ui5_ui5/sap/zshavitDok/img/sh`;
    let icon;

    if (place.Eqart === "B001") {
        icon = `${baseUrl}/bl_b_l.png`;
    } else if (place.Eqart === "B002") {
        icon = `${baseUrl}/re_b_l.png`;
    } else if (place.Eqart === "B003") {
        icon = `${baseUrl}/gr_b_l.png`;
    }

    return `
        <div class="virtual-cell ${place.Eqart.toLowerCase()}">
            <img src="${icon}" alt="${place.Tplnr} Icon" class="icon">
            <span class="icon-text">${place.Typbz}</span>
        </div>
    `;
}*/
function resetIcons() {
    // Reset all icons to their default state
    const icons = document.querySelectorAll('.statusIcons');
    icons.forEach(icon => {
        icon.classList.remove('selected', 'clicked');
        const iconType = icon.alt.toLowerCase(); // Get the icon type from alt attribute
        icon.src = `../../img/icons/${iconType}.png`; // Reset to normal icon
    });
}

 
async function windClick(element) {
    /*
    const iconId = localStorage.getItem('iconId');
    if (iconId) {
        hideIconInShavit(iconId);
    }

    resetIcons(); // Reset all other icons
    element.classList.add('selected'); // Mark this icon as selected
    element.src = "../../img/icons/windS.png"; // Change to "S" version
    */
														 
    const Equnr = localStorage.getItem('Equnr');
    // const Tplnr = localStorage.getItem('Tplnr');
   
                
      
     const dockingData = await fetchDockingData();
     const orgReq = dockingData.find(record => 
         record.Equnr == Equnr );
         
     const  Tplnr = orgReq.Tplnr;
     
     if (!Equnr || !Tplnr) {
         console.error('Equnr or Tplnr not found in localStorage');
         return;
     }
 
     // Step 1.1: Extract the slot from Tplnr (e.g., "M-1-N-009" -> "N")
     const slot = Tplnr.split('-')[2];
 
 
 
     // Step 3: Filter to get the first record where Equnr is empty and Tplnr starts with "M-1-<SLOT>"
     const filteredDocking = dockingData.find(record => 
        !record.Equnr && record.Tplnr.startsWith(`M-3-`)
     );
 
     if (!filteredDocking) {
          showFancyMessage('לא הוקצו מספיק מקומות לעדכון כלי שיט להפלגה - פנה למנהל המערכת');
         return;
     }
 
     const dateInInput = document.getElementById('return-time');
     const dateForecastInput = document.getElementById('return-time-forecast');
 
     
     let DateIn = dateInInput.value ? dateInInput.value.replace(/-/g, '') : new Date().toISOString().split('T')[0].replace(/-/g, ''); // YYYYMMDD
     
     let DateForecast = dateForecastInput.value ? dateForecastInput.value.replace(/-/g, '') : '20991230'; // Default to 20991230
 
     // Step 4: Build the JSON payload
     const payload = {
         Equnr: Equnr,
         Tplnr: filteredDocking.Tplnr
     };
 
     // Step 5: Execute the SetLocationSet POST OData with the constructed JSON payload
     const locationSuccess = await setLocation(Equnr, filteredDocking.Tplnr, DateForecast, DateIn );
    // console.log(locationSuccess); 
 
     // Step 6: Run the original islandClick logic ONLY if setLocation was successful
     if (locationSuccess) {
         const iconId = localStorage.getItem('iconId');
         if (iconId) {
            hideIconInShavit(iconId);
         }
 
         resetIcons(); // Reset all other icons
         element.classList.add('selected'); // Mark this icon as selected
         element.src = "../../img/icons/wind.png"; // Change to "S" version
     } else {
         console.error('Failed to set location, islandClick logic will not run');
     }
}

function anchorClick(element) {
    resetIcons(); // Reset all other icons
    element.classList.add('selected'); // Mark this icon as selected
    element.src = "../../img/icons/AnchorS.png"; // Change to "S" version
}

async function vectorClick(element) {
   // Step 1: Retrieve Equnr and Tplnr from localStorage
   const Equnr = localStorage.getItem('Equnr');
   // const Tplnr = localStorage.getItem('Tplnr');
    
    
    const dockingData = await fetchDockingData();
	const orgReq = dockingData.find(record => 
        record.Equnr == Equnr );
		
	const  Tplnr = orgReq.Tplnr;
	
    if (!Equnr || !Tplnr) {
        console.error('Equnr or Tplnr not found in localStorage');
        return;
    }

    // Step 1.1: Extract the slot from Tplnr (e.g., "M-1-N-009" -> "N")
    const slot = Tplnr.split('-')[2];



    // Step 3: Filter to get the first record where Equnr is empty and Tplnr starts with "M-1-<SLOT>"
    const filteredDocking = dockingData.find(record => 
       !record.Equnr && record.Tplnr.startsWith(`M-2-Y`)
    );

    if (!filteredDocking) {
         showFancyMessage('לא נותרו מקומות פנויים בסדנא');
        return;
    }
    const dateInInput = document.getElementById('return-time');
    const dateForecastInput = document.getElementById('return-time-forecast');

    
    let DateIn = dateInInput.value ? dateInInput.value.replace(/-/g, '') : new Date().toISOString().split('T')[0].replace(/-/g, ''); // YYYYMMDD
    
    let DateForecast = dateForecastInput.value ? dateForecastInput.value.replace(/-/g, '') : '20991230'; // Default to 20991230

    // Step 4: Build the JSON payload
    const payload = {
        Equnr: Equnr,
        Tplnr: filteredDocking.Tplnr
    };

    // Step 5: Execute the SetLocationSet POST OData with the constructed JSON payload
    const locationSuccess = await setLocation(Equnr, filteredDocking.Tplnr, DateForecast, DateIn );
    console.log(locationSuccess); 

    // Step 6: Run the original islandClick logic ONLY if setLocation was successful
    if (locationSuccess) {
        const iconId = localStorage.getItem('iconId');
        if (iconId) {
           hideIconInShavit(iconId);
        }

        resetIcons(); // Reset all other icons
        element.classList.add('selected'); // Mark this icon as selected
        element.src = "../../img/icons/Vector.png"; // Change to "S" version
    } else {
        console.error('Failed to set location, islandClick logic will not run');
    }
}

// Function to send the SetLocationSet POST request and return success status
/*
async function setLocation(payload) {
    try {
        // Step 1: Get CSRF Token
        const csrfToken = await getCsrfToken();
        if (!csrfToken) {
            console.error('CSRF token is missing');
            return false;
        }

        // Step 2: Send POST request to SetLocationSet
        const response = await fetch('/sap/opu/odata/sap/ZPM_ODATA_ANCHORAGE_SRV/SetLocationSet', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                 'Authorization': 'Basic eW9lbC1tOlpYQ2FzZDEyIw==', 
                'X-CSRF-Token': csrfToken, // Include CSRF token here
            },
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            throw new Error('Failed to execute SetLocationSet');
        }

        const result = await response.json();
        console.log('Location set successfully:', result);

        // Return true if successful
        return true;
    } catch (error) {
        console.error('Error setting location:', error);
        return false; // Return false if failed
    }
}
async function getCsrfToken() {
    return new Promise((resolve, reject) => {
        $.ajax({
            url: '/sap/opu/odata/sap/ZPM_ODATA_ANCHORAGE_SRV/SetLocationSet',
            method: 'POST',
            headers: {
                'X-CSRF-Token': 'Fetch',
                 'Authorization': 'Basic eW9lbC1tOlpYQ2FzZDEyIw==', 
                'Content-Type': 'application/json',
            },
            success: function (data, textStatus, xhr) {
                const csrfToken = xhr.getResponseHeader('x-csrf-token');
                if (csrfToken && csrfToken !== 'Required') {
                    resolve(csrfToken);
                } else {
                    reject('CSRF token not found');
                }
            },
            error: function (xhr, textStatus, errorThrown) {
                reject('Error fetching CSRF token: ' + errorThrown);
            },
        });
    });
}
*/


async function setLocation(Equnr, Tplnr, DateForecast , DateIn ) {

    // Build the OData service URL with the new parameters (DateIn and DateForecast)
    const url = `/sap/opu/odata/sap/ZPM_ODATA_ANCHORAGE_SRV/SetLocationSet(Equnr='${Equnr}',Tplnr='${Tplnr}',DateForecast='${DateForecast}',DateIn='${DateIn}')?$format=json`;

    try {
         
        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                
            }
        });        
        if (response.ok) {
            const responseData = await response.json();
           
            console.log('Success:', responseData);           
           
            return 'OK!';
        } else {
            
            const errorResponse = await response.text();  
            console.error('Error:', errorResponse);
            return `Error: ${response.status} - ${errorResponse}`;
        }
    } catch (error) {
        // Catch any network or other errors
        console.error('Error making the request:', error);
        return `Error: ${error.message}`;
    }
}

/*
async function setLocation(Equnr, Tplnr) {
    const url = `/sap/opu/odata/sap/ZPM_ODATA_ANCHORAGE_SRV/SetLocationSet(Equnr='${Equnr}',Tplnr='${Tplnr}')?$format=json`;
    
    try {
      
        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
              
            }
        });

    
        if (response.ok) {
            const responseData = await response.json();
   
            return 'OK!';
        } else {
           
            const errorResponse = await response.text(); 
            console.error('Error:', errorResponse);
            return `Error: ${response.status} - ${errorResponse}`;
        }
    } catch (error) {
        
        console.error('Error making the request:', error);
        return `Error: ${error.message}`;
    }
}
    */

async function islandClick(element) {
    // Step 1: Retrieve Equnr and Tplnr from localStorage
    const Equnr = localStorage.getItem('Equnr');
   // const Tplnr = localStorage.getItem('Tplnr');
    
    
    const dockingData = await fetchDockingData();
	const orgReq = dockingData.find(record => 
        record.Equnr == Equnr );
		
	const  Tplnr = orgReq.Tplnr;
	
    if (!Equnr || !Tplnr) {
        console.error('Equnr or Tplnr not found in localStorage');
        return;
    }

    // Step 1.1: Extract the slot from Tplnr (e.g., "M-1-N-009" -> "N")
    const slot = Tplnr.split('-')[2];



    // Step 3: Filter to get the first record where Equnr is empty and Tplnr starts with "M-1-<SLOT>"
    const filteredDocking = dockingData.find(record => 
       !record.Equnr && record.Tplnr.startsWith(`M-2-Z`)
    );

    if (!filteredDocking) {
         showFancyMessage('לא נותרו מקומות פנויים במעגנה יבשה');
        return;
    }

    const dateInInput = document.getElementById('return-time');
    const dateForecastInput = document.getElementById('return-time-forecast');

    
    let DateIn = dateInInput.value ? dateInInput.value.replace(/-/g, '') : new Date().toISOString().split('T')[0].replace(/-/g, ''); // YYYYMMDD
    
    let DateForecast = dateForecastInput.value ? dateForecastInput.value.replace(/-/g, '') : '20991230'; // Default to 20991230

    const payload = {
        Equnr: Equnr,
        Tplnr: filteredDocking.Tplnr

    };


    const locationSuccess = await setLocation(Equnr, filteredDocking.Tplnr, DateForecast, DateIn );

    if (locationSuccess) {
        const iconId = localStorage.getItem('iconId');
        if (iconId) {
           hideIconInShavit(iconId);
        }

        resetIcons(); // Reset all other icons
        element.classList.add('selected'); // Mark this icon as selected
        element.src = "../../img/icons/IslandS.png"; // Change to "S" version
    } else {
        console.error('Failed to set location, islandClick logic will not run');
    }
}

/*
async function setLocation(payload) {
    try {
        // Step 1: Get CSRF Token
        const csrfToken = await getCsrfToken();
        if (!csrfToken) {
            console.error('CSRF token is missing');
            return false;
        }

        // Step 2: Send POST request to SetLocationSet
        const response = await fetch('/sap/opu/odata/sap/ZPM_ODATA_ANCHORAGE_SRV/SetLocationSet', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                 'Authorization': 'Basic eW9lbC1tOlpYQ2FzZDEyIw==', 
                'X-CSRF-Token': csrfToken, // Include CSRF token here
            },
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            throw new Error('Failed to execute SetLocationSet');
        }

        const result = await response.json();
        console.log('Location set successfully:', result);

        // Return true if successful
        return true;
    } catch (error) {
        console.error('Error setting location:', error);
        return false; // Return false if failed
    }
}
*/
/*
async function getCsrfToken() {
    return new Promise((resolve, reject) => {
        $.ajax({
            url: '/sap/opu/odata/sap/ZPM_ODATA_ANCHORAGE_SRV/SetLocationSet',
            method: 'POST',
            headers: {
                'X-CSRF-Token': 'Fetch',
                 'Authorization': 'Basic eW9lbC1tOlpYQ2FzZDEyIw==', 
                'Content-Type': 'application/json',
            },
            success: function (data, textStatus, xhr) {
                const csrfToken = xhr.getResponseHeader('x-csrf-token');
                if (csrfToken && csrfToken !== 'Required') {
                    resolve(csrfToken);
                } else {
                    reject('CSRF token not found');
                }
            },
            error: function (xhr, textStatus, errorThrown) {
                reject('Error fetching CSRF token: ' + errorThrown);
            },
        });
    });
}*/

function hideIconInShavit(iconId) {
    const iconInShavit = document.getElementById(iconId);
    if (iconInShavit) {
        //iconInShavit.style.display = 'none';
         iconInShavit.src = '../../img/sh/icons/bk_v1-80.png'; 
    }
}

function initializePanelIconEvents() {
    const panelIcons = document.querySelectorAll('.panel-icon');

    panelIcons.forEach(icon => {
        // Add hover effects
        icon.addEventListener('mouseover', () => {
            icon.style.transform = 'scale(1.1)';
        });

        icon.addEventListener('mouseout', () => {
            icon.style.transform = 'scale(1)';
        });

        // Double-click functionality
        icon.addEventListener('dblclick', () => {
            showFancyMessage(`Selected Panel Icon: ${icon.dataset.name || 'Unknown'}`);
        });

        // Add text below the icon
        const textElement = document.createElement('div');
        textElement.classList.add('panel-icon-text');
        textElement.innerText = icon.dataset.name || 'Default Name'; // Use dataset for dynamic naming
        icon.appendChild(textElement);
    });
}
function populatePopupWithBoatData(boat) {
    const popupTitle = document.getElementById('popup-title');
    const popupSubtitle = document.getElementById('popup-subtitle');
    const phoneNumberElement = document.getElementById('phone-number');
    const emailElement = document.getElementById('email-address');
    const nameElement = document.getElementById('person-name');
    const subEqunrElement = document.getElementById('sub-equnr');
    const dateElement = document.getElementById('return-time');
    const statusElement = document.getElementById('boat-status');
    const statusCheckbox = document.getElementById('status-checkbox');
    const checkboxContainer = document.querySelector('.popup-box .fancy-checkbox'); 
    const returnTimeForecast = document.getElementById('return-time-forecast'); 
    const returnTimeInput = document.getElementById('return-time');

    const gwlen = document.getElementById('Gwlen');
    const kosher =document.getElementById('kosher');

 

    localStorage.setItem('Equnr', boat.Equnr);

    popupTitle.textContent = boat.ZztxtEn;
    popupSubtitle.textContent = boat.Typbz;
    phoneNumberElement.textContent = boat.Telf1;

    gwlen.textContent = boat.GwlenChar;
    kosher.textContent = boat.ZzkosherChar;

    if (boat.ZzhazaraChar) {
        // Convert the date from DD.MM.YYYY format to YYYY-MM-DD (for HTML5 date input)
        const formattedDate = boat.ZzhazaraChar.split('.').reverse().join('-'); 
        returnTimeForecast.value = formattedDate;
    }
    const today = new Date().toISOString().split('T')[0];
    returnTimeInput.value = today; 
    const email = `${boat.ZztxtEn.replace(/ /g, '_')}@gmail.com`;
    emailElement.href = `mailto:${email}`;
    emailElement.textContent = email;

    nameElement.textContent = boat.Name1;
    subEqunrElement.textContent = boat.SubEqunrSescr;
   // dateElement.value = boat.ZzkosherChar;
   // statusElement.textContent = boat.StatusAct === "X" ? "Active" : "Inactive";

    const popupBox = document.querySelector('.popup-box');
    if (!boat.SubEqunr || boat.SubEqunr.trim() === "") {
        if (popupBox) {
            popupBox.style.backgroundColor = '#FF5398';
        }
        if (statusCheckbox) {
            checkboxContainer.style.display = 'none'; 
        }  
        
    } else {
          popupBox.style.backgroundColor = '#D2FFE6';
          if (statusCheckbox) {
            checkboxContainer.style.display = 'inline-block';
            statusCheckbox.checked = boat.StatusConnect == "X";
            statusCheckbox.addEventListener('change', () => pedistal(boat.Equnr, boat.StatusConnect));
        }
    }


}

async function pedistal(equnr, statusConnect) {
    const statusCheckbox = document.getElementById('status-checkbox');
    try {
        const action = statusConnect === "X" ? 2 : 1; // 2 for disconnect, 1 for connect
        const message = action === 1 ? "פדיסטל חובר בהצלחה" : "פדיסטל נותק בהצלחה";

        await addEquipment(equnr, action);
        showFancyMessage(message);
        if (statusCheckbox) {
            statusCheckbox.disabled = true;
        }
    } catch (error) {
        console.error('Error in pedistal:', error);
        if (statusCheckbox) {
            statusCheckbox.disabled = false;
        }
    }
}


async function addEquipment(equnr, action) {
    const serviceUrl = `/sap/opu/odata/sap/ZPM_ODATA_ANCHORAGE_SRV/SetEquipmentSet(Equnr='${equnr}',Action='${action}')?$format=json`;

    try {
        const response = await fetch(serviceUrl, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
            },
        });

        if (!response.ok) {
            throw new Error(`Failed to execute addEquipment: ${response.statusText}`);
        }

        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error in addEquipment:', error);
        throw error;
    }
}
function showFancyMessage(message) {
    const messageBox = document.createElement('div');
    messageBox.textContent = message;
    messageBox.style.position = 'fixed';
    messageBox.style.bottom = '50%';
    messageBox.style.right = '50%';
    messageBox.style.backgroundColor = '#105b99';
    messageBox.style.color = '#fff';
    messageBox.style.padding = '10px 20px';
    messageBox.style.borderRadius = '5px';
    messageBox.style.boxShadow = '0px 4px 6px rgba(0,0,0,0.1)';
    messageBox.style.zIndex = '1000';
    messageBox.style.fontSize = '16px';

    document.body.appendChild(messageBox);

    setTimeout(() => {
        document.body.removeChild(messageBox);
    }, 3000);
}


function openDrawer(icon) {
    const equnr = icon.dataset.equnr; // Get Equnr from the clicked icon's data attribute
									   

    if (!equnr) {
        console.error('Equnr not found for this icon');
        return;
    }

    // Store the icon id in local storage if needed
    localStorage.setItem('iconId', icon.id);

    // Fetch boat data using the provided Equnr
    fetch(`/sap/opu/odata/sap/zpm_odata_anchorage_srv/GetBoatSet(Equnr='${equnr}')?$format=json`)
        .then(response => response.json())
        .then(boatData => {
            if (boatData.d) {
                const boat = boatData.d;
                populatePopupWithBoatData(boat);
            } else {
                console.error('Boat data not found for the given Equnr');
            }
        })
        .catch(err => {
            console.error('Error fetching GetBoatSet:', err);
        });

    // Position the drawer near the icon (existing logic)
    const iconRect = icon.getBoundingClientRect();
    const drawer = document.getElementById('floatingDrawer');

    const windowWidth = window.innerWidth;
    const windowHeight = window.innerHeight;

    let drawerLeft = iconRect.right + 10;
    let drawerTop = iconRect.top;

    if (drawerLeft + drawer.offsetWidth > windowWidth) {
        drawerLeft = iconRect.left - drawer.offsetWidth - 10;
    }

    if (drawerTop + drawer.offsetHeight > windowHeight) {
        drawerTop = iconRect.top - drawer.offsetHeight - 10;
    }

    drawer.style.top = `${drawerTop}px`;
    drawer.style.left = `${drawerLeft}px`;

    drawer.classList.add('open');
    drawer.style.display = 'block';


    // Select Anchor by default
    const anchorIcon = document.getElementById('anchorIcon');
    anchorClick(anchorIcon);
}


/*
function openDrawer(icon, id) {
    const iconText = icon.innerText || icon.textContent;
    localStorage.setItem('iconId', id);

    const iconRect = icon.getBoundingClientRect();
    const drawer = document.getElementById('floatingDrawer');

    const windowWidth = window.innerWidth;
    const windowHeight = window.innerHeight;

    let drawerLeft = iconRect.right + 10;
    let drawerTop = iconRect.top;

    if (drawerLeft + drawer.offsetWidth > windowWidth) {
        drawerLeft = iconRect.left - drawer.offsetWidth - 10;
    }

    if (drawerTop + drawer.offsetHeight > windowHeight) {
        drawerTop = iconRect.top - drawer.offsetHeight - 10;
    }

    drawer.style.top = `${drawerTop}px`;
    drawer.style.left = `${drawerLeft}px`;

    drawer.classList.add('open');
    drawer.style.display = 'block';

    // Select Anchor by default
    const anchorIcon = document.getElementById('anchorIcon');
    anchorClick(anchorIcon);
}
*/
/*
function loadDrawerContent(iconId) {
	 localStorage.setItem('iconId', iconId);									   

    fetch('ship.html')
        .then(response => response.text())
        .then(html => {
            const drawer = document.getElementById('floatingDrawer');
            drawer.innerHTML = html;
        })
        .catch(err => console.warn('Error loading ship.html:', err));
}*/


function hideIconInShavit(iconId) {
    const iconInShavit = document.getElementById(iconId);
    if (iconInShavit) {
         iconInShavit.style.display = 'none';
         /*
         const baseUrl = `${window.location.origin}/sap/bc/ui5_ui5/sap/zshavitDok/img/sh`;
		 let iconUrl = `${baseUrl}/bk_v1-80.png`;
         iconInShavit.src =iconUrl; */
    }
}
/*
function loadDrawerContent(iconText) {
    const drawer = document.getElementById('floatingDrawer');

    // Use AJAX or Fetch to load the content from ship.html
    fetch('ship.html')
        .then(response => response.text())
        .then(html => {
            // Insert the content from ship.html into the floating drawer
            drawer.innerHTML = html;

            // Optionally, update the title dynamically based on the clicked icon's text
            const popupTitle = document.getElementById('popup-title');
            popupTitle.textContent = iconText; // Set the drawer title to the icon's text
        })
        .catch(err => {
            console.warn('Error loading ship.html:', err);
        });
}*/

// Function to close the floating drawer
function closeDrawer() {
    const drawer = document.getElementById('floatingDrawer');
    drawer.classList.remove('open');
    drawer.style.display = 'none'; 
    window.location.reload(true);
    enterFullscreen();
}

function enterFullscreen() {
    const element = document.documentElement; // Select the full page
    if (element.requestFullscreen) {
        element.requestFullscreen();
    } else if (element.webkitRequestFullscreen) { // Safari and old Chrome/Edge
        element.webkitRequestFullscreen();
    } else if (element.mozRequestFullScreen) { // Firefox
        element.mozRequestFullScreen();
    } else if (element.msRequestFullscreen) { // Internet Explorer/Edge
        element.msRequestFullscreen();
    }
}

/*
document.addEventListener('click', function(event) {
    const drawer = document.getElementById('floatingDrawer');
    const iconContainer = document.querySelector('.background-container');

    if (!drawer.contains(event.target) && !iconContainer.contains(event.target)) {
        closeDrawer();
    }
});*/

function openLegendPopup() {
    const legendContainer = document.getElementById("legendContainer");

    // Dynamically load legend.html
    fetch("legend.html")
        .then(response => response.text())
        .then(data => {
            legendContainer.innerHTML = data;

            // Ensure the popup is visible
            const popup = document.getElementById("legendPopup");
            popup.style.display = "block";
        });
}

function closeLegendPopup() {
    const legendContainer = document.getElementById("legendContainer");
    legendContainer.innerHTML = ""; // Remove popup content
}
async function fetchDockingData() {
    const serviceUrl = "/sap/opu/odata/sap/zpm_odata_anchorage_srv/GetDockingSet?$format=json";
	//const serviceUrl =	"/sap/opu/odata/sap/zre_main_odata_srv/AreaSet?$format=json"
    try {
        const response = await fetch(serviceUrl, {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        });

        // Log the raw response body
       // console.log(await response.text()); // Debug: See what the server is returning

        // Check for HTTP errors
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const contentType = response.headers.get("content-type");
        if (contentType && contentType.includes("application/json")) {
            // Re-fetch the response as JSON (since `response.text()` consumes it)
            const jsonResponse = await fetch(serviceUrl, {
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            });
            return (await jsonResponse.json()).d.results; // Assuming "d.results" contains the list
        } else {
            throw new Error("Response is not JSON");
        }
    } catch (error) {
        console.error("Error fetching OData service:", error);
        return [];
    }
}
async function sendAnchorClick(icon) {
    // Get the equnr from the icon's dataset
    const equnr = localStorage.getItem('iconId');  

  
    const dropdown = document.getElementById('dropdown_location');
    const selectedOption = dropdown.options[dropdown.selectedIndex];  
    const selectedValue = selectedOption ? selectedOption.value : null;  
    const selectedText = selectedOption ? selectedOption.textContent : null;  

    const dateInInput = document.getElementById('return-time');
    const dateForecastInput = document.getElementById('return-time-forecast');

    
    let DateIn =new Date().toISOString().split('T')[0].replace(/-/g, ''); // YYYYMMDD
    
    let DateForecast =   '20991230'; // Default to 20991230



    const locationSuccess = await setLocation(equnr, selectedValue ,DateForecast, DateIn );

    if (locationSuccess) {
        const iconElement = document.querySelector(`[data-eqnr="${equnr}"]`);
        if (iconElement) {
            iconElement.style.display = 'none';
            showFancyMessage(`כלי שיט התמקם במעגנה`);
        } else {
            console.warn(`Icon with equnr "${equnr}" not found.`);
        }
    } else {
        console.error('Failed to set location, islandClick logic will not run');
    }   

    // Alert the equnr, selected value, and key
    //alert(`Equnr: ${equnr}\nValue: ${selectedValue}\nKey: ${selectedText}`);
}


function processDockingData(dockingData) {
    return dockingData
        .filter(item => item.Tplnr.startsWith("M-1")) // Only "M-1" Tplnr values
        .map(item => {
            const [_, __, slot, place] = item.Tplnr.split("-"); // Extract slot and place
            return {
                slot,
                place: parseInt(place),
                equnr: item.Equnr,
                subEqunr: item.SubEqunr,
				Eqart: item.Eqart,
				SubTypbz: item.SubTypbz,
				Tplnr: item.Tplnr,
				Typbz: item.Typbz,		
                Zzyehud: item.Zzyehud	
            };
        });
}


async function updateIcons(dockingPlaces) {
    const slotRanges = {
        B: [1, 50],
        A: [51, 100],
        C: [101, 150],
        D: [151, 200],
        H: [201, 215],
        I: [216, 230],
        J: [231, 245],
        K: [246, 260],
        O: [261, 275],
        P: [276, 290],
        M: [291, 350],
        N: [351, 450],
        F: [451, 473],
    };

    const slotsWithDirection = {
        M: "R", B: "R", D: "R", I: "R", K: "R", P: "R", N: "R", F: "R", // Right
        A: "L", C: "L", H: "L", J: "L", O: "L" // Left
   
    };

    const placeholderIcon = `${window.location.origin}/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/bk_v1-80.png`;

    async function fetchBoatStatus(equnr) {
        try {
            const response = await fetch(
                `/sap/opu/odata/sap/zpm_odata_anchorage_srv/GetBoatSet(Equnr='${equnr}')?$format=json`
            );
            const data = await response.json();
            return data.d.StatusConnect; // Return the StatusConnect value
        } catch (error) {
            console.error(`Error fetching boat status for Equnr=${equnr}:`, error);
            return null;
        }
    }

    Object.entries(slotRanges).forEach(([slot, [start, end]]) => {
        for (let i = start; i <= end; i++) {
            const iconId = `icon${i}`;
            const iconElement = document.getElementById(iconId);

            if (!iconElement) continue; // Skip if the icon element doesn't exist

            const place = dockingPlaces.find(p => p.slot === slot && p.place === i - start);

            let icon = "";
            const text = place && place.equnr ? place.Typbz : "";
            const baseUrl = `${window.location.origin}/sap/bc/ui5_ui5/sap/zshavitDok/img/sh`;
            const direction = slotsWithDirection[slot] === "R" ? "_r" : "_l"; // Determine left or right side

            if (place && place.equnr) {
                if (place.Zzyehud === "1") {
                    if (place.Eqart === "B001" || place.Eqart === "B003" ) {
                        icon = `${baseUrl}/gr_b1${direction}.png`;
                    } else if (place.Eqart === "B002") {
                        icon = `${baseUrl}/gr_b2${direction}.png`;
                    }
                } else if (place.Zzyehud === "2") {
                    if (place.Eqart === "B001") {
                        icon = `${baseUrl}/bl_b1${direction}.png`;
                    } else if (place.Eqart === "B002") {
                        icon = `${baseUrl}/bl_b2${direction}.png`;
                    }
                } else if (place.Zzyehud === "3") {
                    if (place.Eqart === "B001") {
                        icon = `${baseUrl}/ye_b1${direction}.png`;
                    } else if (place.Eqart === "B002") {
                        icon = `${baseUrl}/ye_b2${direction}.png`;
                    }
                } else if (place.Zzyehud === "4") {
                    if (place.Eqart === "B001") {
                        icon = `${baseUrl}/re_b1${direction}.png`;
                    } else if (place.Eqart === "B002") {
                        icon = `${baseUrl}/re_b2${direction}.png`;
                    }
                }
            } else {
																	 
                icon = `${baseUrl}/block_${slotsWithDirection[slot].toLowerCase()}.png`; // Placeholder if no place found
            }

            iconElement.style.backgroundImage = `url("${icon}")`;
            iconElement.classList.remove("disappear");
            iconElement.textContent = text;

            let dotClass = `dot-gray${slotsWithDirection[slot]}`;
            if (place && place.equnr) {
                if (place.subEqunr) {
                    fetchBoatStatus(place.equnr).then(statusConnect => {
                        dotClass =
                            statusConnect === "X"
                                ? `dot-green${slotsWithDirection[slot]}`
                                : `dot-yellow${slotsWithDirection[slot]}`;

                        let dotElement = iconElement.querySelector(".dot");
                        if (!dotElement) {
                            dotElement = document.createElement("div");
                            dotElement.classList.add("dot");
                            iconElement.appendChild(dotElement);
                        }
                        dotElement.className = `dot ${dotClass}`;
                    });
                } else {
                    dotClass = `dot-red${slotsWithDirection[slot]}`;
                }
            }

            let dotElement = iconElement.querySelector(".dot");
            if (!dotElement) {
                dotElement = document.createElement("div");
                dotElement.classList.add("dot");
                iconElement.appendChild(dotElement);
            }
            dotElement.className = `dot ${dotClass}`;

            // Store the Equnr in the icon's data attribute for later use
            if (place && place.equnr) {
                iconElement.dataset.equnr = place.equnr; // Store Equnr in the data attribute
            }
        }
    });
}


/*
async function updateIcons(dockingPlaces) {
    const slotRanges = {
        B: [1, 50],
        A: [51, 100],
        C: [101, 150],
        D: [151, 200],
        H: [201, 215],
        I: [216, 230],
        J: [231, 245],
        K: [246, 260],
        O: [261, 275],
        P: [276, 290],
        M: [291, 350],
        N: [351, 450],
        F: [451, 473],
    };

    const slotsWithDirection = {
        M: "R", B: "R", D: "R", I: "R", K: "R", P: "R", N: "R", F: "R", // Right
        A: "L", C: "L", H: "L", J: "L", O: "L" // Left
			
    };

    const placeholderIcon = `${window.location.origin}/sap/bc/ui5_ui5/sap/zshavitDok/img/sh/bk_v1-80.png`;

    async function fetchBoatStatus(equnr) {
        try {
            const response = await fetch(
                `/sap/opu/odata/sap/zpm_odata_anchorage_srv/GetBoatSet(Equnr='${equnr}')?$format=json`
            );
            const data = await response.json();
            return data.d.StatusConnect; // Return the StatusConnect value
        } catch (error) {
            console.error(`Error fetching boat status for Equnr=${equnr}:`, error);
            return null;
        }
    }
      
    Object.entries(slotRanges).forEach(([slot, [start, end]]) => {
        for (let i = start; i <= end; i++) {
            const iconId = `icon${i}`;
            const iconElement = document.getElementById(iconId);

            if (!iconElement) continue; // Skip if the icon element doesn't exist

            const place = dockingPlaces.find(p => p.slot === slot && p.place === i - start);

            let icon = "";
            const text = place && place.equnr ? place.Typbz : "";
            const baseUrl = `${window.location.origin}/sap/bc/ui5_ui5/sap/zshavitDok/img/sh`;
            if (place && place.equnr) {              
                if (place.Eqart === "B001") {
                    icon = `${baseUrl}/bl_b_${slotsWithDirection[slot].toLowerCase()}.png`;
                } else if (place.Eqart === "B002") {
                    icon = `${baseUrl}/re_b_${slotsWithDirection[slot].toLowerCase()}.png`;
                } else if (place.Eqart === "B003") {
                    icon = `${baseUrl}/gr_b_${slotsWithDirection[slot].toLowerCase()}.png`;
                }
            } else {
                //icon = placeholderIcon; // Use the placeholder icon
                icon = `${baseUrl}/block_${slotsWithDirection[slot].toLowerCase()}.png`;
            }

            iconElement.style.backgroundImage = `url("${icon}")`;
            iconElement.classList.remove("disappear");
            iconElement.textContent = text;

            let dotClass = `dot-gray${slotsWithDirection[slot]}`;
            if (place && place.equnr) {
                if (place.subEqunr) {
                    fetchBoatStatus(place.equnr).then(statusConnect => {
                        dotClass =
                            statusConnect === "X"
                                ? `dot-green${slotsWithDirection[slot]}`
                                : `dot-yellow${slotsWithDirection[slot]}`;

                        let dotElement = iconElement.querySelector(".dot");
                        if (!dotElement) {
                            dotElement = document.createElement("div");
                            dotElement.classList.add("dot");
                            iconElement.appendChild(dotElement);
                        }
                        dotElement.className = `dot ${dotClass}`;
                    });
                } else {
                    dotClass = `dot-red${slotsWithDirection[slot]}`;
                }
            }

            let dotElement = iconElement.querySelector(".dot");
            if (!dotElement) {
                dotElement = document.createElement("div");
                dotElement.classList.add("dot");
                iconElement.appendChild(dotElement);
            }
            dotElement.className = `dot ${dotClass}`;

            // Store the Equnr in the icon's data attribute for later use
            if (place && place.equnr) {
                iconElement.dataset.equnr = place.equnr; // Store Equnr in the data attribute
            }
        }
    });
}

*/
document.addEventListener('DOMContentLoaded', initializePanelIconEvents);