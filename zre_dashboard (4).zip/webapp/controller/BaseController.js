sap.ui.define([
	"sap/ui/core/mvc/Controller",
	 "../model/MainService", 
	 "sap/ui/model/json/JSONModel",
	 'sap/m/MessageToast',
	"sap/ui/core/routing/History"
], function (Controller, MainService,JSONModel,MessageToast, History) {
	"use strict";

	return Controller.extend("sap.ui.demo.masterdetail.controller.BaseController", {

		getRouter : function () {
			return this.getOwnerComponent().getRouter();
		},

		getModel : function (sName) {
			return this.getView().getModel(sName);
		},


		setModel : function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},


		getResourceBundle : function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		onNavBack : function() {
			var sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("main", {}, true);
			}
		},
		 // Filter the array of JSON objects based on the specified property and value
		filterJsonArray: function (jsonArray, propertyName, propertyValue) {
		    return jsonArray.filter(item => item[propertyName] === propertyValue);
		},		
        operateReadEntity: function(entity,filters) {
            return new Promise((resolve, reject) => {
                const oCtrl = this;
                const oService = new MainService(this.getView(), false);
                let getItms = oService.getEntitySet(entity,filters);
        
                getItms.then(function (oODataResult) {
                        if ((oODataResult) && (oODataResult.oData)) {
                            sap.ui.core.BusyIndicator.hide();
        
                            if (
                                oODataResult.oResponse.statusCode == "200" ||
                                oODataResult.oResponse.statusCode === "201" ||
                                oODataResult.oResponse.statusCode === "202" ||
                                oODataResult.oResponse.statusCode == "0"
                            ) {
                                let oModel = new JSONModel(oODataResult.oData.results);
                                resolve(oModel); 
                            } else {
                                reject(`Status Code ${oODataResult.oResponse.statusCode}`); // Reject the promise with an error message
                            }
                        } else {
                            reject("No Data"); 
                        }
                    }.bind(oCtrl))
                    .catch(function (oError) {
                        sap.ui.core.BusyIndicator.hide();
                        MessageToast.show(oError.message);
                        reject(oError); // Reject the promise with the error object
                    }.bind(oCtrl));
            });
        },		

	});

});