sap.ui.define([
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("icl.group.com.dashboard.controller.NotFound", {

		/**
		 * Navigates to the dashboard when the link is pressed
		 * @public
		 */
		onLinkPressed : function () {
			this.getRouter().navTo("dashboard");
		}

	});

});