sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/odata/v2/ODataModel",
	], function (Object, JSONModel, ODataModel) {
	"use strict";
	return Object.extend("clalit.org.il.ODataTimeout.model.MyService", {

		// -----------------------------------------------------------------------------------------------------------------
		
		 // TODO: Add metadata (if any)
		 metadata : {
	         properties : {
	        	 //oView : {type : "sap.ui.view"},
	        	 //sUrl  : {type : "string"}
	         }
		 },

		// -----------------------------------------------------------------------------------------------------------------

		 // TODO: init properties (if any) 
		 constructor: function(view) {
			 //this.oView = view;
	         //this.bMock = false;
	         //this.bMock = true;
	         //this.sUrl = GeneralConstants.SERVICE_URL;
		 },

		 // -----------------------------------------------------------------------------------------------------------------
		 
		 setODataTimerOn: function (nTimeout) {
			 return new Promise((resolve, reject) => {
			     setTimeout(() => { reject({timeout: true}); }, nTimeout);
			 });
		},
		 
		// -----------------------------------------------------------------------------------------------------------------
		
		getUserDetails: function() {
            return new Promise(function(resolve, reject) {
               const sUrl = "/sap/opu/odata/sap/ZLO_STERILE_SUPPLY_SRV"; // TODO: Use constant
               const oModel = new ODataModel(sUrl);
               
               sap.ui.core.BusyIndicator.show(0);
               oModel.read("/UserDetailsSet", {
            	   success: (oData, oResponse)  => resolve({oData, oResponse}),
                   error:   (oError) => reject(oError)
               });
            });           
		}
		
		// -----------------------------------------------------------------------------------------------------------------
	 
	});
});