sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/odata/v2/ODataModel",
	"clalit/org/il/ODataTimeout/model/MyService",
	"sap/m/MessageToast",
], function(Controller, ODataModel, MyService, MessageToast) {
	"use strict";

	return Controller.extend("clalit.org.il.ODataTimeout.controller.Main", {
		onGetData: function() {
			const oCtrl = this;
			const oService = new MyService();
			
			// TODO: Use constant in external constants file
			const TIMEOUT = 30000; // 30 seconds
			
			Promise.race([oService.getUserDetails(), oService.setODataTimerOn(TIMEOUT)])
				.then(function(oODataResult) {
					if ((oODataResult) && (oODataResult.oData)) {
						sap.ui.core.BusyIndicator.hide();
						console.log("Success");
						
						// TODO: Check for oODataResult.oResponse.statusCode value before processing the data
						// == instead of === because sometimes it's string "200" and sometimes it's int 200
						if (oODataResult.oResponse.statusCode == "200") { 
							console.log(oODataResult.oData.results[0].UserName);	
						} else {
							MessageToast.show(`Status Code ${oODataResult.oResponse.statusCode}`);
						}
						
					} else {
						MessageToast.show("No Data");
					}}.bind(oCtrl))
				.catch(function(oError) {
					sap.ui.core.BusyIndicator.hide();
					if (oError.timeout) {
						// oError has a single property 'timeout' with the value true.
						// You can add more properties in the 'setODataTimerOn' function which is part of the 'MyService' object
						MessageToast.show("Error connecting to server, try again");
					} else {
						// oError is part of the OData response
						MessageToast.show(oError.message);
					}}.bind(oCtrl))		
		}
	});

});