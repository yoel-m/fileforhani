function addIdleTimeInterval() {
	                window.idleTime = 0;
	                window.isDialogOpen = false;
	                
	                if(jQuery.sap !== undefined){
	                                //Increment the idle time counter every minute.
	                                var idleInterval = setInterval(function(){
	                                                window.idleTime ++;
	                                                if (window.idleTime >= 1 && ! window.isDialogOpen) { // עברו 10 דקות ללא הוזזת עכבר או מקלדת וכן הדיאלוג שמתריע על כך לא מוצג כבר
	                                                    showDialog();
	                                                    //window.location.reload();
	                                                }
	                                }, 60000); // 1 minute
	                                
	                 //Zero the idle timer on mouse movement.
	                    $(this).mousemove(function (e) {
	                        window.idleTime = 0;
	                    });
	                    $(this).keypress(function (e) {
	                        window.idleTime = 0;
	                    });
	                    
	                    
	                }
	}

    function showDialog() {
        
        var title = sap.ui.demo.cart.constants.MessagePool.DIALOG_EXPIRED_TIME_TITLE;
        var message = sap.ui.demo.cart.constants.MessagePool.DIALOG_EXPIRED_TIME_MESSAGE;
        
		var oModelDialog = new sap.ui.model.json.JSONModel();
		oModelDialog.setData(
			{
				"dialogTitle" : title,          
				"dialogMessage" : message
			}
		);

		sap.ui.getCore().setModel(null, "oModelDialog");
		sap.ui.getCore().setModel(oModelDialog, "oModelDialog");

		var _oViewDialogIdleTime = sap.ui.xmlfragment("sap.ui.demo.cart.fragment.DialogIdleTime");
		
		_oViewDialogIdleTime.addStyleClass("sapUiSizeCompact").addStyleClass("myDialog");
		_oViewDialogIdleTime.open();
		window.isDialogOpen = true;
	}			 
                
    function onIdleTimeConfirm () {
        window.location.reload();
    }