sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
	], function (Object, JSONModel, ODataModel,Filter, FilterOperator) {
	"use strict";
	return Object.extend("hani.org.il.ODataTimeout.model.MainService", {

		// -----------------------------------------------------------------------------------------------------------------
		
		 // TODO: Add metadata (if any)
		metadata: {
			properties: {
				oView: {
					oView: {
						type: "sap.ui.view"
					},
					bMock: {
						type: "boolean",
						defaultValue: false
					},
					sUrl: {
						type: "string"
					}

				}
			}
		},

		// -----------------------------------------------------------------------------------------------------------------

		 // TODO: init properties (if any) 
		 constructor: function(view,isComponent) {
			 //this.oView = view;
	         //this.bMock = false;
	         this.bMock = true;
	         //this.sUrl = GeneralConstants.SERVICE_URL;
	         if (!isComponent) {
				this.sUrl = view.getController().getOwnerComponent().getModel().sServiceUrl ; 
			}else{
				this.sUrl = view.getModel().sServiceUrl ; 
			}
		 },

		 // -----------------------------------------------------------------------------------------------------------------
		 
		 setODataTimerOn: function (nTimeout) {
			 return new Promise((resolve, reject) => {
			     setTimeout(() => { reject({timeout: true}); }, nTimeout);
			 });
		},
		 
		// -----------------------------------------------------------------------------------------------------------------
		
		getEmpDataSet: function(fMonth) {
			const sUrl =  this.sUrl ; //  "/sap/opu/odata/sap/ZBO_ODATA_BKPF_SRV/";  ;
            return new Promise(function(resolve, reject) {
           
               const oModel = new ODataModel(sUrl);

				var aFilters = [];
				var oFilter1 = new Filter("IvMonth", FilterOperator.EQ, fMonth );
				aFilters.push(oFilter1);


               
               sap.ui.core.BusyIndicator.show(0);
               oModel.read("/GetEmpDataSet", {
             	   filters: aFilters,
            	   success: (oData, oResponse)  => resolve({oData  , oResponse}),
                   error:   (oError) => reject(oError)
               });
            });           
		},

		getEtTypesSet: function() {
			const sUrl =  this.sUrl ; //  "/sap/opu/odata/sap/ZBO_ODATA_BKPF_SRV/";  ;
            return new Promise(function(resolve, reject) {
               const oModel = new ODataModel(sUrl);
               sap.ui.core.BusyIndicator.show(0);
               oModel.read("/EtTypesSet", {
            	   success: (oData, oResponse)  => resolve({oData  , oResponse}),
                   error:   (oError) => reject(oError)
               });
            });           
		},	

		saveEtTypesSet: function(oData) {
			const sUrl =  this.sUrl ; //  "/sap/opu/odata/sap/ZBO_ODATA_BKPF_SRV/";  ;		
            return new Promise(function(resolve, reject) {
               const oModel = new ODataModel(sUrl);
			   sap.ui.core.BusyIndicator.show(0);
			   oModel.create("/SetEmpDataSet",oData ,  {
					success: (oData, oResponse)  => resolve({oData, oResponse}),
					error:   (oError) => reject(oError)
			   });
			});           
		}, 	 

		getEmpDetailsSet: function(pernr) {
			const sUrl =  this.sUrl ; //  "/sap/opu/odata/sap/ZBO_ODATA_BKPF_SRV/";  ;
            return new Promise(function(resolve, reject) {
               const oModel = new ODataModel(sUrl);
               sap.ui.core.BusyIndicator.show(0);
               oModel.read("/GetEmpDetailsSet(Pernr='" + pernr +"')", {
            	   success: (oData, oResponse)  => resolve({oData  , oResponse}),
                   error:   (oError) => reject(oError)
               });
            });           
		},			
		
		
		readChecklistEntity: function(path) {
		  var that = this;
					
		  return new Promise(
			function(resolve, reject) {
				    that.getModel().read(path, {
					  success: function(oData) {
					    resolve(oData);
					  },
	                  error: function(oResult) {
					    reject(oResult);
	                  }
	                });
		        });
		},	
		
/*
		getUserDetails: function() {
			const sUrl =  this.sUrl ; //  "/sap/opu/odata/sap/ZBO_ODATA_BKPF_SRV/";  ;
            return new Promise(function(resolve, reject) {
           
               const oModel = new ODataModel(sUrl);
               
               sap.ui.core.BusyIndicator.show(0);
               oModel.read("/GetEmpDataSet", {
            	   success: (oData, oResponse)  => resolve({oData, oResponse}),
                   error:   (oError) => reject(oError)
               });
            });           
		},
	*/
		
		
		// -----------------------------------------------------------------------------------------------------------------
	 
	});
});