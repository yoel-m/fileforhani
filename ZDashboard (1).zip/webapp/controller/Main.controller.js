sap.ui.define([
	"sap/ui/core/mvc/Controller" , 
	"../model/formatter",
	"sap/ui/core/BusyIndicator", 
	"ipa/org/il/zdashboard/model/MainService",
	"sap/ui/model/json/JSONModel",
    "sap/viz/ui5/format/ChartFormatter",
    "sap/viz/ui5/api/env/Format",
    "../model/InitPage",
    "../model/InitPageXblnr"
], function(Controller, formatter,BusyIndicator, MainService,JSONModel,ChartFormatter,Format,InitPageUtil,InitPageXblnr) {
	"use strict";

	return Controller.extend("ipa.org.il.zdashboard.controller.Main", {
		
		formatter: formatter,
		
		 oVizFrame : null  ,
	
		onInit : function () {
			
			var oView = this.getView() ; 
	    	var oService = new MainService(oView, false);

			BusyIndicator.show() ; 
			oService.getClientsData();
	 
		},
		/*
		onAfterRendering: function() {
        	debugger ; 
        	 
		},
		*/
	 

		retGroupByArray :function (arr){

		   let map = new Map() ;
		   let totalDebtSum = 0 ; 

		   for (let i = 0; i < arr.length; i++) {
		   	  totalDebtSum = totalDebtSum + parseFloat (arr[i].Dmbtr) ; 
		   	  let key = arr[i].Kunnr ;
		   	  let XblnrCount= 0 ; 
		   	  if (arr[i].Xblnr.trim().length > 0){
		   	  	XblnrCount = 1 ; 
		   	  }
		   	  let val = {"Dmbtr": parseFloat (arr[i].Dmbtr) , "Xblnr" : XblnrCount ,   "Name1" : arr[i].Name1 }; 

		      if (!map.has(key)) {
		         map.set(key, val) ;
		      } else {
		          map.set(key, {"Dmbtr": parseFloat (map.get(key).Dmbtr) + parseFloat (arr[i].Dmbtr) ,
		          "Xblnr" : map.get(key).Xblnr + XblnrCount , 
		          "Name1" : arr[i].Name1 } ) ; 
		      }
	
		   }
		   
		   let allDebtSort = new Map([...map.entries()].sort((a, b) => b[1].Dmbtr - a[1].Dmbtr)); 
		   let allXblnrSort = new Map([...map.entries()].sort((a, b) => b[1].Xblnr - a[1].Xblnr));
		   
		   allDebtSort.set("totalDebtSum" , totalDebtSum) ; 
		   allDebtSort.set("allXblnrSort" , allXblnrSort) ; 
		   return allDebtSort;
		
		},


		setChartXblnr : function (lastestHightXblnrModel) {
          
          this.getView().setModel(lastestHightXblnrModel, "lastHightXblnrModel") ; 
            var oVizFrameXblnr= this.getView().byId("idXblnrFrame");
			this.oVizFrameXblnr = oVizFrameXblnr ; 
			var oChartXblnr = this.getView().byId("idPopOverXblnr");
			oChartXblnr.connect(oVizFrameXblnr.getVizUid());
			InitPageXblnr.initPageSettings(this.getView());   
         
		},
		setChartDmbtr : function (lastestHightMbtrModel) {

           Format.numericFormatter(ChartFormatter.getInstance());
           var formatPattern = ChartFormatter.DefaultPattern;
         
           
            var oVizFrame = this.oVizFrame = this.getView().byId("idVizFrame");
            oVizFrame.setVizProperties({
                plotArea: {
                    dataLabel: {
                        formatString:formatPattern.SHORTFLOAT_MFD2,
                        visible: true
                    }
                },
                valueAxis: {
                    label: {
                        formatString: formatPattern.SHORTFLOAT
                    },
                    title: {
                        visible: true
                    }
                },
                categoryAxis: {
                    title: {
                        visible: true
                    }
                },
                title: {
                    visible: true,
                    text: 'לקוחות עם חוב הגבוה ביותר'
                }
            });
            
           
           
            
	 		var oDataset = new sap.viz.ui5.data.FlattenedDataset({
				dimensions : [{
					name : 'לקוחות',
					value : "{obj/Name1}"}],
				               
				measures : [{
					name : 'חוב',
					value : '{obj/Dmbtr}'} ],
				data : {
					path : "/ClientDmbtr"
				}			             

			});           
            
            oVizFrame.setModel(lastestHightMbtrModel);
            oVizFrame.setDataset(oDataset);
            
	  		oVizFrame.setVizProperties({
	            plotArea: {
	            	colorPalette : d3.scale.category20().range()
	                }});
			
			var feedValueAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
			      'uid': "valueAxis",
			      'type': "Measure",
			      'values': ["חוב"]
			    }), 
			    feedCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
			      'uid': "categoryAxis",
			      'type': "Dimension",
			      'values': ["לקוחות"]
			    });
			oVizFrame.addFeed(feedValueAxis);
			oVizFrame.addFeed(feedCategoryAxis);    
	 
            
            
           	var oPopOver = new sap.viz.ui5.controls.Popover( "idPopOver" ,{});

            oPopOver.connect(oVizFrame.getVizUid());
            oPopOver.setFormatString(formatPattern.STANDARDFLOAT);
            oVizFrame.setHeight("350px") ; 	
           	InitPageUtil.initPageSettings(this.getView()); 
           	
		},

		getClientsDataCallBack : function (o) {
			
			var oModel = o.oModel;		
			//var oData = oModel.getData() ; 
			//oModel.setSizeLimit(500);
		   this.getView().setModel ( oModel, "clientModel");
		   
			var arrayData = oModel.getData() ; 
			var allDebtSorted = this.retGroupByArray(arrayData) ; 
			
			//**********************************************************
			var totalDebtSum = allDebtSorted.get("totalDebtSum") ; 
			allDebtSorted.delete ("totalDebtSum") ; 
			this.getView().byId('totalDebt').setValue (totalDebtSum) ; 
			
			//**********************************************************
			var allXblnrSort = allDebtSorted.get("allXblnrSort") ; 
			allDebtSorted.delete ("allXblnrSort") ; 
			const iterator = allXblnrSort.entries();
			var fiveBigXblnrArr = [] ; 
			for (var i=0; i<5; i++) {
				var nxtIt = iterator.next() ;
				var elm =  {"Kunnr" : nxtIt.value[0] , "obj" :  nxtIt.value[1] }  ; 
				fiveBigXblnrArr.push(elm) ; 
			}		

		 	var lastestHightXblnr = {"ClientDmbtr" :  fiveBigXblnrArr} ; 
			var lastestHightXblnrModel = new JSONModel(lastestHightXblnr); 
			
			 this.setChartXblnr(lastestHightXblnrModel) ; 
		 
			
			//**********************************************************
		 
			const iterator1 = allDebtSorted.entries();
			var tenBigDebtArr = [] ; 
			for (var i=0; i<10; i++) {
				var nxtIt = iterator1.next() ;
				var elm =  {"Kunnr" : nxtIt.value[0] , "obj" :  nxtIt.value[1] }  ; 
				tenBigDebtArr.push(elm) ; 
			 
			}			
			 
		 	var lastestHightMbtr = {"ClientDmbtr" :  tenBigDebtArr} ; 
			var lastestHightMbtrModel = new JSONModel(lastestHightMbtr); 
			
			this.setChartDmbtr(lastestHightMbtrModel) ;
 
			BusyIndicator.hide();
		}
		
	});
});