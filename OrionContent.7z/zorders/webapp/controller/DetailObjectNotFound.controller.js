sap.ui.define([
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("icl.group.com.Orders.controller.DetailObjectNotFound", {});
});