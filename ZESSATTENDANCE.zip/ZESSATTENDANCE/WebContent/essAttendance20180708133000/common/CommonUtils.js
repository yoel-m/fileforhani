"use strict";
  
jQuery.sap.declare("common.CommonUtils");
jQuery.sap.require("sap.ui.commons.Dialog");
jQuery.sap.require("clalit.org.il.ZEssAttendance.constants.GeneralConstants");

sap.ui.base.Object.extend("common.CommonUtils", {
	// --------------------------------------------------------------------------------------------------------
	
	getMaterialAndSerialFromKit : function(s) {
		var o = {};
		
		if ((s) && (s.length === 13)) {
			o.material = s.substring(0,10);
			o.serial = s.substring(10,13);
		} else {
			o.material = s;
			o.serial = "000";
		}
		
		return o;
	},
	
	// --------------------------------------------------------------------------------------------------------
	
	formatDateToDDMMYYYY : function (dDate) {
		var iDay = dDate.getDate();
		var iMonth = dDate.getMonth() + 1;
		var iYear = dDate.getFullYear();
		
		var sDay = "";
		var sMonth = "";

		if (iDay < 10) {
			sDay = "0" + iDay.toString();
		} else {
			sDay = iDay.toString();
		}

		if (iMonth < 10) {
			sMonth = "0" + iMonth.toString();
		} else {
			sMonth = iMonth.toString();
		}

		return sDay + sMonth + iYear.toString();
	},
	
	// --------------------------------------------------------------------------------------------------------	
	
	getCurrentYear : function() {
		var dToday = new Date();
		return (dToday.getFullYear()).toString();
	},
	
	// --------------------------------------------------------------------------------------------------------
	
	formatDateToYYYYMMDD : function (dDate) {
		var iDay = dDate.getDate();
		var iMonth = dDate.getMonth() + 1;
		var iYear = dDate.getFullYear();
		
		var sDay = "";
		var sMonth = "";

		if (iDay < 10) {
			sDay = "0" + iDay.toString();
		} else {
			sDay = iDay.toString();
		}

		if (iMonth < 10) {
			sMonth = "0" + iMonth.toString();
		} else {
			sMonth = iMonth.toString();
		}

		return iYear.toString() + sMonth + sDay;
	},

	// --------------------------------------------------------------------------------------------------------
	
	formatDateToDDslashMMslashYYYY : function (dDate) {
		if (dDate==null) {
			return "";
		} else {
			var iDay = dDate.getDate();
			var iMonth = dDate.getMonth() + 1;
			var iYear = dDate.getFullYear();
			
			var sDay = "";
			var sMonth = "";
	
			if (iDay < 10) {
				sDay = "0" + iDay.toString();
			} else {
				sDay = iDay.toString();
			}
	
			if (iMonth < 10) {
				sMonth = "0" + iMonth.toString();
			} else {
				sMonth = iMonth.toString();
			}
	
			return sDay + "/" + sMonth + "/" + iYear.toString();
		}
	},
	
	// --------------------------------------------------------------------------------------------------------
	
	closeBusyDialog : function() {
		var oDialogFragment = sap.ui.xmlfragment("clalit.org.il.SterileSupply.fragment.BusyDialog");
		
		var oBusyDialogModel = sap.ui.getCore().getModel("oBusyDialogModel");
		if (oBusyDialogModel) {
			oDialogFragment = oBusyDialogModel.getData().o;
			oDialogFragment.close();
		}
	},
	
	// --------------------------------------------------------------------------------------------------------	

	openDialog: function (sType, sErrMessage) { // sType: I - Info ; E - Error
		var sTitle = "";
		var sIcon = "";
			
		if (sType === "E") {
			sTitle = "שגיאה";
			//sState = "Error";
			//sState = ValueState.Error;
			sIcon = "./" + window.clalitSterileSupplyAppVer + "/images/error_outline.svg";
		} else {
			sTitle = "הודעה";
			//sState = ValueState.None;
			//sIcon = "./" + window.clalitSterileSupplyAppVer + "/images/check_circle.svg";
			sIcon = "";
		}
		
		var dialog = new sap.m.Dialog({
			title: sTitle,
			type: 'Message',
			icon : sIcon,
			//state: 'Error',
			//state : sState,
			content: new sap.m.Text({
				text: sErrMessage
			}),
			beginButton: new sap.m.Button({
				text: 'אישור',
				press: function () {
					dialog.close();
				}
			}),
			afterClose: function() {
				dialog.destroy();
			}
		}).addStyleClass("myDialog").addStyleClass("clalitDialogIcon");

		dialog.open();
	},
	
	// --------------------------------------------------------------------------------------------------------	

	openDirtyModeDialog : function(oCtrl) {
		var dialog = new sap.m.Dialog({
			title: 'לחזור למסך ראשי?',
			type: 'Message',
			content: new sap.m.Text({
				text: 'כל העדכונים שהזנת עד עכשיו לא ישמרו'
			}),
			buttons: [		
				new sap.m.Button({
					text: 'אישור',
					press: function () {
						var oRouter = sap.ui.core.UIComponent.getRouterFor(oCtrl);
						oRouter.navTo("Main");
						dialog.close();
					}
				}),
				new sap.m.Button({
					text: 'ביטול',
					press: function () {
						dialog.close();
					}
				})
			],
			afterClose: function() {
				dialog.destroy();
			}
		}).addStyleClass("myDialog").addStyleClass("clalitDialogIcon");

		dialog.addEventDelegate({
			onAfterRendering: function() {
	          this.$().find('footer').find(".sapMTBSpacer").remove();
	          this.$().find('footer').attr({"style" : 'display: flex; justify-content: space-between;'});
			}
		}, dialog);

		dialog.open();
	}
	
	// --------------------------------------------------------------------------------------------------------	

});