"use strict";

jQuery.sap.declare("sap.ui.demo.cart.constants.TableCells");

sap.ui.demo.cart.constants.TableCells =  new function() {


		this.DATE_REPORT = 0;
		this.DAY = 1;
		
		//רב מינוי או רב שיבוץ
		this.ORG_UNIT = 2;
		
		//עובד רגיל
		this.ORG_START_HOUR = 2;
		this.ORG_END_HOUR = 3;
		this.START_HOUR = 4;
		this.END_HOUR = 5;
		this.ATTENDANCE_DAILY = 6;
		this.TEKEN_DAILY = 7;
		// this.ABS_CODE = 8;
		// this.ABS_FULL_DAY = 9;
		this.COMMENT_EMP = 11;
		this.COMMENT_MNG = 12;
		
	
    
};