sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device"
	//"clalit/org/il/ZEssAttendance/model/models"
], function(UIComponent, Device) {
	"use strict";

	return UIComponent.extend("clalit.org.il.ZEssAttendance.Component", {

		metadata: {
			manifest: 
	{
    "_version": "1.5.0",
    "sap.app": {
        "id": "clalit.org.il.ZEssAttendance",
        "type": "application",
        "i18n": "i18n/i18n.properties",
        "applicationVersion": {
            "version": "1.0.0"
        },
        "title": "{{appTitle}}",
        "description": "{{appDescription}}",
        "sourceTemplate": {
            "id": "servicecatalog.connectivityComponent",
            "version": "0.0.0"
        },
        "dataSources": {
            "ZHR_ESS_SELF_REPORTING_SRV": {
                "uri": "/sap/opu/odata/sap/ZHR_ESS_SELF_REPORTING_SRV/",
                "type": "OData",
                "settings": {
                    "odataVersion": "2.0",
                    "localUri": "localService/metadata.xml"
                }
            },
            "ZSH_EMPLOYEE_DATA_SRV": {
                "uri": "/sap/opu/odata/sap/ZSH_EMPLOYEE_DATA_SRV/",
                "type": "OData",
                "settings": {
                    "odataVersion": "2.0",
                    "localUri": "localService/ZSH_EMPLOYEE_DATA_SRV/metadata.xml"
                }
            }
        }
    },
    "sap.ui": {
        "technology": "UI5",
        "icons": {
            "icon": "",
            "favIcon": "",
            "phone": "",
            "phone@2": "",
            "tablet": "",
            "tablet@2": ""
        },
        "deviceTypes": {
            "desktop": true,
            "tablet": true,
            "phone": true
        },
        "supportedThemes": [
            "sap_hcb",
            "sap_belize"
        ]
    },
    "sap.ui5": {
        "rootView": {
            "viewName": "clalit.org.il.ZEssAttendance.view.Main",
            "type": "XML"
        },
        "dependencies": {
            "minUI5Version": "1.30.0",
            "libs": {
                "sap.ui.core": {},
                "sap.m": {},
                "sap.ui.layout": {}
            }
        },
        "contentDensities": {
            "compact": true,
            "cozy": true
        },
        "models": {
            "i18n": {
                "type": "sap.ui.model.resource.ResourceModel",
                "settings": {
                    "bundleName": "clalit.org.il.ZEssAttendance.i18n.i18n"
                }
            }
        },
        "resources": {
            "css": [
                {
                    "uri": "css/app.css"
                }
            ]
        }
    },
    "sap.platform.abap": {
        "uri": "/sap/bc/ui5_ui5/sap/zessattendance",
        "_version": "1.1.0"
    }
}			
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);


			//create Constants-Model for using in XML-Views
			var constantsMessagePoolModel = new sap.ui.model.json.JSONModel({
			     ERROR_USERDATA_INVALID : "שגיאה בנסיון לשלוף פרטי משתמש",
			     ERROR_CHECK_DAY_START_BIGGER_THAN_END : "שעת התחלה גדולה או שווה לשעת סיום"
			});
			
			constantsMessagePoolModel.setDefaultBindingMode("OneTime");
			sap.ui.getCore().setModel(constantsMessagePoolModel, "constMessagePoolModel");


			// set the device model
			//this.setModel(models.createDeviceModel(), "device");
		}
	});
});