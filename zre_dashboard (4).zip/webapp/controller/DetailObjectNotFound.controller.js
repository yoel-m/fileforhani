sap.ui.define([
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("sap.ui.demo.masterdetail.controller.DetailObjectNotFound", {});
});