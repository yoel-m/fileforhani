sap.ui.define([
	'jquery.sap.global',
	'sap/ui/demo/cart/controller/BaseController',
	'sap/ui/demo/cart/model/formatter',
	'sap/ui/demo/cart/constants/GeneralConstants',
	'sap/ui/demo/cart/constants/MessagePool',
	'sap/ui/demo/cart/model/cart',
	'sap/ui/model/json/JSONModel',
	'sap/ui/demo/cart/model/MngAttendanceService',
	'sap/ui/demo/cart/constants/TableCells',
	"sap/ui/core/ValueState",
	'sap/ui/demo/cart/model/PersoService',
	'sap/m/TablePersoController'
], function ($, BaseController, formatter, GeneralConstants, MessagePool, cart, JSONModel, MngAttendanceService, TableCells, ValueState, PersoService, TablePersoController) {
	"use strict";

	return BaseController.extend("sap.ui.demo.cart.controller.Product", {
		formatter : formatter,
		cart: cart,

		onInit : function () {
			var oComponent = this.getOwnerComponent();
			
			// var oViewModel = new JSONModel();
			// this.getView().setModel(oViewModel, "empDetail");
			
			var oView = this.getView();
			var oCtrl = this;
			
			var aData =  {productView: this.getView().getId() } ; 
			var viewGlobalModel = new sap.ui.model.json.JSONModel();
			viewGlobalModel.setData(aData);
			sap.ui.getCore().setModel(viewGlobalModel, "productViewModel");			
			
			this._router = oComponent.getRouter();
			
			if (sap.ui.getCore().getModel('sgiraDatesModel')) {
//				oView.setModel(sap.ui.getCore().getModel('sgiraDatesModel'), "sgiraDatesModel"); 
				this._router.getRoute("product").attachPatternMatched(this._routePatternMatched, this);
			}else{
		     window.location.replace ("/sap/bc/ui5_ui5/sap/zmngaproveatten/index.html");
			}
			
			var oTable = oView.byId("mainTable");
			
			/*
			oTable.addEventDelegate({
				onAfterRendering: function() {
					// טיפול בגלילת טבלה
				    $("#" + oView.byId("mainTable").getId() + "-vsb").scroll(function() {
				      
						jQuery.sap.delayedCall(100, oCtrl, function() {
							oCtrl.unMergeColumns();
							oCtrl.mergeColumns();
						});

             		});
				}
			}, oTable);*/
			
			
			// init and activate controller
			// this._oTPC = new TablePersoController({
			// 	table: this.byId("mainTable"),
			// 	//specify the first part of persistence ids e.g. 'demoApp-productsTable-dimensionsCol'
			// 	componentName: "Component",
			// 	persoService: PersoService
			// }).activate();

		},
		onOpenHelp: function() {
			window.open(GeneralConstants.HELP_URL);
		},
		
		onSendEmail: function(O){
			var empMail = this.getView().getModel('empDetail').getData().EmpMail ; 
			sap.m.URLHelper.triggerEmail(empMail, "מערכת נוכחות", "", "", "");
		},
		getSgiraDateCallback : function(o) {
			var oView = o.oView;
			var oModel = o.oModel;
		//	var oCtrl = oView.getController();
			
			var oModelData = o.oModel.getData().sgiraDatesModel ;
			oModel.setData(oModelData[0]); 
		//	oView.setModel(oModel, "empDetailModel"); 
			/*
			var sgiraDatesModel = new JSONModel( ) ; 
			sgiraDatesModel.setData(oModelData) ; */
			sap.ui.getCore().setModel(oModel, "sgiraDatesModel");	
			oView.setModel(oModel, "sgiraDatesModel");
			
			oView.getModel("sgiraDatesModel").refresh();
		},
		
		
	 
		getEmployeeFromListCallback:  function(o) {
			
			var oView = o.oView;
			var oModel = o.oModel;
			if (oModel !== undefined) {
				var oModelData = o.oModel.getData();
				oModel.setData(oModelData[0]); 
		 		oView.setModel(oModel, "empDetail");
		 		var monthSelectedValue = sap.ui.getCore().getModel('oSelectedMonthModel').getData().monthSelectedKey;
		 		
				var oService = new MngAttendanceService(oView, false);
			    oService.getEmployeeDataAndAttendance(monthSelectedValue, oModel.getData().EmpUname , oModel.getData().ManagerPernr);	
			}

		},
		
		_routePatternMatched: function(oEvent) {
			
			this.openBusyDialog();
			
			if (sap.ui.getCore().getModel('sgiraDatesModel')) {
				this.getView().setModel(sap.ui.getCore().getModel('sgiraDatesModel'), "sgiraDatesModel"); 
			}

			
			var sId = oEvent.getParameter("arguments").EmpMainPernr,
				managerID = oEvent.getParameter("arguments").Manager,
				oView = this.getView(),
				monthSelectedValue = sap.ui.getCore().getModel('oSelectedMonthModel').getData().monthSelectedKey;
				
			this.getView().setModel(sap.ui.getCore().getModel('modelDates'), "modelDates");
			this.getView().setModel(sap.ui.getCore().getModel('oSelectedMonthModel'), "oSelectedMonthModel");
			this.getView().setModel(sap.ui.getCore().getModel('oMngHeaderDetails'), "oMngHeaderDetails");
			
			var viewHomeModel = sap.ui.getCore().getModel("categoryViewModel");	
			var categoryView = sap.ui.getCore().byId(viewHomeModel.getData().categoryView); 
			this.getView().setModel(categoryView.getModel("empListModel"), "empListModel");
		
			// the binding should be done after insuring that the metadata is loaded successfully
			var oService = new MngAttendanceService(oView, false);
			oService.getEmployeeFromList(monthSelectedValue, managerID, sId);
			
			this.getView().byId("Panel_productList").setExpanded(false);
			this.getView().byId("Panel_monimTable").setExpanded(false);
			    
	 			
			/*
			oModel.metadataLoaded().then(function () {
				var sPath = "/" + this.getModel().createKey("Emp_listSet", {
						EmpMainPernr: sId, ManagerPernr:managerID , Month:monthSelectedValue
					});
				oView.bindElement({
					path : sPath,
					events: {
						dataRequested: function () {
							oView.setBusy(true);
						},
						dataReceived: function () {
							oView.setBusy(false);
						}
					}
				});
				var oData = oModel.getData(sPath);
				this.getModel("empDetail").setData (oData) ;
				//if there is no data the model has to request new data
				if (!oData) {
					oView.setBusyIndicatorDelay(0);
					oView.getElementBinding().attachEventOnce("dataReceived", function() {
						// reset to default
						oView.setBusyIndicatorDelay(null);
						this._checkIfProductAvailable(sPath);
					}.bind(this));
				}
			}.bind(this)); */
		},
		
		// -------------------------------------------------------------------------------------------------------------------------		
		setApproveOvertimeInMonimTable: function() {
			var oView = this.getView(),
				overtimeApproveData = oView.getModel("overtimeApproveModel").getData(),
				empMonimModel = oView.getModel("monimModel"),
				empMonimData = oView.getModel("monimModel").getData();
			for (var i=0; i < empMonimData.length; i++) {
				for (var j=0; j < overtimeApproveData.length; j++) {
					
					if(empMonimData[i].Pernr === overtimeApproveData[j].Pernr){
						empMonimData[i].OvertimeApproveMng = overtimeApproveData[j].Anzhl;
					}
				}
			}
			empMonimModel.setData(empMonimData);
			oView.setModel(empMonimModel, "monimModel");
		},
		// -------------------------------------------------------------------------------------------------------------------------		
		// setMonimModelByPernr: function() {
		// 	var oView = this.getView(),
		// 		empPernr = oView.getModel("empDetail").getData().EmpPernr,
		// 		empMonimData = sap.ui.getCore().getModel("monimModel").getData(),
		// 		empMonimByPernrModel = new JSONModel();
				
		// 	for (var i=0; i<empMonimData.length; i++) {
				
		// 		if(empMonimData[i].Pernr === empPernr){
		// 			empMonimByPernrModel.setData(empMonimData[i]);
		// 		}
		// 	}
		// 	empMonimByPernrModel.getData().OvertimeAppMng = empMonimByPernrModel.getData().Overtime;// נשמור את השעות נוספות שהמנהל יאשר על מנת לא לדרוס את המקור
			
		// 	oView.setModel(empMonimByPernrModel, "empMonimByPernrModel");
		// },
		// -------------------------------------------------------------------------------------------------------------------------		
		
		// מודל עבור הטבלה של אישור שעות נוספות בחלון דיאלוג
		setMonimModelOvertimeSource: function() {
			var oView = this.getView(),
				monimData = oView.getModel("monimModel").getData(),
				monimModelMngApproveDialog = new JSONModel(),
			//	empPernr = oView.getModel("empDetail").getData().EmpPernr,   //"Y 04022019"
				
				// ----- שורות -----
				oRow = {},
				aRow = [],
				oRowSource = {};
				
			for (var i=0; i<monimData.length; i++) {
					oRowSource = monimData[i];
					
//					if(oRowSource.Pernr === empPernr){
						
						oRow = {};
						
						oRow.Pernr = oRowSource.Pernr;
						oRow.WerksText = oRowSource.WerksText;
						oRow.OrgunitTxt = oRowSource.OrgunitTxt;
						oRow.Overtime = oRowSource.Overtime;
						oRow.OvertimeAppMng = oRowSource.Overtime;// נשמור את השעות נוספות שהמנהל יאשר על מנת לא לדרוס את המקור
						oRow.checkMngApproveOvertime = false;
						
						aRow.push(oRow);
//					}
				}

				monimModelMngApproveDialog.setData({"lines" : aRow});	
				sap.ui.getCore().setModel(monimModelMngApproveDialog, "monimModelMngApproveDialog");

		},
		// -------------------------------------------------------------------------------------------------------------------------		
		onCheckMngApproveOvertime: function(oEvent) {
			var oBindingContext = oEvent.getSource().getBindingContext("monimModelMngApproveDialog");
			var isApproveOvertimeSelected = oEvent.getParameter("selected");
			if(! isApproveOvertimeSelected){
				oBindingContext.getObject().OvertimeAppMng = GeneralConstants.OVERTIME_NULLIFY;
				oBindingContext.oModel.refresh(); 
			}
		},
		// -------------------------------------------------------------------------------------------------------------------------		
		getEmployeeAttendanceDataCallback: function(o) {
			
			console.debug("getEmployeeAttendanceDataCallback");
			
			var oView = this.getView();
			var oModel = o.oModel;
			
			if (oModel !== undefined) {
				
				var empHeaderDetailsAllPernrsModel = new JSONModel(); 
				var monimModel = new JSONModel(); 
				var overtimeApproveModel = new JSONModel();
		 
				empHeaderDetailsAllPernrsModel.setData (oModel.getData()[0].Header_empnav.results);
				monimModel.setData (oModel.getData()[0].Header_Monthlynav.results);
				overtimeApproveModel.setData(oModel.getData()[0].Header_approvnav.results);
				
				oView.setModel(empHeaderDetailsAllPernrsModel, "empHeaderDetailsAllPernrsModel");
				oView.setModel(monimModel, "monimModel");
				oView.setModel(overtimeApproveModel, "overtimeApproveModel");
				
				this.setMonimModelOvertimeSource();
				this.setApproveOvertimeInMonimTable();
				//oView.setModel(sap.ui.getCore().getModel("monimModel"), "monimModel");
				
				var isEmpMultiPositionOrAssignment = oModel.getData()[0].Header_empnav.results.length > 1 ? true : false;
				
			    var heightScreen = screen.height;
			    var widthScreen = screen.width;
				console.log ('heightScreen = ' + heightScreen) ;
				console.log ('widthScreen = ' + widthScreen) ;
					
				var initVisibilityModel ; 	
				if (heightScreen >= 1024 ) {
					  initVisibilityModel = new JSONModel({
						"isEmpMultiPositionOrAssignment" : isEmpMultiPositionOrAssignment,
						"empUname" : oModel.getData()[0].IEmpUname,
						"showMoreCols" : false,
						"minRow" : 17
					});				
				}else if (heightScreen == 768 ) {
						initVisibilityModel = new JSONModel({
						"isEmpMultiPositionOrAssignment" : isEmpMultiPositionOrAssignment,
						"empUname" : oModel.getData()[0].IEmpUname,
						"showMoreCols" : false,
						"minRow" : 10
					});	
				}else{
					  initVisibilityModel = new JSONModel({
						"isEmpMultiPositionOrAssignment" : isEmpMultiPositionOrAssignment,
						"empUname" : oModel.getData()[0].IEmpUname,
						"showMoreCols" : false,
						"minRow" : 7
					});						
				}
				

				oView.setModel(initVisibilityModel, "initVisibilityModel");
				
				//נתוני טבלת דיווח השעות
				var oTableData = oModel.getData()[0].Emp_linesnav.results;
				var oModelEmpAttendanceTable = new JSONModel();
				// ----- שורות -----
				var oRow = {};
				var aRow = [];
				var oRowSource = {};
				
				for (var i=0; i<oTableData.length; i++) {
					oRowSource = oTableData[i];
					oRow = {};
					
					oRow.Uname = oRowSource.Uname;
					oRow.pernr = oRowSource.Pernr;
					
					oRow.isRelevantMng = oRowSource.AttMngRelv === "X" ? true : false;
					
					oRow.dateReport = model.formatter.formatSapDate(oRowSource.Ldate);
					oRow.dateReportSource = oRowSource.Ldate;
					
					//במידה ויש חג נרצה להציג את תיאור החג במקום תיאור היום בשבוע
					if(oRowSource.DayType !== "" && oRowSource.DayType.length > 0){
						oRow.dayDesc = oRowSource.DayType;
					}
						
					else{
						oRow.dayDesc = oRowSource.DayText;
					}
						
					oRow.werksTxt = oRowSource.WerksText;
					
					//this.isEmpMultiPositionOrAssignmentPerLine(oRow, oRowSource.Pernr);
				
					oRow.orgUnit = oRowSource.Orgunit;
					oRow.orgUnitTxt = oRowSource.OrgunitTxt;
					
					oRow.pernrKey = oRowSource.PernrKey;
					oRow.orgIn = oRowSource.OrgIn === GeneralConstants.SAP_FORMAT_BLANK_ORG_HOUR ? "" : model.formatter.formatSapToTime(oRowSource.OrgIn);
					oRow.orgOut = oRowSource.OrgOut === GeneralConstants.SAP_FORMAT_BLANK_ORG_HOUR ? "" : model.formatter.formatSapToTime(oRowSource.OrgOut);
					
					// האם מדובר על שורת נוכחות
					if(oRowSource.AttAbsNum.length === 0 || oRowSource.AttAbsNum === ""){
						oRow.clockInDisplay = model.formatter.formatSapToTime(oRowSource.Begtm);
						oRow.clockOutDisplay = model.formatter.formatSapToTime(oRowSource.Endtm);
					}
					//העדרות
					else{
						oRow.clockInDisplay = model.formatter.formatSapToTime(oRowSource.StartAbs);
						oRow.clockOutDisplay = model.formatter.formatSapToTime(oRowSource.EndAbs);
					}
					
					oRow.clockIn = model.formatter.formatSapToTime(oRowSource.Begtm);
					oRow.clockOut = model.formatter.formatSapToTime(oRowSource.Endtm);
					
					oRow.attandanceDaily = oRowSource.AttandanceDaily.trim() === "0.00" ? "" : oRowSource.AttandanceDaily;
					oRow.tekenDaily = oRowSource.TekenDaily.trim() === "0.00" ? "" : oRowSource.TekenDaily;
					
 					oRow.startAbs = oRowSource.StartAbs;
					oRow.endAbs = oRowSource.EndAbs;
					
					oRow.endAbs = oRowSource.RegularDaily;
            		oRow.overDaily = oRowSource.OverDaily;
            		oRow.lackDaily = oRowSource.LackDaily;
            		
					//עבור כניסה או יציאה בתפקיד
					oRow.attP11 = oRowSource.AttP11;

					oRow.isFullDay = oRowSource.PeridFullDayInd === "X" ? true : false;
					
					oRow.empComment = oRowSource.EmpComment;
					if (oRow.empComment.trim() === "") {
						oRow.empCommentColor = ""; 
						oRow.empCommentSrc = ""; 
					} else {
							oRow.empCommentColor = "green"; 
							oRow.empCommentSrc = "sap-icon://notification-2";
					}
					
					oRow.mngComment = oRowSource.MngComment;
					if (oRow.mngComment.trim() === "") {
						oRow.mngCommentColor = "black"; 
						oRow.mngCommentSrc = "sap-icon://post"; 
					} else {
						oRow.mngCommentColor = "green"; 
						oRow.mngCommentSrc = "sap-icon://notification-2";
					}
					
					//במידה וחוזר סוג תנועה מיוחדת, היא תוצג כערך נבחר ברשימת היעדרות
					if(oRowSource.AttP11.length > 0){
						oRow.attAbsNum = oRowSource.AttP11;
					}
					else{
						oRow.attAbsNum = oRowSource.AttAbsNum;
					}
					
					// במידה ומדובר בנוכחות, כלומר השדה סוג היעדרות ריק, יוצג בעמודה סוג הערך "נוכחות" במקום
					if(oRowSource.AttAbsDisc.trim().length === 0 && (oRow.clockIn !== null || oRow.clockOut !== null)){
						oRow.attAbsText = MessagePool.COLUMN_TYPE_ATTENDANCE;
					}
					else{
						oRow.attAbsText = oRowSource.AttAbsDisc;
					}
					
					//האם מדובר על הזנה של כניסה או יציאה ידנית - מוצג אייקון לצד השעה
					oRow.manualClockIn = oRowSource.BChange  === "X" ? true : false;
					oRow.manualClockOut = oRowSource.EChange  === "X" ? true : false;
					
					oRow.isRowEditable = oRowSource.AttMngRelv === "X" ? true : false;
					
					if(! oRow.isRowEditable){
						oRow.mngCommentColor = "gray"; 
					}
						
					aRow.push(oRow);
				}

				oModelEmpAttendanceTable.setData({"lines" : aRow});	
				oView.setModel(oModelEmpAttendanceTable, "oModelEmpAttendanceTable");
			}
			this.handelEnablementIssues();
			/*
			jQuery.sap.delayedCall(100, this, function() {
				
				this.unMergeColumns();
				this.mergeColumns();

			});*/
			
			this.closeBusyDialog();
			
		},
		
		
		// -------------------------------------------------------------------------------------------------------------------------		
	
		mergeColumns : function() {
		
        var oTable;
        oTable = this.getView().byId("mainTable");
        
        var initVisibilityModel = this.getView().getModel("initVisibilityModel");
 
		var isEmpMultiPositionOrAssignment = initVisibilityModel.isEmpMultiPositionOrAssignment;

		var isEmpMulti = isEmpMultiPositionOrAssignment === true ? 1 : 0;
		
		//טיפול במיזוג שורות כאשר יש מספר שורות באותו תאריך
        var aRows = oTable.getRows();
         if (aRows && aRows.length > 0) {
             var pRow = {};
             for (var i = 0; i < aRows.length; i++) {
             	
                 if (i > 0) {
                 	
                     var pCell = pRow.getCells()[TableCells.DATE_REPORT];
                     var cCell = aRows[i].getCells()[TableCells.DATE_REPORT];

                     if (cCell.getText() === pCell.getText()) {
                     	//מיזוג עמודת התאריך
                         $("#" + cCell.getId()).css("visibility", "hidden");
                         $("#" + pRow.getId() + "-col" + TableCells.DATE_REPORT).css("border-bottom-style", "hidden");
        
                         //מיזוג עמודת היום
                         $("#" + aRows[i].getCells()[TableCells.DAY].getId()).css("visibility", "hidden");
                         $("#" + pRow.getId() + "-col" + TableCells.DAY).css("border-bottom-style", "hidden");

						  // מיזוג עמודת היעדרות יום מלא
						  var absFullDayIndex = TableCells.ABS_FULL_DAY + isEmpMulti;

		                  $("#" + aRows[i].getCells()[absFullDayIndex].getId()).css("visibility", "hidden");
		                  $("#" + pRow.getId() + "-col" + absFullDayIndex).css("border-bottom-style", "hidden");

						  //מיזוג עמודת הערה עובד
						  var commentIndex = TableCells.COMMENT_EMP + isEmpMulti;
		                 
		                  $("#" + aRows[i].getCells()[commentIndex].getId()).css("visibility", "hidden");
		                  $("#" + pRow.getId() + "-col" + commentIndex).css("border-bottom-style", "hidden");
		                  
		                   //מיזוג עמודת הערה מנהל
						  var commentIndex = TableCells.COMMENT_MNG + isEmpMulti;
		                 
		                  $("#" + aRows[i].getCells()[commentIndex].getId()).css("visibility", "hidden");
		                  $("#" + pRow.getId() + "-col" + commentIndex).css("border-bottom-style", "hidden");

						//משתמש שמוגדר רב שיבוץ או רב מינוי יש עמודה נוספת של יחידה
						  if(isEmpMultiPositionOrAssignment){
						  			

				    		if (pRow.getBindingContext("oModelEmpAttendanceTable")) {
		            			var pObj = pRow.getBindingContext("oModelEmpAttendanceTable").getObject();
				    		}
				    		if (aRows[i].getBindingContext("oModelEmpAttendanceTable")) {
		            			var cObj = aRows[i].getBindingContext("oModelEmpAttendanceTable").getObject();
				    		}
				    		
		                    if (pObj !== undefined && cObj !== undefined ){
		                     	//בדיקה האם מדובר באותה יחידה
			                     if(pObj.pernr === cObj.pernr){
			                     	
			                         //מיזוג עמודת סה"כ יומי
			                         var attendanceDayIndex = TableCells.ATTENDANCE_DAILY + isEmpMulti;
			                         $("#" + aRows[i].getCells()[attendanceDayIndex].getId()).css("visibility", "hidden");
			                         $("#" + pRow.getId() + "-col" + attendanceDayIndex).css("border-bottom-style", "hidden");
			                         
			                         //מיזוג עמודת תקן
			                         var tekenDailyIndex = TableCells.TEKEN_DAILY + isEmpMulti;
			                         $("#" + aRows[i].getCells()[tekenDailyIndex].getId()).css("visibility", "hidden");
			                         $("#" + pRow.getId() + "-col" + tekenDailyIndex).css("border-bottom-style", "hidden");
			                     }
		                     }
	                     }
						  
						  else{
							  //מיזוג עמודת סה"כ יומי
			                  $("#" + aRows[i].getCells()[TableCells.ATTENDANCE_DAILY].getId()).css("visibility", "hidden");
			                  $("#" + pRow.getId() + "-col" + TableCells.ATTENDANCE_DAILY).css("border-bottom-style", "hidden");
			                  
								//מיזוג עמודת תקן
			                  $("#" + aRows[i].getCells()[TableCells.TEKEN_DAILY].getId()).css("visibility", "hidden");
			                  $("#" + pRow.getId() + "-col" + TableCells.TEKEN_DAILY).css("border-bottom-style", "hidden");

						  }
                     }
            	 }
            	 pRow = aRows[i];
	          }
	      }

	      
	      
		},
		
		// -------------------------------------------------------------------------------------------------------------------------		
		
		unMergeColumns : function() {
        var oTable;

        oTable = this.getView().byId("mainTable");

		//טיפול במיזוג שורות כאשר יש כמה דיווחים באותו תאריך
        var aRows = oTable.getRows();
         if (aRows && aRows.length > 0) {
             var pRow = {};
             for (var i = 0; i < aRows.length; i++) {
             	pRow = aRows[i];
				for(var j=0; j < pRow.getCells().length; j++ ){
					var oCell = pRow.getCells()[j];
					
					$("#" + oCell.getId()).css("visibility", "visible");
            		$("#" + pRow.getId() + "-col" + j  ).css("border-bottom-style", "solid");
				}
				
             }
             
	       }
	      
		},

		
		// -------------------------------------------------------------------------------------------------------------------------		
		updateMngCommPerLineCallback : function (o) {

		},
		// -------------------------------------------------------------------------------------------------------------------------
		onOpenEmpComment : function (oEvent) {
			// create popover
			var oBindingContext = oEvent.getSource().getBindingContext("oModelEmpAttendanceTable");
			var oContextObject = oBindingContext.getObject() ;
		//	if(oContextObject.isRowEditable){
		//	if (!this._oPopover) {
				this._oPopover = sap.ui.xmlfragment("sap.ui.demo.cart.fragment.EmpCommentPopover", this);
				this.getView().addDependent(this._oPopover);
				this._oPopover.setModel(this.getView().getModel('oModelEmpAttendanceTable')) ; 
			 	this._oPopover.bindElement (oBindingContext.sPath );
		//	}

			this._oPopover.openBy(oEvent.getSource());
		//	}
		},
		// -------------------------------------------------------------------------------------------------------------------------
		onOpenMngComment : function (oEvent) {
			// create popover
			var oBindingContext = oEvent.getSource().getBindingContext("oModelEmpAttendanceTable");
			var oContextObject = oBindingContext.getObject() ;
			if(oContextObject.isRowEditable){
		//	if (!this._oPopover) {
				this._oPopover = sap.ui.xmlfragment("sap.ui.demo.cart.fragment.MngCommentPopover", this);
				this.getView().addDependent(this._oPopover);
				this._oPopover.setModel(this.getView().getModel('oModelEmpAttendanceTable')) ; 
			 	this._oPopover.bindElement (oBindingContext.sPath );
		//	}

			this._oPopover.openBy(oEvent.getSource());
			}
		},
		
	// -------------------------------------------------------------------------------------------------------------------------
		closeMngCommentUpdatePress: function (oEvent) {
			if (this._oPopover) {
				 this._oPopover.close();
				 this._oPopover.destroy();
			}
		},
		
		
		
		
		
	// -------------------------------------------------------------------------------------------------------------------------
		handleMngCommentUpdatePress: function (oEvent) {
			
			if (this._oPopover) {
				var oContextObject = this._oPopover.getBindingContext().getObject() ;
				if (oContextObject.mngComment.trim().length > 0) {
					oContextObject.mngCommentColor = "green" ;
					oContextObject.mngCommentSrc = "sap-icon://notification-2"; 
					this._oPopover.getBindingContext().oModel.refresh() ; 
				}  else {
					oContextObject.mngCommentColor = "black" ; 
					oContextObject.mngCommentSrc = "sap-icon://post"; 
					this._oPopover.getBindingContext().oModel.refresh() ; 				
				}
				var oView = this.getView();
				
				var empUname = oContextObject.Uname;
				var dateReport = model.formatter.formatDateToYYYYMMDD(oContextObject.dateReport);
				var strComment = oContextObject.mngComment;
				// בסגירה של דיאלוג כתיבת הערה, נעדכן אותה מיד בשרת
				var oService = new MngAttendanceService(oView, false);
			    oService.updateMngCommPerLine(empUname, dateReport, strComment);

				
				// oView.getModel("oModelEmpAttendanceTable").setProperty('/modelData/lines', this._oPopover.getBindingContext().getModel());
				// oView.getModel("oModelEmpAttendanceTable").refresh();
				
				 this._oPopover.close();
				 this._oPopover.destroy();

				// jQuery.sap.delayedCall(100, this, function() {
				// 	this.handleErrorsDesginAfterScrolling(false);
				// });
			}
		},
	// -------------------------------------------------------------------------------------------------------------------------
		handleEmpCommentClosePress: function (oEvent) {
			
			if (this._oPopover) {
				 this._oPopover.close();
				 this._oPopover.destroy();
			}
		},
	// -------------------------------------------------------------------------------------------------------------------------
		onPrint: function (oEvent) {
			
			var monthSelectedValue = sap.ui.getCore().getModel('oSelectedMonthModel').getData().monthSelectedKey;
			var sPeriod = monthSelectedValue;
			
			var oView = this.getView();
			var empDetailModel = oView.getModel("empDetail");
			var empUname = empDetailModel.getData().EmpUname;
	
			var serviceUrl = GeneralConstants.SERVICE_URL + "/Print_fileSet(IUname='" + empUname +"',IMonth='" + sPeriod +"')/$value";
					
			//window.open(serviceUrl, "_blank", "toolbar=no");
			
			window.open(serviceUrl);
		},
	// -------------------------------------------------------------------------------------------------------------------------
		handelEnablementIssues: function () {
			
		var approveBtnEnabled = false;
		var declineBtnEnabled = false;
		var cancelApproveBtnEnabled = false;
		
		var oView = this.getView();
		var sgiraDatesModel = oView.getModel("sgiraDatesModel").getData();
		
		
		var viewHomeModel = sap.ui.getCore().getModel("categoryViewModel");	
		var categoryView  = sap.ui.getCore().byId(viewHomeModel.getData().categoryView); 
		var empListData = categoryView.getModel("empListModel").getData();
		oView.setModel(categoryView.getModel("empListModel"), "empListModel");
		
		
		var empHeaderDetailsAllPernrsData = oView.getModel("empHeaderDetailsAllPernrsModel").getData();
		
		var initVisibilityModel = oView.getModel("initVisibilityModel");
		
		var isMonthOpen = sgiraDatesModel.StatusSgira === "X" ? true : false;
		var eDateEndMng = sgiraDatesModel.EndSgiraMng;
		// תאריך נוכחי קטן שווה לתאריך סגירת אישורי מנהל
		var isCurrentDateBeforeEndMng = model.formatter.formatDateToYYYYMMDD(eDateEndMng) >= model.formatter.todayAsYYYYMMDD() ? true : false;
		
		//החודש פתוח לעידכון וכן לא עבר תאריך אישור מנהל
		if (isMonthOpen === true && isCurrentDateBeforeEndMng) {
			for (var i=0; i<empListData.length; i++) {
				if(empListData[i].EmpUname === initVisibilityModel.getData().empUname){
					var status = empListData[i].EmpTmStatus;
					//אם הסטאטוס ריק, זה כמו פתוח
					if(status === ""){
						status = "0";
					}
					switch(status){
						//פתוח
						case "0":
							approveBtnEnabled = true;	
							declineBtnEnabled = false;
							cancelApproveBtnEnabled = false;
						break;
						// נשלח לאישור מנהל
						case "1":
							approveBtnEnabled = true;
							declineBtnEnabled = true;
							cancelApproveBtnEnabled = false;
						break;
						
						//מנהל אישר
						case "2":
							approveBtnEnabled = false;	
							declineBtnEnabled = false;
							cancelApproveBtnEnabled = true;
						break;
					
						// מנהלן אישר
						case "4":
							approveBtnEnabled = false;	
							declineBtnEnabled = false;
							cancelApproveBtnEnabled = true;
						break;
					}

					
				}

			}
		}
		
		else{
				approveBtnEnabled = false;	
				declineBtnEnabled = false;
				cancelApproveBtnEnabled = false;
		}
		
		initVisibilityModel.setProperty("/approveBtnEnabled", approveBtnEnabled);
		initVisibilityModel.setProperty("/declineBtnEnabled", declineBtnEnabled);
		initVisibilityModel.setProperty("/cancelApproveBtnEnabled", cancelApproveBtnEnabled);
		
		var isTblEditabled = approveBtnEnabled || cancelApproveBtnEnabled ? true : false;
		initVisibilityModel.setProperty("/isTblEditabled",isTblEditabled);
		
		 this.getView().setModel(initVisibilityModel, "initVisibilityModel");
		 this.getView().getModel("initVisibilityModel").refresh();
			
		},
	//---------------------------------------------------------------------------------------------------

		onCheckApproveChanges: function(oEvent) {
			var oModelDialog = new JSONModel();
			oModelDialog = sap.ui.getCore().getModel("oModelDialog");
			var valueState = oEvent.getParameter("selected") ?  ValueState.Success :  ValueState.Error;
			var approveBtnEnabled = oEvent.getParameter("selected");
			
			oModelDialog.setProperty("/valueState", valueState);
			oModelDialog.setProperty("/approveBtnEnabled", approveBtnEnabled);
		
			sap.ui.getCore().setModel(null, "oModelDialog");
			sap.ui.getCore().setModel(oModelDialog, "oModelDialog");
			sap.ui.getCore().getModel("oModelDialog").refresh();
		},
	// -------------------------------------------------------------------------------------------------------------------------
		onOpenDialogApproveReportingHours: function(oEvent) {
			
			var oModelDialog = new JSONModel();
			oModelDialog.setData(
				{
					"dialogTitle" : MessagePool.DIALOG_CONFIRM_HOURS_TITLE_START,             
					"dialogMessage" : "",
					"approveBtnEnabled" : false,
					"valueState" : ValueState.Error
				}
			);
				
			sap.ui.getCore().setModel(null, "oModelDialog");
			sap.ui.getCore().setModel(oModelDialog, "oModelDialog");
			

			debugger;
			
			if (!this._oViewDialogApproveHourReporting) {
				this._oViewDialogApproveHourReporting = sap.ui.xmlfragment("sap.ui.demo.cart.fragment.DialogApproveReportingHours", this);


				// this.getView().addDependent(this._oViewDialogApproveHourReporting);
				// this._oViewDialogApproveHourReporting.setModel(this.getView().getModel('monimModel')) ; 
			}
			this._oViewDialogApproveHourReporting.addStyleClass("sapUiSizeCompact").addStyleClass("myDialog");
			this._oViewDialogApproveHourReporting.open();	
		},
		
		// -------------------------------------------------------------------------------------------------------------------------		

		onOpenDialogCancelMngApproveReportingHours: function(oEvent) {
			
			var oView = this.getView(),
			EmpName = oView.getModel("empDetail").getData().EmpName,
			MngName = oView.getModel("empDetail").getData().MngName, 
			dialogMessage = MessagePool.DIALOG_CANCEL_CONFIRM_HOURS_MESSAGE_PART1 + " " +  EmpName + " " + MessagePool.DIALOG_CANCEL_CONFIRM_HOURS_MESSAGE_PART2 + " "  + MngName;
			
			
			var oModelDialog = new JSONModel();
			oModelDialog.setData(
				{
					"dialogTitle" : MessagePool.DIALOG_CANCEL_CONFIRM_HOURS_TITLE_START,             
					"dialogMessage" : dialogMessage,
					"cancelApproveReason" : ""
				}
			);
				
			sap.ui.getCore().setModel(null, "oModelDialog");
			sap.ui.getCore().setModel(oModelDialog, "oModelDialog");

			if (!this._oViewDialogCancelApproveHourReporting) {
				this._oViewDialogCancelApproveHourReporting = sap.ui.xmlfragment("sap.ui.demo.cart.fragment.DialogCancelApproveReportingHours", this);
			}
			this._oViewDialogCancelApproveHourReporting.addStyleClass("sapUiSizeCompact").addStyleClass("myDialog");
			this._oViewDialogCancelApproveHourReporting.open();	
		},
		
// -------------------------------------------------------------------------------------------------------------------------				
		onRefreshCatalog: function(mngPernr){
			var viewHomeModel = sap.ui.getCore().getModel("categoryViewModel");	
			var categoryView  = sap.ui.getCore().byId(viewHomeModel.getData().categoryView); 
			
			categoryView.getController().refreshList(mngPernr); 
	//		var dt = viewHomeModel.getData();
	 	 
			 	//	homeView.getModel('MngDepModel').setData(oData.results);


		},

		// -------------------------------------------------------------------------------------------------------------------------		
		onOpenDialogMngDeclineReportingHours: function(oEvent) {
			
			var oView = this.getView(),
			EmpName = oView.getModel("empDetail").getData().EmpName,
			MngName = oView.getModel("empDetail").getData().MngName, 
			dialogMessage = MessagePool.DIALOG_DECLINE_HOURS_MESSAGE_PART1 + " " +  EmpName + " " + MessagePool.DIALOG_DECLINE_HOURS_MESSAGE_PART2 + " "  + MngName;
			
			var oModelDialog = new JSONModel();
			oModelDialog.setData(
				{
					"dialogTitle" : MessagePool.DIALOG_DECLINE_HOURS_TITLE_START,             
					"dialogMessage" : dialogMessage,
					"declineReason" : ""
				}
			);
				
			sap.ui.getCore().setModel(null, "oModelDialog");
			sap.ui.getCore().setModel(oModelDialog, "oModelDialog");
			

			debugger;
			
			if (!this._oViewDialogDeclineHourReporting) {
				this._oViewDialogDeclineHourReporting = sap.ui.xmlfragment("sap.ui.demo.cart.fragment.DialogDeclineReportingHours", this);
			}
			this._oViewDialogDeclineHourReporting.addStyleClass("sapUiSizeCompact").addStyleClass("myDialog");
			this._oViewDialogDeclineHourReporting.open();	
		},
		
		
		
		
	// -------------------------------------------------------------------------------------------------------------------------		
	

		declineHoursReportingCallback: function(oModel) {
			var oView = this.getView();
			
			if (oModel !== undefined) {
				debugger;
				var EMessage = oModel.oModelDeclineHoursReporting.getData()[0].EMessage;


				//oModel.EMessage;
				var oModelDialog = new JSONModel();
				oModelDialog.setData(
					{
						"dialogTitle" : MessagePool.DIALOG_DECLINE_HOURS_TITLE_END,             
						"dialogMessage" : EMessage
					}
				);
					
				sap.ui.getCore().setModel(null, "oModelDialog");
				sap.ui.getCore().setModel(oModelDialog, "oModelDialog");
				
				if (!this._oViewDialogConfirm) {
					this._oViewDialogConfirm = sap.ui.xmlfragment("sap.ui.demo.cart.fragment.DialogConfirm", this);
					
				}
				
				if (this._oViewDialogApproveHourReporting) {
				this._oViewDialogApproveHourReporting.close();
				//sap.ui.getCore().setModel(null, "oModelDialog");
				this._oViewDialogApproveHourReporting = null;
				}
	
				this._oViewDialogConfirm.addStyleClass("sapUiSizeCompact").addStyleClass("myDialog");
				this._oViewDialogConfirm.open();
				
			}
			
			// לקרוא לפונקציות של רשימת עובדים ופרטי עובד, ולרענן את המצב של הכפתורים בהתאם לסטאטוס החדש
			this.onRefreshCatalog (this.getView().getModel('empDetail').getData().ManagerPernr);
		//	this.onRefreshButtonState();
			

			this.closeBusyDialog();
		},
	
	// -------------------------------------------------------------------------------------------------------------------------		
		cancelApproveHoursReportingCallback: function(oModel) {
			var oView = this.getView();
			
			if (oModel !== undefined) {
				debugger;
				var EMessage = oModel.oModelCancelApprove.getData()[0].EMessage;

				//oModel.EMessage;
				var oModelDialog = new JSONModel();
				oModelDialog.setData(
					{
						"dialogTitle" : MessagePool.DIALOG_CANCEL_CONFIRM_HOURS_TITLE_END,             
						"dialogMessage" : EMessage
					}
				);
					
				sap.ui.getCore().setModel(null, "oModelDialog");
				sap.ui.getCore().setModel(oModelDialog, "oModelDialog");
				
				if (!this._oViewDialogConfirm) {
					this._oViewDialogConfirm = sap.ui.xmlfragment("sap.ui.demo.cart.fragment.DialogConfirm", this);
					
				}
				
				if (this._oViewDialogApproveHourReporting) {
				this._oViewDialogApproveHourReporting.close();
				//sap.ui.getCore().setModel(null, "oModelDialog");
				this._oViewDialogApproveHourReporting = null;
				}
	
				this._oViewDialogConfirm.addStyleClass("sapUiSizeCompact").addStyleClass("myDialog");
				this._oViewDialogConfirm.open();
				
			}
			
			// לקרוא לפונקציות של רשימת עובדים ופרטי עובד, ולרענן את המצב של הכפתורים בהתאם לסטאטוס החדש
			this.onRefreshCatalog (this.getView().getModel('empDetail').getData().ManagerPernr);
			//this.onRefreshButtonState();
			
			this.closeBusyDialog();
		},
		
	// -------------------------------------------------------------------------------------------------------------------------		
	
		approveReportingHoursCallback: function(oModel) {
			if (oModel !== undefined) {

				var EMessage = 	oModel.EMessage;
				
				var oModelDialog = new JSONModel();
				oModelDialog.setData(
					{
						"dialogTitle" : MessagePool.DIALOG_CONFIRM_HOURS_TITLE_END,             
						"dialogMessage" : EMessage,
						"approveBtnEnabled" : false
					}
				);
					
				sap.ui.getCore().setModel(null, "oModelDialog");
				sap.ui.getCore().setModel(oModelDialog, "oModelDialog");
				
				if (!this._oViewDialogConfirm) {
					this._oViewDialogConfirm = sap.ui.xmlfragment("sap.ui.demo.cart.fragment.DialogConfirm", this);
					
				}
				
				if (this._oViewDialogApproveHourReporting) {
				this._oViewDialogApproveHourReporting.close();
				//sap.ui.getCore().setModel(null, "oModelDialog");
				this._oViewDialogApproveHourReporting = null;
				}


				this._oViewDialogConfirm.addStyleClass("sapUiSizeCompact").addStyleClass("myDialog");
				this._oViewDialogConfirm.open();
			}
			
			// לקרוא לפונקציות של רשימת עובדים ופרטי עובד, ולרענן את המצב של הכפתורים בהתאם לסטאטוס החדש
			this.onRefreshCatalog (this.getView().getModel('empDetail').getData().ManagerPernr);
			//this.onRefreshButtonState();
			
			this.closeBusyDialog();
		},
		
		
	// -------------------------------------------------------------------------------------------------------------------------		
		onRefreshButtonState : function(){
			var oView = this.getView();
			var monthSelectedValue = sap.ui.getCore().getModel('oSelectedMonthModel').getData().monthSelectedKey;
	 		
			var oService = new MngAttendanceService(oView, false);
		 
			oService.getEmployeeFromList(monthSelectedValue, oView.getModel("empDetail").getData().ManagerPernr, oView.getModel("empDetail").getData().EmpPernr);
		 
		//	oService.getEmployeeFromList(monthSelectedValue, oView.getModel("empDetail").getData().ManagerPernr, oView.getModel("empDetail").getData().EmpMainPernr);
		}
		,
	// -------------------------------------------------------------------------------------------------------------------------		

		onConfirm_CancelApproveHoursReportingDialog : function() {
		
			this.openBusyDialog();
		
			var oView = this.getView(),
				monthSelectedValue = sap.ui.getCore().getModel('oSelectedMonthModel').getData().monthSelectedKey,
				empUname = oView.getModel("empDetail").getData().EmpUname,
				strComment = sap.ui.getCore().getModel("oModelDialog").getData().cancelApproveReason;
				
			var oService = new MngAttendanceService(oView, false);
		    oService.cancelApproveHoursReporting(monthSelectedValue, empUname, strComment);
			
			// oView.getModel("oModelEmpAttendanceTable").setProperty('/modelData/lines', this._oPopover.getBindingContext().getModel());
			// oView.getModel("oModelEmpAttendanceTable").refresh();
			
			if (this._oViewDialogCancelApproveHourReporting) {
				this._oViewDialogCancelApproveHourReporting.close();
				sap.ui.getCore().setModel(null, "oModelDialog");
				this._oViewDialogCancelApproveHourReporting = null;
			}
		},
		

	// -------------------------------------------------------------------------------------------------------------------------		
		onCancel_CancelApproveDialog : function() {
			if (this._oViewDialogCancelApproveHourReporting) {
				this._oViewDialogCancelApproveHourReporting.close();
				sap.ui.getCore().setModel(null, "oModelDialog");
				this._oViewDialogCancelApproveHourReporting = null;
			}

		},
		
	// -------------------------------------------------------------------------------------------------------------------------		
		
		onCloseDialogConfirm : function() {
			if (this._oViewDialogConfirm) {
				this._oViewDialogConfirm.close();
				sap.ui.getCore().setModel(null, "oModelDialog");
				this._oViewDialogConfirm = null;
			}

		},
		
	// -------------------------------------------------------------------------------------------------------------------------
		
		onConfirmApproveHoursReportingDialog : function(e) {
			
			this.openBusyDialog();
			
			var oView = this.getView(),
			monthSelectedValue = sap.ui.getCore().getModel('oSelectedMonthModel').getData().monthSelectedKey,
			empDetailModel = oView.getModel("empDetail"),
			empUname = empDetailModel.getData().EmpUname,
			managerPernr = empDetailModel.getData().ManagerPernr,
			monimModelMngApproveDialog = sap.ui.getCore().getModel("monimModelMngApproveDialog"),
			aTableData = monimModelMngApproveDialog.getData().lines;
			
			var oData = {};
			
			oData.IEmpPernr = "";
			oData.IEmpUname = empUname;
			oData.IMngUname = managerPernr;
			oData.IMngPernr = managerPernr;
			oData.IMonth = monthSelectedValue;
			oData.EErrorType = "";
			oData.EMessage = "";
			
			var oEntry = {};
			var a = [];
			
			for (var i=0; i<aTableData.length; i++) {
				oEntry = {};
				
				oEntry.EmpPernr = aTableData[i].Pernr;
				if(aTableData[i].checkMngApproveOvertime){
					oEntry.EmpOvertime = aTableData[i].OvertimeAppMng;
				}
				else{
					oEntry.EmpOvertime = "0";

				}
				a.push(oEntry);
				
			}
			
			oData.ConfirmToOvertimenav = a;
			
			var oService = new MngAttendanceService(oView, false);
		    oService.approveReportingHours(oData);
		    },
		
	// -------------------------------------------------------------------------------------------------------------------------
		// סגירת דיאלוג של אישור שעות
		onCancelApproveDialog : function(e) {
			//השמת ערך שעות נוספות המקורי - כפי שהגיע מהמערכת
			this.setMonimModelOvertimeSource();
			
			if (this._oViewDialogApproveHourReporting) {
				this._oViewDialogApproveHourReporting.close();
				//sap.ui.getCore().setModel(null, "oModelDialog");
				this._oViewDialogApproveHourReporting = null;
			}
		},
	//---------------------------------------------------------------------------------------------------
		openBusyDialog : function() {
			var oDialogFragment = sap.ui.xmlfragment("sap.ui.demo.cart.fragment.BusyDialog");

			var oBusyDialogModel = sap.ui.getCore().getModel("oBusyDialogModel");
			if (oBusyDialogModel) {
				oDialogFragment = oBusyDialogModel.getData().o;
				oDialogFragment.open();
			}
		},
		
	//---------------------------------------------------------------------------------------------------
		closeBusyDialog : function() {
			var oDialogFragment = sap.ui.xmlfragment("sap.ui.demo.cart.fragment.BusyDialog");
	
			var oBusyDialogModel = sap.ui.getCore().getModel("oBusyDialogModel");
			if (oBusyDialogModel) {
				oDialogFragment = oBusyDialogModel.getData().o;
				oDialogFragment.close();
			}
		},
		
	// -------------------------------------------------------------------------------------------------------------------------
		onCancelDeclineDialog : function(e) {
			
			if (this._oViewDialogDeclineHourReporting) {
				this._oViewDialogDeclineHourReporting.close();
				sap.ui.getCore().setModel(null, "oModelDialog");
				this._oViewDialogDeclineHourReporting = null;
			}
		},
		
	// -------------------------------------------------------------------------------------------------------------------------		
		onConfirmDeclineHoursReportingDialog : function() {
			
			this.openBusyDialog();
			
			var oView = this.getView(),
				monthSelectedValue = sap.ui.getCore().getModel('oSelectedMonthModel').getData().monthSelectedKey,
				empUname = oView.getModel("empDetail").getData().EmpUname,
				strComment = sap.ui.getCore().getModel("oModelDialog").getData().declineReason;
				
			var oService = new MngAttendanceService(oView, false);
		    oService.declineApproveHoursReporting(monthSelectedValue, empUname, strComment);
			
			// oView.getModel("oModelEmpAttendanceTable").setProperty('/modelData/lines', this._oPopover.getBindingContext().getModel());
			// oView.getModel("oModelEmpAttendanceTable").refresh();

			if (this._oViewDialogDeclineHourReporting) {
				this._oViewDialogDeclineHourReporting.close();
				sap.ui.getCore().setModel(null, "oModelDialog");
				this._oViewDialogDeclineHourReporting = null;
			}
		},

		/*
		fnUpdateProduct: function(productId) {
			var sPath = "/Products('" + productId + "')",
				fnCheck = function () {
					this._checkIfProductAvailable(sPath);
				};

			this.getView().bindElement({
				path: sPath,
				events: {
					change: fnCheck.bind(this)
				}
			});
		},*/

		_checkIfProductAvailable: function(sPath) {
			var oModel = this.getModel();
			var oData = oModel.getData(sPath);

			// show not found page
			if (!oData) {
				this._router.getTargets().display("notFound");
			}
		},
		
		onPersoButtonPressed: function (oEvent) {
			this._oTPC.openDialog();
		},

		onTablePersoRefresh : function() {
			PersoService.resetPersData();
			this._oTPC.refresh();
		},

		onTableGrouping : function(oEvent) {
			this._oTPC.setHasGrouping(oEvent.getSource().getSelected());
		},

		/**
		 * Called, when the add button of a product is pressed.
		 * Saves the product, the i18n bundle, and the cart model and hands them to the <code>addToCart</code> function
		 * @public
		 */
		onAddButtonPress : function () {
			var oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oProduct = this.getView().getBindingContext().getObject();
			var oCartModel = this.getView().getModel("cartProducts");
			cart.addToCart(oResourceBundle, oProduct, oCartModel);
		},

		onCartButtonPress :  function () {
			this._router.navTo("cart");
		},

		onNavButtonPress : function () {
			this.getOwnerComponent().myNavBack();
		}
	});
});