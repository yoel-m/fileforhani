sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"../model/formatter",
	"sap/m/MessageToast",
	'sap/m/MessageStrip',
	"../model/MainService"
], function (BaseController, JSONModel, formatter, MessageToast,MessageStrip,MainService) {
	"use strict";

	return BaseController.extend("sap.ui.demo.worklist.controller.Detail", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit : function () {
 
			let iOriginalBusyDelay,
				oViewModel = new JSONModel({
					busy : true,
					delay : 0
				});

			this.getRouter().getRoute("detail").attachPatternMatched(this._onObjectMatched, this);

			// Store original busy indicator delay, so it can be restored later on
			iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();
			this.setModel(oViewModel, "detailView");
			this.getOwnerComponent().getModel().metadataLoaded().then(function () {
					// Restore original busy indicator delay for the object view
					oViewModel.setProperty("/delay", iOriginalBusyDelay);
				}
			);
		},

 
		 /*
		onNavBack : function() {
			let sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("worklist", {}, true);
			}
		},  
		*/
		
		_selectedDayCongig: function(isFirstRecord, isLastRecord,currentIndex) {
			let selectedDays  = this.getSelectedListItems().getData() ; 
			let days = selectedDays.length ; 
			if (days == 1 ) {
				this.getView().byId ("arrow-right").setVisible (false)      ;
				this.getView().byId ("arrow-left").setVisible (false)      ;
				return ; 
			}else {
				this.getView().byId ("arrow-right").setVisible (true)      ;
				this.getView().byId ("arrow-left").setVisible (true)      ;
			}
			if (isLastRecord && this.getView().byId ("arrow-right").getVisible()) {
				this.getView().byId ("arrow-right").setVisible (false)  ; 
			}
			if (isFirstRecord && this.getView().byId ("arrow-left").getVisible()) {
				this.getView().byId ("arrow-left").setVisible (false)  ; 
			}		
			if (!isFirstRecord && currentIndex+1 == days ) {
				this.getView().byId ("arrow-right").setVisible (false)  ; 			
			}
			if ( currentIndex == 0 ) {
				this.getView().byId ("arrow-left").setVisible (false)  ; 
			}
			
		},
		_setActualRecord:  function(actualIndex) {
			
			let selectedRecord = 	this.getSelectedListItems().getData()[actualIndex] ; 			    	
	    	let absTypeText = this.getAbsTypeVal(selectedRecord.AttType) ; 
	    	selectedRecord.AttText = absTypeText ; 

	    	let diff =  this.calculateTimeDifference (selectedRecord.LclockIn , selectedRecord.LclockOut ) ; 
	    	selectedRecord.diffMain = diff ;       
	    	
	    	diff =  this.calculateTimeDifference (selectedRecord.LtimeIn.replace(':' , '' )  , selectedRecord.LtimeOut.replace(':' , '' )  ) ; 
	    	selectedRecord.diffMan1 = diff ;      

	    	
	    	diff =  this.calculateTimeDifference (selectedRecord.LtimeIn2.replace(':' , '' )  , selectedRecord.LtimeOut2.replace(':' , '' )  ) ; 
	    	selectedRecord.diffMan2 = diff ;	    	

	    	let SelectedDayItemModel = new JSONModel(selectedRecord);

	    	this.setSelectedDayItem (SelectedDayItemModel);   
	    	
	    	this.setStatusButton() ; 
	 
			//return  (this.getSelectedListItems().getData()[actualIndex]) ;
		}, 
		
		_getNextIndex:  function(currentIndex) {
			let len = this.getSelectedListItems().getData().length ; 
			if (currentIndex + 1 >= len ) {
				return -1 ;
			}else {
				return currentIndex + 1 ; 
			}
		}, 
		_getPreIndex:  function(currentIndex) {
			 
			if (currentIndex - 1 < 0 ) {
				return -1 ;
			}else {
				return currentIndex - 1 ; 
			}			
		}, 

		onNextItem : function () {
			let	selectedItems = this.getSelectedListItems().getData() ; 
			let selectedDay  =this.getSelectedDayItem().getData() ; 
			
			let currentIndex = -1 ; 
			for (var i=0; i<selectedItems.length; i++) {
				if (selectedItems[i].Ldate == selectedDay.Ldate ) { 
					currentIndex  = i ;
				}
			}
			if (currentIndex > -1 ) {
				let nextIndex  = this._getNextIndex(currentIndex) ; 
				if ( nextIndex > -1  ) {
					this._setActualRecord (nextIndex) ; 
					this._selectedDayCongig(false,false,nextIndex) ; 
				}else {
					MessageToast.show('הגעת לסוף הרשימה');
					this._selectedDayCongig(false,true) ; 
				}
				
			}
		 
			
		},
		onPreItem: function () {
			let	selectedItems = this.getSelectedListItems().getData() ; 
			let selectedDay  =this.getSelectedDayItem().getData() ; 
			
			let currentIndex = -1 ; 
			for (var i=0; i<selectedItems.length; i++) {
				if (selectedItems[i].Ldate == selectedDay.Ldate ) { 
					currentIndex  = i ;
				}
			}
			if (currentIndex > -1 ) {
				let preIndex  = this._getPreIndex(currentIndex) ; 
				if ( preIndex > -1  ) {
					this._setActualRecord (preIndex) ; 
					this._selectedDayCongig(false,false,preIndex) ; 
				}else {
					MessageToast.show('הגעת לתחילת הרשימה');
					this._selectedDayCongig(false,true) ; 
				}
				
			}
		},
		setStatusButton : function () {
			let selectedRecordData = this.getSelectedDayItem().getData() ; 
			if ( parseInt(  selectedRecordData.Status ) == 2) {   // אושר 
				this.getView().byId("reject").setVisible (true);
				this.getView().byId("approve").setVisible (false);
			}
			if (parseInt(  selectedRecordData.Status ) == 1 ) {     // ממתין לאישור 
				this.getView().byId("approve").setVisible (true);   // 
				this.getView().byId("reject").setVisible (false);
			}			
		},
		_onObjectMatched : function (oEvent) {
			
			let oArguments = oEvent.getParameter("arguments");
			let selectedRecord = this._setActualRecord(0); 
			this._selectedDayCongig(true,false) ;
 			
			let selectedEmp = this.getSelectedEmployeesItems().getData().filter(function selectedEmp(item) {
			  return item.Pernr == oArguments.objectId ; 
			}); 
			
			this.getEmpDetailSet(oArguments.objectId) ; 
			
			this.getView().byId("empPernr").setText(selectedEmp[0].Vorna +  ' ' + selectedEmp[0].Nachn );
		    //	this.setStatusButton() ; 

		} ,
		checkDateInOut: function(oInTime, oOuttime) {
			let inTime = oInTime.replace(':','') ; 
			inTime = inTime.substring(0,2) + ":" +  inTime.substring(2,4) ;

			let outTime = oOuttime.replace(':','') ; 
		    outTime = outTime.substring(0,2) + ":" +  outTime.substring(2,4) ;	
			
			if (outTime < inTime ) {
			//	MessageToast.show('זמן יציאה צריך להיות גדול מזמן כניסה');
				var oVC = this.byId("msgStrip");
		
				var oMsgStrip = new MessageStrip( {
					text: "זמן יציאה צריך להיות גדול מזמן כניסה",
					showCloseButton: true,
					showIcon: true,
					type: "Error"
				});

				oVC.addItem(oMsgStrip);
				sap.ui.core.BusyIndicator.hide();
				return false; 
			} else {
				return true ; 
			}			
		},

		onSavePress: function(oEvent,sts) {
			let dataToUpdate =  this.getSelectedDayItem().getData(); 
			let oView = this.getView() ; 
			
			oView.byId('msgStrip').removeAllItems() ; 
			
			if (! this.checkDateInOut (dataToUpdate.LtimeIn,dataToUpdate.LtimeOut )){
				return false ; 
			}
			if (! this.checkDateInOut (dataToUpdate.LtimeIn2,dataToUpdate.LtimeOut2 )){
				return false ; 
			}
		 
			if (dataToUpdate.LtimeIn2.length > 0  ||  dataToUpdate.LtimeOut2.length > 0 ) {
				if (! (dataToUpdate.AttType2 )){
					MessageToast.show("חייב לבחור סוג דיווח") ; 
					return; 
				}
			}
			if (!sts){
				sts = dataToUpdate.Status  ; 
			}
			
			let tmp = {
			    "Pdsnr" : parseInt( dataToUpdate.Pdsnr).toString(),
			    "Pernr" : dataToUpdate.Pernr,
			    "Ldate" : "",
			    "Lday" : "",
			    "LclockIn" : "",
			    "LclockOut" : "",
			    "LtimeIn" : dataToUpdate.LtimeIn.indexOf(":") >=0 ? dataToUpdate.LtimeIn.replace(':','')+'00' : dataToUpdate.LtimeIn,
			    "LtimeOut" : dataToUpdate.LtimeOut.indexOf(":") >=0 ? dataToUpdate.LtimeOut.replace(':','')+'00' : dataToUpdate.LtimeOut,
			    "AttType" : dataToUpdate.AttType,
			    "AttType2" : dataToUpdate.AttType2,
			    "Remark" : dataToUpdate.Remark,
			    "Remark2" : dataToUpdate.Remark2,
			    "Status" : sts,
			    "TekenCmpl" : "",
			    "LtimeIn2" : dataToUpdate.LtimeIn2.indexOf(":") >=0 ? dataToUpdate.LtimeIn2.replace(':','')+'00' : dataToUpdate.LtimeIn2,
			    "LtimeOut2" : dataToUpdate.LtimeOut2.indexOf(":") >=0 ? dataToUpdate.LtimeOut2.replace(':','')+'00' : dataToUpdate.LtimeOut2
			};
			
			
			if (dataToUpdate.LtimeIn.length > 0 && parseInt ( dataToUpdate.LtimeIn) > 0){
				tmp.OrigfIn ="E" ;
			}
			if (dataToUpdate.LtimeOut.length > 0 && parseInt ( dataToUpdate.LtimeOut) > 0){
				tmp.OrigfOut ="E" ;
			}			
 			if (dataToUpdate.LtimeIn2.length > 0 && parseInt ( dataToUpdate.LtimeIn2) > 0){
				tmp.OrigfIn2 ="E" ;
			}
			if (dataToUpdate.LtimeOut2.length > 0 && parseInt ( dataToUpdate.LtimeOut2) > 0){
				tmp.OrigfOut2 ="E" ;
			}

			const oCtrl = this;
			const oService = new MainService(this.getView(),false);
			
			let updateDayManual = oService.saveEtTypesSet(tmp); 
			
			let tmpModel = new JSONModel(tmp); 
			this.setModel(tmpModel, "tmpSave");
		  
			updateDayManual.then(function(oODataResult) {
			if ((oODataResult) && (oODataResult.oData)) {
				sap.ui.core.BusyIndicator.hide();
				if (oODataResult.oResponse.statusCode == "200" ||
				   (oODataResult.oResponse.statusCode === "201") ||
				   (oODataResult.oResponse.statusCode === "202") ||
				   (oODataResult.oResponse.statusCode == "0"))
				{ 				
					MessageToast.show('הנתונים עודכנו בהצלחה');
					let updateDate =  this.getSelectedDayItem().getData(); 
					updateDate.Status  = this.getModel("tmpSave").getData().Status ; 
					let updateModel= new JSONModel(updateDate); 
					this.setSelectedDayItem (updateModel) ; 
					this.setStatusButton() ; 

				} else {
					MessageToast.show('Status Code ${oODataResult.oResponse.statusCode}');
				}
			} else {
				MessageToast.show("No Data");
			}}.bind(oCtrl))
			.catch(function(oError) {
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(oError.message);
			}.bind(oCtrl)) ; 	

		},



		handleChange : function () {
			let oItem = this.getSelectedDayItem().getData();
	    	let diff =  this.calculateTimeDifference (oItem.LtimeIn.replace(':' , '' )  , oItem.LtimeOut.replace(':' , '' )  ) ; 
	    	oItem.diffMan1 = diff ;      
	    	let	odayModel = new JSONModel(oItem);
	    	this.setSelectedDayItem(odayModel) ; 
		}, 		
		handleChange2 : function () {
			let oItem = this.getSelectedDayItem().getData();
	    	let diff =  this.calculateTimeDifference (oItem.LtimeIn2.replace(':' , '' )  , oItem.LtimeOut2.replace(':' , '' )  ) ; 
	    	oItem.diffMan2 = diff ;      
	    	let	odayModel = new JSONModel(oItem);
	    	this.setSelectedDayItem(odayModel) ; 
		}, 		

		_bindView : function (sObjectPath) {
			let oViewModel = this.getModel("detailView"),
				oDataModel = this.getModel();

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function () {
						oDataModel.metadataLoaded().then(function () {
							oViewModel.setProperty("/busy", true);
						});
					},
					dataReceived: function () {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		}
		
		
		
	});

});