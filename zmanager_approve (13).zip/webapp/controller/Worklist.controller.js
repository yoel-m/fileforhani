sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"../model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"../model/MainService", 
	"sap/m/MessageToast"
], function (BaseController, JSONModel, formatter, Filter, FilterOperator,MainService,MessageToast ) {
	"use strict";

	return BaseController.extend("sap.ui.demo.worklist.controller.Worklist", {

		formatter: formatter,

		onInit : function () {
			let oViewModel,
				iOriginalBusyDelay,
				oTable = this.byId("table");


			iOriginalBusyDelay = oTable.getBusyIndicatorDelay();
		
			this._aTableSearchState = [];

		
			oViewModel = new JSONModel({
				worklistTableTitle : this.getResourceBundle().getText("worklistTableTitle"),
				shareOnJamTitle: this.getResourceBundle().getText("worklistTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText : this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay : 0
			});
			this.setModel(oViewModel, "worklistView");
			//this.getEtTypes() ;

			this.getOwnerComponent().getRouter().getRoute("worklist").attachPatternMatched(this._onMasterMatched, this);
		},

		_onMasterMatched :  function() {
					 
			let oDate = new Date () ; 
			let fMounthSelected = this.getFormattedMonthDate(oDate) ; 

			const oCtrl = this;
			const oService = new MainService(this.getView(),false);
			
			let getItms = oService.getEmpListSet(fMounthSelected); 
			 
			getItms.then(function(oODataResult) {
				if ((oODataResult) && (oODataResult.oData)) {
					sap.ui.core.BusyIndicator.hide();
	
					if (oODataResult.oResponse.statusCode == "200" ||
					   (oODataResult.oResponse.statusCode === "201") ||
					   (oODataResult.oResponse.statusCode === "202") ||
					   (oODataResult.oResponse.statusCode == "0")
						
						) { 				
						 
						let oModel = new JSONModel(oODataResult.oData.results); 
						this.setSelectedEmployeesItems(oModel)  ;
						 
					 	let modelData = oODataResult.oData.results ; 
					  
					} else {
						MessageToast.show(`Status Code ${oODataResult.oResponse.statusCode}`);
					}
					
				} else {
					MessageToast.show("No Data");
				}}.bind(oCtrl))
			.catch(function(oError) {
				sap.ui.core.BusyIndicator.hide();
				{
					MessageToast.show(oError.message);
				}
			}.bind(oCtrl)) ;  	 

		 
		},

	    getFormattedMonthDate: function (oDate) { 
	    	let fMounthSelected = oDate.getMonth()+1 +'';
			if (fMounthSelected.length < 2 ) {
				fMounthSelected = '0' + fMounthSelected ; 
			}			
			fMounthSelected = oDate.getFullYear()  + fMounthSelected ; 
			return fMounthSelected ; 
	    },	
		onUpdateFinished : function (oEvent) {
 
			let sTitle,
				oTable = oEvent.getSource(),
				iTotalItems = oEvent.getParameter("total");
 
		 
			if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
			} else {
				sTitle = this.getResourceBundle().getText("worklistTableTitle");
			}
			this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
		 
		},
		
		
	    getEtTypes : function(pernr) {

			const oCtrl = this;
			const oService = new MainService(this.getView(),false);
			
			let getEtTypes = oService.getEtTypesSet(pernr); 
			
			getEtTypes.then(function(oODataResult) {
				if ((oODataResult) && (oODataResult.oData)) {
					sap.ui.core.BusyIndicator.hide();
					
					if (oODataResult.oResponse.statusCode == "200" ||
					   (oODataResult.oResponse.statusCode === "201") ||
					   (oODataResult.oResponse.statusCode === "202") ||
					   (oODataResult.oResponse.statusCode == "0"))
					{ 
						//this.setAbsTypesModel (oODataResult.oData.results);
						let res = oODataResult.oData.results ; 
					
						let oModel = new JSONModel(res); 
						this.getOwnerComponent().setModel(oModel , "absTypesModel");
					 
					} else {
						MessageToast.show(`Status Code ${oODataResult.oResponse.statusCode}`);
					}
				} else {
					MessageToast.show("No Data");
				}}.bind(oCtrl))
			.catch(function(oError) {
				sap.ui.core.BusyIndicator.hide();
				{
					MessageToast.show(oError.message);
				}
			}.bind(oCtrl)) ;  	    	
	    	
	    },  
	    

		onPress : function (oEvent) {
		    let pernr = parseInt (oEvent.getSource().getBindingContext('selectedEmployeesModel').getObject().Pernr).toString();
			this.getEtTypes(pernr) ;
			this._showObject(oEvent.getSource());
		},


		onRefresh : function () {
			let oTable = this.byId("table");
			oTable.getBinding("items").refresh();
		},


		_showObject : function (oItem) {
			 
			this.getRouter().navTo("object", {
				objectId:  oItem.getBindingContext('selectedEmployeesModel').getProperty("Pernr")
			});
			 
		}



	 /*
		_applySearch: function(aTableSearchState) {
			let oTable = this.byId("table"),
				oViewModel = this.getModel("worklistView");
			oTable.getBinding("items").filter(aTableSearchState, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (aTableSearchState.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
			}
		}
		*/

	});
});