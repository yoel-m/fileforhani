jQuery.sap.declare("model.DashboardService");
sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/odata/v2/ODataModel"
 
], function(Object, JSONModel, Filter, FilterOperator, ODataModel, GeneralConstants, MessagePool) {
	"use strict";

	return Object.extend("icl.group.com.dashboard.model.service.DashboardService", {

		metadata: {
			properties: {
				oView: {
					oView: {
						type: "sap.ui.view"
					},
					bMock: {
						type: "boolean",
						defaultValue: false
					},
					sUrl: {
						type: "string"
					}

				}
			}
		},
		// -----------------------------------------------------------------------------------------------------------------
		constructor: function(view, isComponent) {
			this.oView = view;
			this.bMock = false;
			this.isComponent = isComponent; 
			//this.sUrl = GeneralConstants.SERVICE_URL;
			if (!isComponent) {
				this.sUrl = view.getController().getOwnerComponent().getModel().sServiceUrl ; 
			}else{
				this.sUrl = view.getModel().sServiceUrl ; 
			}
			
			//	"http://sapgwdev.clalit.org.il:8021/sap/opu/odata/sap/ZHR_ESS_MENG_REPORTING_SRV";

		},

		// -----------------------------------------------------------------------------------------------------------------		
		getPrDetailsSet: function (selectedDate) {

			var oModel, oCtrl;
			oModel = new JSONModel();
			if (!this.isComponent ){
				oCtrl = this.oView.getController();
			}else{
				oCtrl = this ; 
			}
			
			if (this.bMock) {

				this.sUrl = "./localService/mockdata/CopyOflinesSet.json";

				oModel.loadData(
					this.sUrl,
					null,
					true,
					"GET",
					false,
					true
				);
				
				oModel.attachRequestCompleted(function() {
					oCtrl.getPrDetailsSetCallback(oModel);
				});
				
			} else {

				var oModelPrDetailsSetData = new sap.ui.model.odata.v2.ODataModel(this.sUrl);
				oModelPrDetailsSetData.setDefaultCountMode(sap.ui.model.odata.CountMode.None);

				oModelPrDetailsSetData.attachRequestCompleted({
						oView: this.oView,
						oModel: oModel
					},

					function(o, oParams) {
						
						var oResponse = o.getParameter("response");
						if (
							(oResponse.statusCode === "200") ||
							(oResponse.statusCode === "202") ||
							(oResponse.statusCode === "0")
						) {
							var oModelAllData = JSON.parse(o.getParameters("responseText").response.responseText).d.results;
							oModel.setData( oModelAllData);
							oCtrl.oView.getPrDetailsSetCallback(oParams);
						} else {
							var sError = (oResponse.statusCode).toString() + " --> " + oResponse.message;
							console.log(sError);
							var ERROR_ORG_TEVEN_DATA_INVALID = "שגיאה בניסון לשלוף נתוני מקור";
						
							console.log (ERROR_ORG_TEVEN_DATA_INVALID);
						//	oCtrl.openDialog("E", ERROR_ORG_TEVEN_DATA_INVALID );  // MessagePool.ERROR_ORG_TEVEN_DATA_INVALID
						}
					}
				);

				oModelPrDetailsSetData.attachRequestFailed(
					function(o, ofilter) {
						console.log("getPrDetailsSet");
					}
				);


				oModelPrDetailsSetData.read(
					"/PrDetailsSet" 
				);
			}	
		
		}
	
	});
	
	

});